package app.touchprobe;

interface IProbeService {
    void destroy() = 16777114;
    String probe() = 1;
    String readTouch(int ms) = 2;
    String inject(int x, int y) = 3;
    String setLibDir(String dir) = 4;
    String grabTest(int ms) = 5;
    String correct(int ms, int dx, int dy) = 6;
}
