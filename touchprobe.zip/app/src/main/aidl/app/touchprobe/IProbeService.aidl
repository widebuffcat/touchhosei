package app.touchprobe;

interface IProbeService {
    void destroy() = 16777114;
    String probe() = 1;
    String readTouch(int ms) = 2;
    String inject(int x, int y) = 3;
}
