package app.touchprobe;

import android.app.Activity;
import android.content.ComponentName;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.concurrent.Callable;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {

    private static final int REQ = 100;

    private TextView logView;
    private TextView target;
    private EditText dxEdit, dyEdit;
    private ScrollView scroll;
    private IProbeService svc;
    private int hits = 0;

    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            svc = IProbeService.Stub.asInterface(binder);
            try {
                svc.setLibDir(getApplicationInfo().nativeLibraryDir);
            } catch (Throwable t) {
                log("setLibDir失敗: " + t);
            }
            log("サービス接続OK（shell権限で動作中）");
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            svc = null;
            log("サービス切断");
        }
    };

    private final Shizuku.OnRequestPermissionResultListener permListener =
            (requestCode, grantResult) -> {
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    log("Shizukuの許可を得ました");
                    bind();
                } else {
                    log("Shizukuの許可が拒否されました");
                }
            };

    private int parseInt(EditText e) {
        try {
            return Integer.parseInt(e.getText().toString().trim());
        } catch (Throwable t) {
            return 0;
        }
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(12), dp(12), dp(12));

        root.addView(button("1. Shizukuに接続", v -> connect()));
        root.addView(button("2. 入力デバイス調査", v -> call("入力デバイス調査", () -> svc.probe())));
        root.addView(button("3. タッチ読取（8秒・画面をタップ/ドラッグ）",
                v -> call("タッチ読取", () -> svc.readTouch(8000))));
        root.addView(button("4. 注入テスト（下の枠の中央を自動タップ）", v -> {
            int[] loc = new int[2];
            target.getLocationOnScreen(loc);
            final int cx = loc[0] + target.getWidth() / 2;
            final int cy = loc[1] + target.getHeight() / 2;
            call("注入 (" + cx + "," + cy + ")", () -> svc.inject(cx, cy));
        }));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        dxEdit = new EditText(this);
        dxEdit.setHint("補正X(px)");
        dxEdit.setText("0");
        dxEdit.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        dyEdit = new EditText(this);
        dyEdit.setHint("補正Y(px)");
        dyEdit.setText("0");
        dyEdit.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        row.addView(dxEdit, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(dyEdit, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(row);
        root.addView(button("5. 占有テスト（5秒・この間は画面が反応しない）",
                v -> call("占有テスト", () -> svc.grabTest(5000))));
        root.addView(button("6. 補正して再注入（15秒）", v -> {
            final int dx = parseInt(dxEdit);
            final int dy = parseInt(dyEdit);
            call("補正再注入 dx=" + dx + " dy=" + dy, () -> svc.correct(15000, dx, dy));
        }));

        target = new TextView(this);
        target.setText("ターゲット枠\n回数 0");
        target.setGravity(Gravity.CENTER);
        target.setBackgroundColor(Color.DKGRAY);
        target.setTextColor(Color.WHITE);
        target.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                hits++;
                target.setText("ターゲット枠\n回数 " + hits
                        + "\n最後 (" + (int) e.getRawX() + "," + (int) e.getRawY() + ")");
            }
            return true;
        });
        root.addView(target, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(110)));

        scroll = new ScrollView(this);
        logView = new TextView(this);
        logView.setTextSize(12);
        logView.setTextIsSelectable(true);
        scroll.addView(logView);
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        Shizuku.addRequestPermissionResultListener(permListener);
    }

    @Override
    protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener);
        super.onDestroy();
    }

    private Shizuku.UserServiceArgs args() {
        return new Shizuku.UserServiceArgs(new ComponentName(getPackageName(), ProbeService.class.getName()))
                .daemon(false)
                .processNameSuffix("probe")
                .version(1);
    }

    private void connect() {
        try {
            if (!Shizuku.pingBinder()) {
                log("Shizukuが動いていません。Shizukuアプリで開始してください");
                return;
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(REQ);
                return;
            }
            bind();
        } catch (Throwable t) {
            log("エラー: " + t);
        }
    }

    private void bind() {
        try {
            Shizuku.bindUserService(args(), conn);
            log("サービス起動中…");
        } catch (Throwable t) {
            log("bind失敗: " + t);
        }
    }

    private void call(String label, Callable<String> c) {
        if (svc == null) {
            log("先に「1. Shizukuに接続」を押してください");
            return;
        }
        log("▶ " + label);
        new Thread(() -> {
            String r;
            try {
                r = c.call();
            } catch (Throwable t) {
                r = "エラー: " + t;
            }
            final String out = r;
            runOnUiThread(() -> log(out));
        }).start();
    }

    private void log(String s) {
        logView.append(s + "\n");
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }
}
