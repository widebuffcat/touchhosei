package app.touchprobe;

import android.os.Build;
import android.os.Process;
import android.os.SystemClock;
import android.system.Os;
import android.system.OsConstants;
import android.system.StructPollfd;
import android.view.InputDevice;
import android.view.InputEvent;
import android.view.MotionEvent;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

/** Shizukuのユーザーサービス。shell権限のプロセスで動く。 */
public class ProbeService extends IProbeService.Stub {

    public ProbeService() {
    }

    @Override
    public void destroy() {
        System.exit(0);
    }

    private static String readText(String path) {
        try (BufferedReader r = new BufferedReader(new FileReader(path))) {
            String s = r.readLine();
            return s == null ? "" : s.trim();
        } catch (Throwable t) {
            return "";
        }
    }

    // ABS_MT_POSITION_X(0x35=53)のビットが立っているか(64bitカーネル前提)
    private static boolean hasMt(String abs) {
        try {
            String[] t = abs.trim().split("\\s+");
            long w = Long.parseUnsignedLong(t[t.length - 1], 16);
            return ((w >>> 53) & 1L) == 1L;
        } catch (Throwable t) {
            return false;
        }
    }

    private static File[] eventFiles() {
        File[] fs = new File("/dev/input").listFiles();
        if (fs == null) return new File[0];
        Arrays.sort(fs);
        return fs;
    }

    private static String geteventRaw(String path) {
        StringBuilder sb = new StringBuilder();
        try {
            java.lang.Process p = new ProcessBuilder("getevent", "-lp", path)
                    .redirectErrorStream(true).start();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line).append("\n");
            }
            p.destroy();
        } catch (Throwable t) {
            sb.append("getevent失敗: ").append(t).append("\n");
        }
        return sb.toString();
    }

    private static String devName(String raw) {
        for (String line : raw.split("\n")) {
            int i = line.indexOf("name:");
            if (i >= 0) return line.substring(i + 5).trim();
        }
        return "?";
    }

    @Override
    public String probe() {
        StringBuilder sb = new StringBuilder();
        sb.append("uid=").append(Process.myUid()).append("（2000ならshell）\n");
        sb.append("Android SDK=").append(Build.VERSION.SDK_INT).append("\n");
        File[] fs = eventFiles();
        if (fs.length == 0) sb.append("/dev/input を列挙できません\n");
        for (File f : fs) {
            String n = f.getName();
            if (!n.startsWith("event")) continue;
            String raw = geteventRaw(f.getPath());
            boolean mt = raw.contains("ABS_MT_POSITION_X");
            sb.append(n).append(" 読取=").append(f.canRead() ? "可" : "不可")
                    .append(" 名前=").append(devName(raw))
                    .append(mt ? "  ★タッチ候補" : "").append("\n");
        }
        return sb.toString();
    }

    private static String findTouchPath() {
        for (File f : eventFiles()) {
            String n = f.getName();
            if (!n.startsWith("event")) continue;
            if (geteventRaw(f.getPath()).contains("ABS_MT_POSITION_X")) {
                return f.getPath();
            }
        }
        return null;
    }

    private static String getevent(String path) {
        StringBuilder sb = new StringBuilder();
        try {
            java.lang.Process p = new ProcessBuilder("getevent", "-lp", path)
                    .redirectErrorStream(true).start();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = r.readLine()) != null) {
                    if (line.contains("POSITION_") || line.contains("name:")) {
                        sb.append("  ").append(line.trim()).append("\n");
                    }
                }
            }
            p.destroy();
        } catch (Throwable t) {
            sb.append("  getevent失敗: ").append(t).append("\n");
        }
        return sb.toString();
    }

    @Override
    public String readTouch(int ms) {
        String path = findTouchPath();
        if (path == null) return "タッチデバイスが見つかりません（先に入力デバイス調査を）";
        StringBuilder sb = new StringBuilder();
        sb.append("対象: ").append(path).append("\n").append(getevent(path));
        FileDescriptor fd = null;
        try {
            fd = Os.open(path, OsConstants.O_RDONLY, 0);
        } catch (Throwable t) {
            return sb.append("open失敗: ").append(t).toString();
        }
        int total = 0, touches = 0;
        int minX = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE;
        int minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
        int lastX = -1, lastY = -1;
        byte[] buf = new byte[24 * 64];
        long end = SystemClock.uptimeMillis() + ms;
        try {
            StructPollfd p = new StructPollfd();
            p.fd = fd;
            p.events = (short) OsConstants.POLLIN;
            while (true) {
                long left = end - SystemClock.uptimeMillis();
                if (left <= 0) break;
                int n = Os.poll(new StructPollfd[]{p}, (int) left);
                if (n <= 0) continue;
                int r = Os.read(fd, buf, 0, buf.length);
                for (int off = 0; off + 24 <= r; off += 24) {
                    ByteBuffer bb = ByteBuffer.wrap(buf, off + 16, 8).order(ByteOrder.LITTLE_ENDIAN);
                    int type = bb.getShort() & 0xffff;
                    int code = bb.getShort() & 0xffff;
                    int value = bb.getInt();
                    total++;
                    if (type == 3 && code == 0x35) {
                        lastX = value;
                        minX = Math.min(minX, value);
                        maxX = Math.max(maxX, value);
                    } else if (type == 3 && code == 0x36) {
                        lastY = value;
                        minY = Math.min(minY, value);
                        maxY = Math.max(maxY, value);
                    } else if (type == 3 && code == 0x39 && value >= 0) {
                        touches++;
                    }
                }
            }
        } catch (Throwable t) {
            sb.append("読取エラー: ").append(t).append("\n");
        } finally {
            try {
                Os.close(fd);
            } catch (Throwable ignored) {
            }
        }
        sb.append("イベント数=").append(total).append(" 指の接触回数=").append(touches).append("\n");
        if (total > 0 && minX != Integer.MAX_VALUE) {
            sb.append("X範囲 ").append(minX).append("〜").append(maxX)
                    .append(" / Y範囲 ").append(minY).append("〜").append(maxY)
                    .append(" / 最後 (").append(lastX).append(",").append(lastY).append(")\n");
        } else {
            sb.append("イベントが来ませんでした（画面を触りましたか？）\n");
        }
        return sb.toString();
    }

    private static Object inputManager() throws Exception {
        try {
            Class<?> c = Class.forName("android.hardware.input.InputManagerGlobal");
            return c.getMethod("getInstance").invoke(null);
        } catch (Throwable ignored) {
        }
        Class<?> c = Class.forName("android.hardware.input.InputManager");
        return c.getMethod("getInstance").invoke(null);
    }

    @Override
    public String inject(int x, int y) {
        try {
            Object im = inputManager();
            Method m = im.getClass().getMethod("injectInputEvent", InputEvent.class, int.class);
            long now = SystemClock.uptimeMillis();
            MotionEvent down = MotionEvent.obtain(now, now, MotionEvent.ACTION_DOWN, x, y, 0);
            down.setSource(InputDevice.SOURCE_TOUCHSCREEN);
            Object r1 = m.invoke(im, down, 0);
            Thread.sleep(60);
            long t2 = SystemClock.uptimeMillis();
            MotionEvent up = MotionEvent.obtain(now, t2, MotionEvent.ACTION_UP, x, y, 0);
            up.setSource(InputDevice.SOURCE_TOUCHSCREEN);
            Object r2 = m.invoke(im, up, 0);
            down.recycle();
            up.recycle();
            return "注入 (" + x + "," + y + ") down=" + r1 + " up=" + r2 + "\n使用クラス: " + im.getClass().getName();
        } catch (InvocationTargetException e) {
            return "注入失敗: " + e.getCause();
        } catch (Throwable t) {
            return "注入失敗: " + t;
        }
    }
}
