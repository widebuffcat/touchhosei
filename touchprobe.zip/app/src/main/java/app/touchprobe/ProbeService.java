package app.touchprobe;

import android.os.Build;
import android.os.Process;
import android.os.SystemClock;
import android.system.Os;
import android.system.OsConstants;
import android.system.StructPollfd;
import android.view.InputDevice;
import android.view.InputEvent;
import android.view.MotionEvent;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;

/** Shizukuのユーザーサービス。shell権限のプロセスで動く。 */
public class ProbeService extends IProbeService.Stub {

    public ProbeService() {
    }

    @Override
    public void destroy() {
        System.exit(0);
    }

    private static String readText(String path) {
        try (BufferedReader r = new BufferedReader(new FileReader(path))) {
            String s = r.readLine();
            return s == null ? "" : s.trim();
        } catch (Throwable t) {
            return "";
        }
    }

    // ABS_MT_POSITION_X(0x35=53)のビットが立っているか(64bitカーネル前提)
    private static boolean hasMt(String abs) {
        try {
            String[] t = abs.trim().split("\\s+");
            long w = Long.parseUnsignedLong(t[t.length - 1], 16);
            return ((w >>> 53) & 1L) == 1L;
        } catch (Throwable t) {
            return false;
        }
    }

    private static File[] eventFiles() {
        File[] fs = new File("/dev/input").listFiles();
        if (fs == null) return new File[0];
        Arrays.sort(fs);
        return fs;
    }

    private static String geteventRaw(String path) {
        StringBuilder sb = new StringBuilder();
        try {
            java.lang.Process p = new ProcessBuilder("getevent", "-lp", path)
                    .redirectErrorStream(true).start();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line).append("\n");
            }
            p.destroy();
        } catch (Throwable t) {
            sb.append("getevent失敗: ").append(t).append("\n");
        }
        return sb.toString();
    }

    private static String devName(String raw) {
        for (String line : raw.split("\n")) {
            int i = line.indexOf("name:");
            if (i >= 0) return line.substring(i + 5).trim();
        }
        return "?";
    }

    @Override
    public String probe() {
        StringBuilder sb = new StringBuilder();
        sb.append("uid=").append(Process.myUid()).append("（2000ならshell）\n");
        sb.append("Android SDK=").append(Build.VERSION.SDK_INT).append("\n");
        File[] fs = eventFiles();
        if (fs.length == 0) sb.append("/dev/input を列挙できません\n");
        for (File f : fs) {
            String n = f.getName();
            if (!n.startsWith("event")) continue;
            String raw = geteventRaw(f.getPath());
            boolean mt = raw.contains("ABS_MT_POSITION_X");
            sb.append(n).append(" 読取=").append(f.canRead() ? "可" : "不可")
                    .append(" 名前=").append(devName(raw))
                    .append(mt ? "  ★タッチ候補" : "").append("\n");
        }
        return sb.toString();
    }

    private static String findTouchPath() {
        for (File f : eventFiles()) {
            String n = f.getName();
            if (!n.startsWith("event")) continue;
            if (geteventRaw(f.getPath()).contains("ABS_MT_POSITION_X")) {
                return f.getPath();
            }
        }
        return null;
    }

    private static String getevent(String path) {
        StringBuilder sb = new StringBuilder();
        try {
            java.lang.Process p = new ProcessBuilder("getevent", "-lp", path)
                    .redirectErrorStream(true).start();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = r.readLine()) != null) {
                    if (line.contains("POSITION_") || line.contains("name:")) {
                        sb.append("  ").append(line.trim()).append("\n");
                    }
                }
            }
            p.destroy();
        } catch (Throwable t) {
            sb.append("  getevent失敗: ").append(t).append("\n");
        }
        return sb.toString();
    }

    @Override
    public String readTouch(int ms) {
        String path = findTouchPath();
        if (path == null) return "タッチデバイスが見つかりません（先に入力デバイス調査を）";
        StringBuilder sb = new StringBuilder();
        sb.append("対象: ").append(path).append("\n").append(getevent(path));
        FileDescriptor fd = null;
        try {
            fd = Os.open(path, OsConstants.O_RDONLY, 0);
        } catch (Throwable t) {
            return sb.append("open失敗: ").append(t).toString();
        }
        int total = 0, touches = 0;
        int minX = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE;
        int minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
        int lastX = -1, lastY = -1;
        byte[] buf = new byte[24 * 64];
        long end = SystemClock.uptimeMillis() + ms;
        try {
            StructPollfd p = new StructPollfd();
            p.fd = fd;
            p.events = (short) OsConstants.POLLIN;
            while (true) {
                long left = end - SystemClock.uptimeMillis();
                if (left <= 0) break;
                int n = Os.poll(new StructPollfd[]{p}, (int) left);
                if (n <= 0) continue;
                int r = Os.read(fd, buf, 0, buf.length);
                for (int off = 0; off + 24 <= r; off += 24) {
                    ByteBuffer bb = ByteBuffer.wrap(buf, off + 16, 8).order(ByteOrder.LITTLE_ENDIAN);
                    int type = bb.getShort() & 0xffff;
                    int code = bb.getShort() & 0xffff;
                    int value = bb.getInt();
                    total++;
                    if (type == 3 && code == 0x35) {
                        lastX = value;
                        minX = Math.min(minX, value);
                        maxX = Math.max(maxX, value);
                    } else if (type == 3 && code == 0x36) {
                        lastY = value;
                        minY = Math.min(minY, value);
                        maxY = Math.max(maxY, value);
                    } else if (type == 3 && code == 0x39 && value >= 0) {
                        touches++;
                    }
                }
            }
        } catch (Throwable t) {
            sb.append("読取エラー: ").append(t).append("\n");
        } finally {
            try {
                Os.close(fd);
            } catch (Throwable ignored) {
            }
        }
        sb.append("イベント数=").append(total).append(" 指の接触回数=").append(touches).append("\n");
        if (total > 0 && minX != Integer.MAX_VALUE) {
            sb.append("X範囲 ").append(minX).append("〜").append(maxX)
                    .append(" / Y範囲 ").append(minY).append("〜").append(maxY)
                    .append(" / 最後 (").append(lastX).append(",").append(lastY).append(")\n");
        } else {
            sb.append("イベントが来ませんでした（画面を触りましたか？）\n");
        }
        return sb.toString();
    }

    private static Object inputManager() throws Exception {
        try {
            Class<?> c = Class.forName("android.hardware.input.InputManagerGlobal");
            return c.getMethod("getInstance").invoke(null);
        } catch (Throwable ignored) {
        }
        Class<?> c = Class.forName("android.hardware.input.InputManager");
        return c.getMethod("getInstance").invoke(null);
    }

    @Override
    public String inject(int x, int y) {
        try {
            Object im = inputManager();
            Method m = im.getClass().getMethod("injectInputEvent", InputEvent.class, int.class);
            long now = SystemClock.uptimeMillis();
            MotionEvent down = MotionEvent.obtain(now, now, MotionEvent.ACTION_DOWN, x, y, 0);
            down.setSource(InputDevice.SOURCE_TOUCHSCREEN);
            Object r1 = m.invoke(im, down, 0);
            Thread.sleep(60);
            long t2 = SystemClock.uptimeMillis();
            MotionEvent up = MotionEvent.obtain(now, t2, MotionEvent.ACTION_UP, x, y, 0);
            up.setSource(InputDevice.SOURCE_TOUCHSCREEN);
            Object r2 = m.invoke(im, up, 0);
            down.recycle();
            up.recycle();
            return "注入 (" + x + "," + y + ") down=" + r1 + " up=" + r2 + "\n使用クラス: " + im.getClass().getName();
        } catch (InvocationTargetException e) {
            return "注入失敗: " + e.getCause();
        } catch (Throwable t) {
            return "注入失敗: " + t;
        }
    }

    // ---------- ここから占有・補正再注入 ----------

    private static boolean nativeLoaded = false;
    private static String libDir = "";
    private Object imObj;
    private Method injM;

    @Override
    public String setLibDir(String dir) {
        libDir = dir == null ? "" : dir;
        return libDir;
    }

    private static String ensureNative() {
        if (nativeLoaded) return null;
        if (libDir.isEmpty()) return "ライブラリの場所が未設定です（接続し直してください）";
        StringBuilder e = new StringBuilder();
        File src = new File(libDir, "libtouchnative.so");
        try {
            System.load(src.getPath());
            nativeLoaded = true;
            return null;
        } catch (Throwable t) {
            e.append("直接load失敗: ").append(t).append("\n");
        }
        try {
            File dst = new File("/data/local/tmp/libtouchnative.so");
            Files.copy(src.toPath(), dst.toPath(), StandardCopyOption.REPLACE_EXISTING);
            dst.setReadable(true, false);
            System.load(dst.getPath());
            nativeLoaded = true;
            return null;
        } catch (Throwable t) {
            e.append("tmp経由も失敗: ").append(t).append("\n");
        }
        return e.toString();
    }

    private void initInject() throws Exception {
        if (imObj != null) return;
        Object im = inputManager();
        injM = im.getClass().getMethod("injectInputEvent", InputEvent.class, int.class);
        imObj = im;
    }

    @Override
    public String grabTest(int ms) {
        String err = ensureNative();
        if (err != null) return err;
        String path = findTouchPath();
        if (path == null) return "タッチデバイスが見つかりません";
        int fd = Native.nOpen(path);
        if (fd < 0) return "open失敗 errno=" + (-fd);
        int g = Native.nGrab(fd, 1);
        if (g != 0) {
            Native.nClose(fd);
            return "占有失敗 errno=" + g;
        }
        int total = 0;
        byte[] buf = new byte[24 * 64];
        long end = SystemClock.uptimeMillis() + ms;
        try {
            while (SystemClock.uptimeMillis() < end) {
                int r = Native.nRead(fd, buf, 100);
                if (r < 0) return "読取エラー errno=" + (-r);
                total += r / 24;
            }
        } finally {
            Native.nGrab(fd, 0);
            Native.nClose(fd);
        }
        return "占有成功。この間のイベント " + total + " 件を横取りしました。\n"
                + "（この間、画面を触ってもアプリは反応しなかったはずです）";
    }

    private final class Pipe {
        // 画面の大きさ（このテストでは固定。生座標の範囲が 0〜1080 / 0〜2460 だったため）
        static final int MAXX = 1079;
        static final int MAXY = 2459;

        final boolean[] act = new boolean[16];
        final int[] px = new int[16];
        final int[] py = new int[16];
        int cur, pendDown, pendUp;
        boolean movedExisting;
        long downTime;
        int dx, dy, injected, fails;
        int lastRx = -1, lastRy = -1, lastCx = -1, lastCy = -1;
        String lastErr = "";

        void feed(int type, int code, int value) {
            if (type == 3) {
                if (code == 0x2f) {
                    cur = Math.max(0, Math.min(15, value));
                } else if (code == 0x39) {
                    if (value >= 0) {
                        if (!act[cur]) pendDown |= 1 << cur;
                    } else {
                        if (act[cur] || ((pendDown >> cur) & 1) == 1) pendUp |= 1 << cur;
                    }
                } else if (code == 0x35) {
                    px[cur] = value;
                    if (act[cur]) movedExisting = true;
                } else if (code == 0x36) {
                    py[cur] = value;
                    if (act[cur]) movedExisting = true;
                }
            } else if (type == 0 && code == 0) {
                flush();
            }
        }

        void flush() {
            for (int i = 0; i < 16; i++) {
                if (((pendDown >> i) & 1) == 1) {
                    act[i] = true;
                    send(0, i);
                }
            }
            if (movedExisting) send(2, -1);
            for (int i = 0; i < 16; i++) {
                if (((pendUp >> i) & 1) == 1 && act[i]) {
                    send(1, i);
                    act[i] = false;
                }
            }
            pendDown = 0;
            pendUp = 0;
            movedExisting = false;
        }

        void cancelAll() {
            boolean any = false;
            for (boolean b : act) any |= b;
            if (any) {
                send(3, -1);
                java.util.Arrays.fill(act, false);
            }
        }

        // kind: 0=down 1=up 2=move 3=cancel
        void send(int kind, int slot) {
            int n = 0, idx = 0;
            int[] ids = new int[16];
            for (int i = 0; i < 16; i++) {
                if (act[i]) {
                    if (i == slot) idx = n;
                    ids[n++] = i;
                }
            }
            if (n == 0) return;
            MotionEvent.PointerProperties[] pp = new MotionEvent.PointerProperties[n];
            MotionEvent.PointerCoords[] pc = new MotionEvent.PointerCoords[n];
            for (int k = 0; k < n; k++) {
                pp[k] = new MotionEvent.PointerProperties();
                pp[k].id = ids[k];
                pp[k].toolType = MotionEvent.TOOL_TYPE_FINGER;
                pc[k] = new MotionEvent.PointerCoords();
                pc[k].x = Math.max(0, Math.min(MAXX, px[ids[k]] + dx));
                pc[k].y = Math.max(0, Math.min(MAXY, py[ids[k]] + dy));
                pc[k].pressure = 1f;
                pc[k].size = 1f;
            }
            int action;
            switch (kind) {
                case 0:
                    action = n == 1 ? MotionEvent.ACTION_DOWN
                            : (MotionEvent.ACTION_POINTER_DOWN | (idx << MotionEvent.ACTION_POINTER_INDEX_SHIFT));
                    break;
                case 1:
                    action = n == 1 ? MotionEvent.ACTION_UP
                            : (MotionEvent.ACTION_POINTER_UP | (idx << MotionEvent.ACTION_POINTER_INDEX_SHIFT));
                    break;
                case 2:
                    action = MotionEvent.ACTION_MOVE;
                    break;
                default:
                    action = MotionEvent.ACTION_CANCEL;
                    break;
            }
            long now = SystemClock.uptimeMillis();
            if (kind == 0 && n == 1) downTime = now;
            MotionEvent ev = MotionEvent.obtain(downTime, now, action, n, pp, pc,
                    0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0);
            try {
                injM.invoke(imObj, ev, 0);
                injected++;
            } catch (Throwable t) {
                fails++;
                lastErr = String.valueOf(t);
            } finally {
                ev.recycle();
            }
            lastRx = px[ids[idx]];
            lastRy = py[ids[idx]];
            lastCx = (int) pc[idx].x;
            lastCy = (int) pc[idx].y;
        }
    }

    @Override
    public String correct(int ms, int dx, int dy) {
        String err = ensureNative();
        if (err != null) return err;
        String path = findTouchPath();
        if (path == null) return "タッチデバイスが見つかりません";
        try {
            initInject();
        } catch (Throwable t) {
            return "注入の準備に失敗: " + t;
        }
        int fd = Native.nOpen(path);
        if (fd < 0) return "open失敗 errno=" + (-fd);
        int g = Native.nGrab(fd, 1);
        if (g != 0) {
            Native.nClose(fd);
            return "占有失敗 errno=" + g;
        }
        Pipe pipe = new Pipe();
        pipe.dx = dx;
        pipe.dy = dy;
        String readErr = "";
        byte[] buf = new byte[24 * 64];
        long end = SystemClock.uptimeMillis() + ms;
        try {
            while (SystemClock.uptimeMillis() < end) {
                int r = Native.nRead(fd, buf, 100);
                if (r < 0) {
                    readErr = "読取エラー errno=" + (-r) + "\n";
                    break;
                }
                for (int off = 0; off + 24 <= r; off += 24) {
                    ByteBuffer bb = ByteBuffer.wrap(buf, off + 16, 8).order(ByteOrder.LITTLE_ENDIAN);
                    int type = bb.getShort() & 0xffff;
                    int code = bb.getShort() & 0xffff;
                    int value = bb.getInt();
                    pipe.feed(type, code, value);
                }
            }
            pipe.cancelAll();
        } finally {
            Native.nGrab(fd, 0);
            Native.nClose(fd);
        }
        StringBuilder sb = new StringBuilder();
        sb.append(readErr);
        sb.append("補正 dx=").append(dx).append(" dy=").append(dy).append("\n");
        sb.append("注入 ").append(pipe.injected).append(" 回 / 失敗 ").append(pipe.fails).append(" 回\n");
        if (pipe.lastRx >= 0) {
            sb.append("最後の座標: 生(").append(pipe.lastRx).append(",").append(pipe.lastRy)
                    .append(") → 補正後(").append(pipe.lastCx).append(",").append(pipe.lastCy).append(")\n");
        } else {
            sb.append("タッチは検出されませんでした\n");
        }
        if (!pipe.lastErr.isEmpty()) sb.append("注入エラー: ").append(pipe.lastErr).append("\n");
        return sb.toString();
    }
}
