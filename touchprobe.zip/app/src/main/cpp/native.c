#include <jni.h>
#include <fcntl.h>
#include <unistd.h>
#include <poll.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <linux/input.h>

JNIEXPORT jint JNICALL
Java_app_touchprobe_Native_nOpen(JNIEnv *env, jclass cls, jstring jpath) {
    const char *path = (*env)->GetStringUTFChars(env, jpath, NULL);
    int fd = open(path, O_RDONLY | O_CLOEXEC);
    int e = errno;
    (*env)->ReleaseStringUTFChars(env, jpath, path);
    return fd < 0 ? -e : fd;
}

JNIEXPORT jint JNICALL
Java_app_touchprobe_Native_nGrab(JNIEnv *env, jclass cls, jint fd, jint on) {
    if (ioctl(fd, EVIOCGRAB, (long) on) < 0) return errno;
    return 0;
}

JNIEXPORT jint JNICALL
Java_app_touchprobe_Native_nRead(JNIEnv *env, jclass cls, jint fd, jbyteArray arr, jint timeoutMs) {
    struct pollfd p;
    p.fd = fd;
    p.events = POLLIN;
    p.revents = 0;
    int r = poll(&p, 1, timeoutMs);
    if (r < 0) return errno == EINTR ? 0 : -errno;
    if (r == 0) return 0;
    jbyte *buf = (*env)->GetByteArrayElements(env, arr, NULL);
    jsize len = (*env)->GetArrayLength(env, arr);
    ssize_t n = read(fd, buf, (size_t) len);
    int e = errno;
    (*env)->ReleaseByteArrayElements(env, arr, buf, 0);
    if (n < 0) return e == EINTR ? 0 : -e;
    return (jint) n;
}

JNIEXPORT void JNICALL
Java_app_touchprobe_Native_nClose(JNIEnv *env, jclass cls, jint fd) {
    close(fd);
}
