package app.tapfix;

interface ITapService {
    void destroy() = 16777114;
    String setLibDir(String dir) = 1;
    String start(int w, int h, in float[] xs, in float[] ys, in float[] dx, in float[] dy) = 2;
    String stop() = 3;
    String status() = 4;
}
