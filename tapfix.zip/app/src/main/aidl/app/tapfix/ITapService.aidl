package app.tapfix;

interface ITapService {
    void destroy() = 16777114;
    String setLibDir(String dir) = 1;
    String start(int w, int h, in float[] xs, in float[] ys, in float[] dx, in float[] dy, int slop, float offX, float offY, int avgMs) = 2;
    String stop() = 3;
    String status() = 4;
    void setSlop(int px) = 5;
    float[] points() = 6;
    void setOffset(float offX, float offY) = 7;
    void setAvg(int ms) = 8;
    boolean setTilt(float roll, float pitch) = 9;
    void setTiltModel(in float[] model) = 10;
    void setLandscape(in float[] xs, in float[] ys, in float[] dx, in float[] dy, float offX, float offY) = 11;
    void setLandOffset(float offX, float offY) = 12;
}
