package app.tapfix;

interface ITapService {
    void destroy() = 16777114;
    String setLibDir(String dir) = 1;
    String start(int w, int h, in float[] xs, in float[] ys, in float[] dx, in float[] dy, int slop, float offX, float offY, int avgMs) = 2;
    String stop() = 3;
    String status() = 4;
    void setSlop(int px) = 5;
    float[] points() = 6;
    void setOffset(float offX, float offY) = 7;
    void setAvg(int ms) = 8;
}
