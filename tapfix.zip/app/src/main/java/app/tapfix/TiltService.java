package app.tapfix;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;

import rikka.shizuku.Shizuku;

/**
 * 端末の傾きとジャイロを読み取り、補正本体（Shizuku常駐）へ送り続ける前面サービス。
 * センサーはアプリ側でしか読めないため、止まらないよう自己修復を強めている。
 */
public class TiltService extends Service {

    static volatile boolean running = false;

    private final TiltSensor sensor = new TiltSensor();
    private volatile ITapService svc;
    private boolean bound = false;
    private long lastSend = 0, lastBind = 0;
    private long lastSensorOk = 0;
    private long lastGyroOk = 0;
    private volatile boolean alive = false;
    private Thread health;

    // ジャイロ：直近1秒の回転の大きさ(rad/s, 二乗平均平方根)
    private SensorManager gsm;
    private HandlerThread gthread;
    private Handler gHandler;
    private Sensor gyroSensor;
    private final long[] gT = new long[256];
    private final float[] gV = new float[256];
    private int gHead = 0, gCount = 0;
    private volatile float gyroRms = -1f;
    private final SensorEventListener gyroListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent e) {
            float[] v = e.values;
            if (v == null || v.length < 3) return;
            long now = SystemClock.uptimeMillis();
            lastGyroOk = now;
            synchronized (gT) {
                gT[gHead] = now;
                gV[gHead] = v[0] * v[0] + v[1] * v[1] + v[2] * v[2];
                gHead = (gHead + 1) % gT.length;
                if (gCount < gT.length) gCount++;
                double sum = 0;
                int n = 0;
                for (int i = 0; i < gCount; i++) {
                    int k = (gHead - 1 - i + gT.length) % gT.length;
                    if (now - gT[k] > 1000) break;
                    sum += gV[k];
                    n++;
                }
                gyroRms = n >= 5 ? (float) Math.sqrt(sum / n) : -1f;
            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }
    };

    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            svc = ITapService.Stub.asInterface(binder);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            svc = null;
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // システムに止められても再起動してもらう
        if (!running || !alive) {
            // 二重起動時もセンサーを確実に張る
            ensureSensors();
        }
        return START_STICKY;
    }

    private Shizuku.UserServiceArgs args() {
        int vc = 1;
        try {
            vc = getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Throwable ignored) {
        }
        return new Shizuku.UserServiceArgs(new ComponentName(getPackageName(), TapService.class.getName()))
                .daemon(true)
                .processNameSuffix("tapfix")
                .version(vc);
    }

    private void startAsForeground() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(
                    "tilt", "傾きの監視", NotificationManager.IMPORTANCE_LOW));
            Notification n = new Notification.Builder(this, "tilt")
                    .setSmallIcon(android.R.drawable.ic_menu_compass)
                    .setContentTitle("傾きを監視中（補正と連携）")
                    .setOngoing(true)
                    .build();
            startForeground(2, n);
        } catch (Throwable ignored) {
        }
    }

    private void rebind() {
        try {
            Shizuku.unbindUserService(args(), conn, false);
        } catch (Throwable ignored) {
        }
        try {
            Shizuku.bindUserService(args(), conn);
            bound = true;
            lastBind = SystemClock.uptimeMillis();
        } catch (Throwable ignored) {
        }
    }

    /** 傾きセンサーとジャイロを張り直す（Dozeや一時停止からの復帰用） */
    private synchronized void ensureSensors() {
        long now = SystemClock.uptimeMillis();
        // 傾き
        if (!sensor.valid || now - lastSensorOk > 4000) {
            try {
                sensor.stop();
            } catch (Throwable ignored) {
            }
            if (sensor.start(this, this::onTilt)) {
                lastSensorOk = now;
            }
        }
        // ジャイロ
        try {
            if (gsm == null) {
                gsm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
            }
            if (gyroSensor == null && gsm != null) {
                gyroSensor = gsm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
            }
            if (gyroSensor != null) {
                if (gthread == null || !gthread.isAlive()) {
                    try {
                        if (gsm != null) gsm.unregisterListener(gyroListener);
                    } catch (Throwable ignored) {
                    }
                    gthread = new HandlerThread("tapfix-gyro");
                    gthread.start();
                    gHandler = new Handler(gthread.getLooper());
                    gsm.registerListener(gyroListener, gyroSensor,
                            SensorManager.SENSOR_DELAY_GAME, gHandler);
                    lastGyroOk = now;
                } else if (now - lastGyroOk > 5000) {
                    // イベントが来なくなった → 付け直す
                    try {
                        gsm.unregisterListener(gyroListener);
                    } catch (Throwable ignored) {
                    }
                    gsm.registerListener(gyroListener, gyroSensor,
                            SensorManager.SENSOR_DELAY_GAME, gHandler);
                    lastGyroOk = now;
                }
            }
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        alive = true;
        startAsForeground();
        lastBind = SystemClock.uptimeMillis();
        lastSensorOk = lastBind;
        lastGyroOk = lastBind;
        try {
            Shizuku.bindUserService(args(), conn);
            bound = true;
        } catch (Throwable ignored) {
        }
        ensureSensors();
        // 定期ヘルスチェック：接続切れ・センサー沈黙を自動修復
        health = new Thread(() -> {
            while (alive) {
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    break;
                }
                if (!alive) break;
                long now = SystemClock.uptimeMillis();
                if (svc == null && now - lastBind > 2500) {
                    rebind();
                }
                ensureSensors();
            }
        }, "tapfix-tilt-health");
        health.setDaemon(true);
        health.start();
    }

    // センサーの更新ごとに呼ばれる（センサー用スレッド）
    private void onTilt(float roll, float pitch) {
        lastSensorOk = SystemClock.uptimeMillis();
        long now = lastSensorOk;
        if (now - lastSend < 30) return;
        lastSend = now;
        ITapService s = svc;
        if (s == null) {
            if (now - lastBind > 2500) {
                rebind();
            }
            return;
        }
        try {
            s.setTilt(roll, pitch);
            float gr = gyroRms;
            if (gr >= 0f) s.setMotion(gr);
            // 補正が止まっていてもセンサー自体は止めない（常駐を優先）
        } catch (Throwable t) {
            svc = null;
        }
    }

    @Override
    public void onDestroy() {
        alive = false;
        running = false;
        if (health != null) health.interrupt();
        sensor.stop();
        try {
            if (gsm != null) gsm.unregisterListener(gyroListener);
            if (gthread != null) gthread.quitSafely();
        } catch (Throwable ignored) {
        }
        gsm = null;
        gthread = null;
        gHandler = null;
        gyroSensor = null;
        if (bound) {
            try {
                Shizuku.unbindUserService(args(), conn, false);
            } catch (Throwable ignored) {
            }
        }
        super.onDestroy();
    }
}
