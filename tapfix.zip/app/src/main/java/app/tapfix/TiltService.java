package app.tapfix;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.SystemClock;

import rikka.shizuku.Shizuku;

/**
 * 補正中、端末の傾きを読み取って、補正の本体（Shizukuの常駐サービス）へ送り続ける。
 * センサーはアプリ側でしか読めないので、前面サービスにして止められにくくしている。
 */
public class TiltService extends Service {

    static volatile boolean running = false;

    private final TiltSensor sensor = new TiltSensor();
    private volatile ITapService svc;
    private boolean bound = false;
    private long lastSend = 0, lastBind = 0;
    private int idle = 0;

    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            svc = ITapService.Stub.asInterface(binder);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            svc = null;
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    private Shizuku.UserServiceArgs args() {
        int vc = 1;
        try {
            vc = getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Throwable ignored) {
        }
        return new Shizuku.UserServiceArgs(new ComponentName(getPackageName(), TapService.class.getName()))
                .daemon(true)
                .processNameSuffix("tapfix")
                .version(vc);
    }

    private void startAsForeground() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(
                    "tilt", "傾きの監視", NotificationManager.IMPORTANCE_LOW));
            Notification n = new Notification.Builder(this, "tilt")
                    .setSmallIcon(android.R.drawable.ic_menu_compass)
                    .setContentTitle("傾きを監視中（補正と連携）")
                    .setOngoing(true)
                    .build();
            startForeground(2, n);
        } catch (Throwable ignored) {
        }
    }

    private void rebind() {
        try {
            Shizuku.unbindUserService(args(), conn, false);
        } catch (Throwable ignored) {
        }
        try {
            Shizuku.bindUserService(args(), conn);
            bound = true;
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        startAsForeground();
        lastBind = SystemClock.uptimeMillis();
        try {
            Shizuku.bindUserService(args(), conn);
            bound = true;
        } catch (Throwable ignored) {
        }
        if (!sensor.start(this, this::onTilt)) {
            running = false;
            stopSelf();
        }
    }

    // センサーの更新ごとに呼ばれる（センサー用スレッド）
    private void onTilt(float roll, float pitch) {
        long now = SystemClock.uptimeMillis();
        if (now - lastSend < 30) return;
        lastSend = now;
        ITapService s = svc;
        if (s == null) {
            if (now - lastBind > 3000) {
                lastBind = now;
                rebind();
            }
            return;
        }
        try {
            boolean on = s.setTilt(roll, pitch);
            // 補正が止まったままなら、しばらくして自分も止まる
            if (on) idle = 0;
            else if (++idle > 300) stopSelf();
        } catch (Throwable t) {
            svc = null;
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        sensor.stop();
        if (bound) {
            try {
                Shizuku.unbindUserService(args(), conn, false);
            } catch (Throwable ignored) {
            }
        }
        super.onDestroy();
    }
}
