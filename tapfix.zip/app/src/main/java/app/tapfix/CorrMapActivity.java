package app.tapfix;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;

/**
 * 補正データの静的マップ。
 * 各格子点に「タッチ試験（格子）」「傾き」「全体オフセット」の内訳と、適用数式を示す。
 * 数式は通常うすく、点をタップするとその点の数式を明るく前面表示する。
 */
public class CorrMapActivity extends Activity {

    public static final String EXTRA_PROFILE = "profile";
    public static final String EXTRA_MODE = "mode"; // 0=縦 1=机 2=横

    private MapView map;
    private TextView title;
    private TextView legend;
    private int mode = 0;
    private Store.Profile profile;
    private float strength; // 0..1.5
    private boolean useTilt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int idx = getIntent().getIntExtra(EXTRA_PROFILE, -1);
        mode = getIntent().getIntExtra(EXTRA_MODE, 0);
        List<Store.Profile> list = Store.load(this);
        if (idx < 0 || idx >= list.size()) {
            Toast.makeText(this, "補正データがありません", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        profile = list.get(idx);
        strength = Store.getStrength(this) / 100f;
        useTilt = Store.getUseTilt(this) && profile.tilt != null && profile.tilt.length >= 6;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF121212);

        title = new TextView(this);
        title.setTextColor(Color.WHITE);
        title.setTextSize(15);
        title.setPadding(dp(12), dp(10), dp(12), dp(2));
        root.addView(title);

        legend = new TextView(this);
        legend.setTextColor(0xFFB0BEC5);
        legend.setTextSize(11);
        legend.setPadding(dp(12), 0, dp(12), dp(6));
        legend.setText("橙矢印＝タッチ試験（格子）補正　水色＝傾き補正（例: Δroll=+5°, Δpitch=+5°）\n"
                + "緑＝全体オフセット　点の色＝格子ずれの大きさ　薄い字＝数式（点をタップで強調）");
        root.addView(legend);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(dp(8), 0, dp(8), dp(6));
        tabs.addView(tabBtn("縦（手持ち）", 0));
        tabs.addView(tabBtn("机置き", 1));
        tabs.addView(tabBtn("横画面", 2));
        root.addView(tabs);

        map = new MapView(this);
        root.addView(map, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        Button close = new Button(this);
        close.setText("閉じる");
        close.setOnClickListener(v -> finish());
        root.addView(close);

        setContentView(root);
        applyMode(mode);
    }

    private Button tabBtn(String label, int m) {
        Button b = new Button(this);
        b.setText(label);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(2), 0, dp(2), 0);
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> applyMode(m));
        return b;
    }

    private void applyMode(int m) {
        mode = m;
        float[] xs = null, ys = null, dx = null, dy = null;
        float ox = 0, oy = 0;
        int w = profile.w, h = profile.h;
        String kind;
        float[] tilt = null;
        if (m == 1) {
            kind = "机置き";
            xs = profile.deskXs;
            ys = profile.deskYs;
            dx = profile.deskDx;
            dy = profile.deskDy;
            ox = profile.deskOffX;
            oy = profile.deskOffY;
            // 机置きは傾き連携を使わない
        } else if (m == 2) {
            kind = "横画面";
            xs = profile.lxs;
            ys = profile.lys;
            dx = profile.ldx;
            dy = profile.ldy;
            ox = profile.loffX;
            oy = profile.loffY;
            if (profile.lw > 0) {
                w = profile.lw;
                h = profile.lh;
            }
        } else {
            kind = "縦（手持ち）";
            xs = profile.xs;
            ys = profile.ys;
            dx = profile.dx;
            dy = profile.dy;
            ox = profile.offX;
            oy = profile.offY;
            if (useTilt) tilt = profile.tilt;
        }
        if (xs == null || ys == null || dx == null || dy == null
                || xs.length < 2 || ys.length < 2
                || dx.length != xs.length * ys.length) {
            title.setText(String.format(Locale.US, "「%s」— %sの補正データがありません",
                    profile.name, kind));
            map.setData(null, null, null, null, 0, 0, 0, 0, null, strength, kind);
            return;
        }
        float max = 0;
        for (int i = 0; i < dx.length; i++) {
            max = Math.max(max, (float) Math.hypot(dx[i], dy[i]));
        }
        title.setText(String.format(Locale.US,
                "「%s」— %s　%dx%d　格子最大 %.1fpx　強さ %.0f%%　オフセット (%+.0f,%+.0f)%s",
                profile.name, kind, xs.length, ys.length, max, strength * 100f, ox, oy,
                tilt != null ? "　傾きモデルあり" : ""));
        map.setData(xs, ys, dx, dy, w, h, ox, oy, tilt, strength, kind);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static final class MapView extends View {
        private float[] xs, ys, dx, dy, tilt;
        private int dataW, dataH;
        private float offX, offY, strength;
        private String kind = "";
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final float dens;
        private int selI = -1, selJ = -1;
        private float mapL, mapT, mapR, mapB, sx, sy;

        // 傾きの説明用サンプル（実際の注入時は押下瞬間の傾きを使う）
        private static final float SAMPLE_DR = 5f;
        private static final float SAMPLE_DP = 5f;
        private static final float TILT_LAMBDA = 0.40f;

        MapView(Context c) {
            super(c);
            dens = c.getResources().getDisplayMetrics().density;
            setBackgroundColor(0xFF1A1A1A);
            setClickable(true);
        }

        void setData(float[] xs, float[] ys, float[] dx, float[] dy,
                     int w, int h, float ox, float oy, float[] tilt,
                     float strength, String kind) {
            this.xs = xs;
            this.ys = ys;
            this.dx = dx;
            this.dy = dy;
            this.dataW = Math.max(1, w);
            this.dataH = Math.max(1, h);
            this.offX = ox;
            this.offY = oy;
            this.tilt = tilt;
            this.strength = strength;
            this.kind = kind == null ? "" : kind;
            this.selI = -1;
            this.selJ = -1;
            invalidate();
        }

        private float strengthCurve(float s) {
            s = s < 0 ? 0 : (s > 1.5f ? 1.5f : s);
            float c = s > 1f ? 1f : s;
            return (float) Math.pow(c, 1.30) * (s > 1f ? s : 1f);
        }

        private float[] tiltDeltaPx() {
            if (tilt == null || tilt.length < 6) return new float[]{0, 0};
            float tdx = tilt[0] * SAMPLE_DR + tilt[1] * SAMPLE_DP;
            float tdy = tilt[2] * SAMPLE_DR + tilt[3] * SAMPLE_DP;
            float cap = 36f; // pxScale≈1 前提の表示用
            if (tdx > cap) tdx = cap;
            else if (tdx < -cap) tdx = -cap;
            if (tdy > cap) tdy = cap;
            else if (tdy < -cap) tdy = -cap;
            return new float[]{tdx, tdy};
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() != MotionEvent.ACTION_DOWN || xs == null) return true;
            float x = e.getX(), y = e.getY();
            int bestI = -1, bestJ = -1;
            float best = 40 * dens;
            for (int j = 0; j < ys.length; j++) {
                for (int i = 0; i < xs.length; i++) {
                    float px = mapL + xs[i] * sx;
                    float py = mapT + ys[j] * sy;
                    float d = (float) Math.hypot(px - x, py - y);
                    if (d < best) {
                        best = d;
                        bestI = i;
                        bestJ = j;
                    }
                }
            }
            if (bestI >= 0) {
                if (selI == bestI && selJ == bestJ) {
                    selI = selJ = -1; // 再タップで解除
                } else {
                    selI = bestI;
                    selJ = bestJ;
                }
                invalidate();
            }
            return true;
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            int vw = getWidth(), vh = getHeight();
            if (vw <= 0 || vh <= 0) return;

            float barW = 16 * dens;
            float barPad = 8 * dens;
            mapR = vw - barW - barPad * 2;
            mapB = vh - 22 * dens;
            mapL = 10 * dens;
            mapT = 10 * dens;
            float mapW = mapR - mapL, mapH = mapB - mapT;

            // カラーバー
            for (int i = 0; i < 80; i++) {
                float t = i / 79f;
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(heat(t));
                float y0 = mapT + mapH * (1f - t);
                float y1 = mapT + mapH * (1f - (i + 1) / 79f);
                c.drawRect(mapR + barPad, y1, mapR + barPad + barW, y0 + 1, paint);
            }
            paint.setColor(Color.WHITE);
            paint.setTextSize(9 * dens);
            paint.setTextAlign(Paint.Align.CENTER);
            c.drawText("大", mapR + barPad + barW / 2, mapT + 10 * dens, paint);
            c.drawText("小", mapR + barPad + barW / 2, mapB, paint);

            if (xs == null) {
                paint.setColor(0xFF90A4AE);
                paint.setTextSize(14 * dens);
                c.drawText("このモードの補正データがありません", vw / 2f, vh / 2f, paint);
                return;
            }

            sx = mapW / dataW;
            sy = mapH / dataH;

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2 * dens);
            paint.setColor(0xFF455A64);
            c.drawRect(mapL, mapT, mapR, mapB, paint);

            int cols = xs.length, rows = ys.length;
            float st = strengthCurve(strength);
            float[] tSample = tiltDeltaPx();
            float tiltGx = tSample[0] * st * TILT_LAMBDA;
            float tiltGy = tSample[1] * st * TILT_LAMBDA;

            // スケール：格子＋傾きサンプル＋オフセットを考慮
            float maxLen = 1f;
            for (int j = 0; j < rows; j++) {
                for (int i = 0; i < cols; i++) {
                    int k = j * cols + i;
                    float gx = dx[k] * st, gy = dy[k] * st;
                    float len = (float) Math.hypot(gx + tiltGx + offX, gy + tiltGy + offY);
                    if (len > maxLen) maxLen = len;
                    float glen = (float) Math.hypot(gx, gy);
                    if (glen > maxLen) maxLen = glen;
                }
            }
            float maxArrow = Math.min(mapW, mapH) * 0.11f;
            float unit = maxLen > 1e-3f ? maxArrow / maxLen : 0f;

            // 格子線
            paint.setStrokeWidth(1 * dens);
            paint.setColor(0x28FFFFFF);
            for (float x : xs) {
                float px = mapL + x * sx;
                c.drawLine(px, mapT, px, mapB, paint);
            }
            for (float y : ys) {
                float py = mapT + y * sy;
                c.drawLine(mapL, py, mapR, py, paint);
            }

            // 全体オフセットの共通表示（左上）
            if (Math.hypot(offX, offY) > 0.3f) {
                float ox0 = mapL + 28 * dens, oy0 = mapT + 28 * dens;
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(0xAA00C853);
                c.drawCircle(ox0, oy0, 4 * dens, paint);
                drawArrow(c, ox0, oy0, ox0 + offX * unit * 1.2f, oy0 + offY * unit * 1.2f,
                        0xFF00E676, 2.2f * dens, 7 * dens);
                paint.setTextAlign(Paint.Align.LEFT);
                paint.setTextSize(10 * dens);
                paint.setColor(0xFF69F0AE);
                c.drawText(String.format(Locale.US, "全体オフセット (%+.0f,%+.0f)", offX, offY),
                        ox0 + 8 * dens, oy0 - 6 * dens, paint);
            }

            paint.setTextSize(8 * dens);
            for (int j = 0; j < rows; j++) {
                for (int i = 0; i < cols; i++) {
                    int k = j * cols + i;
                    float gridX = dx[k] * st;
                    float gridY = dy[k] * st;
                    float gLen = (float) Math.hypot(dx[k], dy[k]);
                    float tNorm = maxLen > 1e-3f ? (float) Math.hypot(gridX, gridY) / maxLen : 0f;
                    if (tNorm > 1f) tNorm = 1f;

                    float x0 = mapL + xs[i] * sx;
                    float y0 = mapT + ys[j] * sy;

                    // 格子ベクトル（橙〜熱）
                    int col = heat(tNorm);
                    paint.setStyle(Paint.Style.FILL);
                    paint.setColor(col);
                    float r = 3f * dens + tNorm * 2.5f * dens;
                    c.drawCircle(x0, y0, r, paint);

                    if (gLen >= 0.4f) {
                        drawArrow(c, x0, y0, x0 + gridX * unit, y0 + gridY * unit,
                                col, 2f * dens + tNorm * dens, 6 * dens);
                    }

                    // 傾きベクトル（水色・少しずらして重なりを減らす）
                    if (tilt != null && (Math.abs(tiltGx) + Math.abs(tiltGy)) > 0.3f) {
                        float ox = 3 * dens, oy = -3 * dens;
                        drawArrow(c, x0 + ox, y0 + oy,
                                x0 + ox + tiltGx * unit, y0 + oy + tiltGy * unit,
                                0xFF40C4FF, 1.6f * dens, 5 * dens);
                    }

                    // 全体オフセット（細い緑、各点にも）
                    if (Math.hypot(offX, offY) > 0.3f) {
                        drawArrow(c, x0, y0, x0 + offX * unit * 0.85f, y0 + offY * unit * 0.85f,
                                0x8800E676, 1.2f * dens, 4 * dens);
                    }

                    // 薄い数式（選択点以外）
                    boolean sel = (i == selI && j == selJ);
                    if (!sel) {
                        String shortF = String.format(Locale.US, "G%+.0f,%+.0f", gridX, gridY);
                        paint.setStyle(Paint.Style.FILL);
                        paint.setTextAlign(Paint.Align.CENTER);
                        paint.setTextSize(7.5f * dens);
                        paint.setColor(0x55FFFFFF);
                        c.drawText(shortF, x0, y0 + r + 10 * dens, paint);
                    }
                }
            }

            // 選択点の明るい数式パネル
            if (selI >= 0 && selJ >= 0 && selI < cols && selJ < rows) {
                int k = selJ * cols + selI;
                float gridX = dx[k] * st;
                float gridY = dy[k] * st;
                float x0 = mapL + xs[selI] * sx;
                float y0 = mapT + ys[selJ] * sy;

                // 選択ハイライト
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2.5f * dens);
                paint.setColor(0xFFFFF59D);
                c.drawCircle(x0, y0, 12 * dens, paint);

                float totalX = gridX + (tilt != null ? tiltGx : 0) + offX;
                float totalY = gridY + (tilt != null ? tiltGy : 0) + offY;

                String[] lines = buildFormulaLines(selI, selJ, xs[selI], ys[selJ],
                        dx[k], dy[k], gridX, gridY, totalX, totalY);

                float panelW = Math.min(mapW - 8 * dens, 300 * dens);
                float lineH = 14 * dens;
                float panelH = 16 * dens + lines.length * lineH;
                float px = x0 + 14 * dens;
                float py = y0 - panelH * 0.35f;
                if (px + panelW > mapR - 4 * dens) px = x0 - panelW - 14 * dens;
                if (py < mapT + 4 * dens) py = mapT + 4 * dens;
                if (py + panelH > mapB - 4 * dens) py = mapB - panelH - 4 * dens;

                RectF box = new RectF(px, py, px + panelW, py + panelH);
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(0xF0F5F5F5);
                c.drawRoundRect(box, 8 * dens, 8 * dens, paint);
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(1.5f * dens);
                paint.setColor(0xFFFFC107);
                c.drawRoundRect(box, 8 * dens, 8 * dens, paint);

                paint.setStyle(Paint.Style.FILL);
                paint.setTextAlign(Paint.Align.LEFT);
                paint.setTextSize(11 * dens);
                float ty = py + 14 * dens;
                for (int li = 0; li < lines.length; li++) {
                    if (li == 0) paint.setColor(0xFF212121);
                    else if (lines[li].startsWith("　傾き")) paint.setColor(0xFF0277BD);
                    else if (lines[li].startsWith("　オフ")) paint.setColor(0xFF2E7D32);
                    else if (lines[li].startsWith("　格子") || lines[li].startsWith("　タッチ"))
                        paint.setColor(0xFFE65100);
                    else if (lines[li].startsWith("合計") || lines[li].startsWith("out"))
                        paint.setColor(0xFFB71C1C);
                    else paint.setColor(0xFF424242);
                    paint.setTextSize(li == 0 ? 12 * dens : 10.5f * dens);
                    c.drawText(lines[li], px + 8 * dens, ty, paint);
                    ty += lineH;
                }
            }

            // フッター凡例
            paint.setStyle(Paint.Style.FILL);
            paint.setTextAlign(Paint.Align.LEFT);
            paint.setTextSize(10 * dens);
            paint.setColor(0xFF90A4AE);
            String foot = String.format(Locale.US,
                    "s'=s^1.3 (s=%.2f)  λ=%.2f  傾き例 Δr=%+.0f° Δp=%+.0f°  ※実運用は押下時の傾き",
                    strength, TILT_LAMBDA, SAMPLE_DR, SAMPLE_DP);
            c.drawText(foot, mapL, vh - 6 * dens, paint);
        }

        private String[] buildFormulaLines(int i, int j, float px, float py,
                                           float rawDx, float rawDy,
                                           float gridX, float gridY,
                                           float totalX, float totalY) {
            float st = strengthCurve(strength);
            java.util.ArrayList<String> L = new java.util.ArrayList<>();
            L.add(String.format(Locale.US, "格子[%d,%d]  位置 (%.0f, %.0f)  — %s",
                    i, j, px, py, kind));
            L.add(String.format(Locale.US,
                    "　タッチ試験: d=(%+.1f,%+.1f) → ×s' → (%+.1f,%+.1f)",
                    rawDx, rawDy, gridX, gridY));
            if (tilt != null) {
                float[] td = tiltDeltaPx();
                L.add(String.format(Locale.US,
                        "　傾き: Δ=(%+.1f,%+.1f)×s'×λ → (%+.1f,%+.1f)  [例 Δr/Δp]",
                        td[0], td[1], td[0] * st * TILT_LAMBDA, td[1] * st * TILT_LAMBDA));
                L.add(String.format(Locale.US,
                        "　モデル: dx=%.3f·Δr%+.3f·Δp  dy=%.3f·Δr%+.3f·Δp",
                        tilt[0], tilt[1], tilt[2], tilt[3]));
            } else {
                L.add("　傾き: （このモードでは未使用）");
            }
            L.add(String.format(Locale.US, "　オフセット: (%+.1f, %+.1f)", offX, offY));
            L.add(String.format(Locale.US,
                    "out = raw + grid·s' + λ·(tilt·s') + offset"));
            L.add(String.format(Locale.US,
                    "合計ずれ ≈ (%+.1f, %+.1f) px  |Δ|=%.1f",
                    totalX, totalY, Math.hypot(totalX, totalY)));
            return L.toArray(new String[0]);
        }

        private void drawArrow(Canvas c, float x0, float y0, float x1, float y1,
                               int col, float width, float head) {
            float dxv = x1 - x0, dyv = y1 - y0;
            float len = (float) Math.hypot(dxv, dyv);
            if (len < 2f) return;
            float ux = dxv / len, uy = dyv / len;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(width);
            paint.setColor(col);
            float ex = x1 - ux * head * 0.5f, ey = y1 - uy * head * 0.5f;
            c.drawLine(x0, y0, ex, ey, paint);
            path.reset();
            path.moveTo(x1, y1);
            path.lineTo(x1 - ux * head - uy * head * 0.55f,
                    y1 - uy * head + ux * head * 0.55f);
            path.lineTo(x1 - ux * head + uy * head * 0.55f,
                    y1 - uy * head - ux * head * 0.55f);
            path.close();
            paint.setStyle(Paint.Style.FILL);
            c.drawPath(path, paint);
        }

        private static int heat(float t) {
            t = t < 0 ? 0 : (t > 1 ? 1 : t);
            float r, g, b;
            if (t < 0.5f) {
                float u = t * 2f;
                r = 40 + 100 * u;
                g = 150 + 50 * u;
                b = 220 - 140 * u;
            } else {
                float u = (t - 0.5f) * 2f;
                r = 140 + 115 * u;
                g = 200 - 140 * u;
                b = 80 - 60 * u;
            }
            return Color.rgb(clamp(r), clamp(g), clamp(b));
        }

        private static int clamp(float v) {
            return v < 0 ? 0 : (v > 255 ? 255 : Math.round(v));
        }
    }
}
