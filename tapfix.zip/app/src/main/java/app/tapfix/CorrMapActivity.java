package app.tapfix;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;

/**
 * 選択中の補正データの「どこをどれだけ動かすか」を静的なベクトル図で示す。
 * 色が濃い／矢印が長いほど、その点の補正が大きい。
 */
public class CorrMapActivity extends Activity {

    public static final String EXTRA_PROFILE = "profile";
    public static final String EXTRA_MODE = "mode"; // 0=縦 1=机 2=横

    private MapView map;
    private TextView title;
    private TextView legend;
    private int mode = 0;
    private Store.Profile profile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int idx = getIntent().getIntExtra(EXTRA_PROFILE, -1);
        mode = getIntent().getIntExtra(EXTRA_MODE, 0);
        List<Store.Profile> list = Store.load(this);
        if (idx < 0 || idx >= list.size()) {
            Toast.makeText(this, "補正データがありません", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        profile = list.get(idx);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF121212);

        title = new TextView(this);
        title.setTextColor(Color.WHITE);
        title.setTextSize(16);
        title.setPadding(dp(12), dp(12), dp(12), dp(4));
        root.addView(title);

        legend = new TextView(this);
        legend.setTextColor(0xFFB0BEC5);
        legend.setTextSize(12);
        legend.setPadding(dp(12), 0, dp(12), dp(8));
        legend.setText("矢印：その点の補正方向と大きさ　色：ずれの大きさ（薄い＝小、濃い赤〜黄＝大）\n"
                + "点はキャリブ格子。端ほど色が変わっていると、端の補正が強い状態です。");
        root.addView(legend);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(dp(8), 0, dp(8), dp(8));
        tabs.addView(tabBtn("縦（手持ち）", 0));
        tabs.addView(tabBtn("机置き", 1));
        tabs.addView(tabBtn("横画面", 2));
        root.addView(tabs);

        map = new MapView(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        root.addView(map, lp);

        Button close = new Button(this);
        close.setText("閉じる");
        close.setOnClickListener(v -> finish());
        root.addView(close);

        setContentView(root);
        applyMode(mode);
    }

    private Button tabBtn(String label, int m) {
        Button b = new Button(this);
        b.setText(label);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(2), 0, dp(2), 0);
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> applyMode(m));
        return b;
    }

    private void applyMode(int m) {
        mode = m;
        float[] xs = null, ys = null, dx = null, dy = null;
        float ox = 0, oy = 0;
        int w = profile.w, h = profile.h;
        String kind;
        if (m == 1) {
            kind = "机置き";
            xs = profile.deskXs;
            ys = profile.deskYs;
            dx = profile.deskDx;
            dy = profile.deskDy;
            ox = profile.deskOffX;
            oy = profile.deskOffY;
        } else if (m == 2) {
            kind = "横画面";
            xs = profile.lxs;
            ys = profile.lys;
            dx = profile.ldx;
            dy = profile.ldy;
            ox = profile.loffX;
            oy = profile.loffY;
            if (profile.lw > 0) {
                w = profile.lw;
                h = profile.lh;
            }
        } else {
            kind = "縦（手持ち）";
            xs = profile.xs;
            ys = profile.ys;
            dx = profile.dx;
            dy = profile.dy;
            ox = profile.offX;
            oy = profile.offY;
        }
        if (xs == null || ys == null || dx == null || dy == null
                || xs.length < 2 || ys.length < 2
                || dx.length != xs.length * ys.length) {
            title.setText(String.format(Locale.US, "「%s」— %sの補正データがありません",
                    profile.name, kind));
            map.setData(null, null, null, null, 0, 0, 0, 0);
            return;
        }
        float max = 0;
        for (int i = 0; i < dx.length; i++) {
            max = Math.max(max, (float) Math.hypot(dx[i], dy[i]));
        }
        title.setText(String.format(Locale.US,
                "「%s」— %s　格子 %d×%d　最大ずれ %.1fpx　全体オフセット (%+.0f, %+.0f)",
                profile.name, kind, xs.length, ys.length, max, ox, oy));
        map.setData(xs, ys, dx, dy, w, h, ox, oy);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static final class MapView extends View {
        private float[] xs, ys, dx, dy;
        private int dataW, dataH;
        private float offX, offY;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final float dens;

        MapView(Context c) {
            super(c);
            dens = c.getResources().getDisplayMetrics().density;
            setBackgroundColor(0xFF1A1A1A);
        }

        void setData(float[] xs, float[] ys, float[] dx, float[] dy,
                     int w, int h, float ox, float oy) {
            this.xs = xs;
            this.ys = ys;
            this.dx = dx;
            this.dy = dy;
            this.dataW = Math.max(1, w);
            this.dataH = Math.max(1, h);
            this.offX = ox;
            this.offY = oy;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            int vw = getWidth(), vh = getHeight();
            if (vw <= 0 || vh <= 0) return;

            // カラーバー（右端）
            float barW = 18 * dens;
            float barPad = 10 * dens;
            float mapR = vw - barW - barPad * 2;
            float mapB = vh - 28 * dens;
            float mapL = 12 * dens, mapT = 12 * dens;
            float mapW = mapR - mapL, mapH = mapB - mapT;

            // 色スケール凡例
            for (int i = 0; i < 100; i++) {
                float t = i / 99f;
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(heat(t));
                float y0 = mapT + mapH * (1f - t);
                float y1 = mapT + mapH * (1f - (i + 1) / 99f);
                c.drawRect(mapR + barPad, y1, mapR + barPad + barW, y0 + 1, paint);
            }
            paint.setColor(Color.WHITE);
            paint.setTextSize(10 * dens);
            paint.setTextAlign(Paint.Align.CENTER);
            c.drawText("大", mapR + barPad + barW / 2, mapT + 12 * dens, paint);
            c.drawText("小", mapR + barPad + barW / 2, mapB, paint);

            if (xs == null) {
                paint.setColor(0xFF90A4AE);
                paint.setTextSize(14 * dens);
                paint.setTextAlign(Paint.Align.CENTER);
                c.drawText("このモードの補正データがありません", vw / 2f, vh / 2f, paint);
                return;
            }

            // 画面枠
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2 * dens);
            paint.setColor(0xFF455A64);
            c.drawRect(mapL, mapT, mapR, mapB, paint);

            // データ座標 → 表示座標
            float sx = mapW / dataW;
            float sy = mapH / dataH;

            // 最大ずれ（オフセット込みの表示スケール用）
            float maxLen = 1f;
            int cols = xs.length;
            int rows = ys.length;
            for (int j = 0; j < rows; j++) {
                for (int i = 0; i < cols; i++) {
                    int k = j * cols + i;
                    float len = (float) Math.hypot(dx[k] + offX, dy[k] + offY);
                    if (len > maxLen) maxLen = len;
                }
            }

            // 矢印の表示長さ上限（画面上）
            float maxArrow = Math.min(mapW, mapH) * 0.12f;
            float unit = maxLen > 1e-3f ? maxArrow / maxLen : 0f;

            // 格子線（薄く）
            paint.setStrokeWidth(1 * dens);
            paint.setColor(0x33FFFFFF);
            for (float x : xs) {
                float px = mapL + x * sx;
                c.drawLine(px, mapT, px, mapB, paint);
            }
            for (float y : ys) {
                float py = mapT + y * sy;
                c.drawLine(mapL, py, mapR, py, paint);
            }

            // 各格子点のベクトル
            for (int j = 0; j < rows; j++) {
                for (int i = 0; i < cols; i++) {
                    int k = j * cols + i;
                    float vx = dx[k] + offX;
                    float vy = dy[k] + offY;
                    float len = (float) Math.hypot(vx, vy);
                    float t = maxLen > 1e-3f ? len / maxLen : 0f;
                    int col = heat(t);

                    float x0 = mapL + xs[i] * sx;
                    float y0 = mapT + ys[j] * sy;
                    float x1 = x0 + vx * unit;
                    float y1 = y0 + vy * unit;

                    // 点（色の濃淡＝ずれの大きさ）
                    paint.setStyle(Paint.Style.FILL);
                    paint.setColor(col);
                    float r = 3.5f * dens + t * 3 * dens;
                    c.drawCircle(x0, y0, r, paint);
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setStrokeWidth(1 * dens);
                    paint.setColor(0x88FFFFFF);
                    c.drawCircle(x0, y0, r, paint);

                    if (len < 0.5f) continue;

                    // 矢印
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setStrokeWidth(2f * dens + t * 1.5f * dens);
                    paint.setColor(col);
                    c.drawLine(x0, y0, x1, y1, paint);
                    drawHead(c, x0, y0, x1, y1, col, 7 * dens);
                }
            }

            // 注記
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0xFF90A4AE);
            paint.setTextSize(11 * dens);
            paint.setTextAlign(Paint.Align.LEFT);
            c.drawText(String.format(Locale.US, "表示スケール: 最大ずれ %.1fpx → 矢印最大長", maxLen),
                    mapL, vh - 10 * dens, paint);
        }

        private void drawHead(Canvas c, float x0, float y0, float x1, float y1, int col, float size) {
            float dxv = x1 - x0, dyv = y1 - y0;
            float len = (float) Math.hypot(dxv, dyv);
            if (len < 1f) return;
            float ux = dxv / len, uy = dyv / len;
            float bx = x1 - ux * size, by = y1 - uy * size;
            path.reset();
            path.moveTo(x1, y1);
            path.lineTo(bx - uy * size * 0.55f, by + ux * size * 0.55f);
            path.lineTo(bx + uy * size * 0.55f, by - ux * size * 0.55f);
            path.close();
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(col);
            c.drawPath(path, paint);
        }

        /** 0=小（青緑）…1=大（黄→赤） */
        private static int heat(float t) {
            t = t < 0 ? 0 : (t > 1 ? 1 : t);
            float r, g, b;
            if (t < 0.5f) {
                float u = t * 2f;
                r = 40 + 80 * u;
                g = 160 + 60 * u;
                b = 220 - 120 * u;
            } else {
                float u = (t - 0.5f) * 2f;
                r = 120 + 135 * u;
                g = 220 - 160 * u;
                b = 100 - 80 * u;
            }
            return Color.rgb(clamp(r), clamp(g), clamp(b));
        }

        private static int clamp(float v) {
            return v < 0 ? 0 : (v > 255 ? 255 : Math.round(v));
        }
    }
}
