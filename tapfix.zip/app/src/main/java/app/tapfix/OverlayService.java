package app.tapfix;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;

import rikka.shizuku.Shizuku;

/**
 * 画面の上に、指の位置（赤）と補正後の位置（青）を重ねて表示する。
 * タッチは素通しなので、他のアプリの操作の邪魔にはならない。
 */
public class OverlayService extends Service {

    static volatile boolean running = false;

    private WindowManager wm;
    private OView view;
    private volatile ITapService svc;
    private volatile boolean alive = false;
    private boolean bound = false;
    private Thread poller;
    private volatile long lastBind = 0;
    private WindowManager.LayoutParams winLp;
    private long createdAt = 0;
    private long lastReattach = 0;
    private final android.os.Handler ui = new android.os.Handler(android.os.Looper.getMainLooper());

    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            svc = ITapService.Stub.asInterface(binder);
            final ITapService t = svc;
            // 止められても、Shizuku側から立ち上げ直してもらえるように伝える
            new Thread(() -> {
                try {
                    t.setOverlayWanted(true);
                } catch (Throwable ignored) {
                }
            }, "tapfix-wanted").start();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            svc = null;
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // システムに止められても、自動で立ち上げ直す
        return START_STICKY;
    }

    private Shizuku.UserServiceArgs args() {
        int vc = 1;
        try {
            vc = getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Throwable ignored) {
        }
        return new Shizuku.UserServiceArgs(new ComponentName(getPackageName(), TapService.class.getName()))
                .daemon(true)
                .processNameSuffix("tapfix")
                .version(vc);
    }

    // 前面サービスにして、システムに勝手に止められにくくする（通知は小さく出ます）
    private void startAsForeground() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(
                    "overlay", "タップ位置の表示", NotificationManager.IMPORTANCE_LOW));
            Notification n = new Notification.Builder(this, "overlay")
                    .setSmallIcon(android.R.drawable.ic_menu_view)
                    .setContentTitle("タップ位置を表示中")
                    .setOngoing(true)
                    .build();
            startForeground(1, n);
        } catch (Throwable ignored) {
        }
    }

    // Shizukuとの接続が切れていたら、つなぎ直す
    private void rebind() {
        try {
            Shizuku.unbindUserService(args(), conn, false);
        } catch (Throwable ignored) {
        }
        try {
            Shizuku.bindUserService(args(), conn);
            bound = true;
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        startAsForeground();
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        view = new OView(this);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        winLp = lp;
        createdAt = SystemClock.uptimeMillis();
        lastReattach = createdAt;
        try {
            // 以前の残骸が残っている場合に備えて一度外してから付ける
            try { wm.removeView(view); } catch (Throwable ignored) {}
            wm.addView(view, lp);
        } catch (Throwable t) {
            Toast.makeText(this, "表示できませんでした: " + t, Toast.LENGTH_LONG).show();
            running = false;
            stopSelf();
            return;
        }
        try {
            Shizuku.bindUserService(args(), conn);
            bound = true;
        } catch (Throwable t) {
            Toast.makeText(this, "Shizukuに接続できません: " + t, Toast.LENGTH_LONG).show();
        }
        alive = true;
        lastBind = SystemClock.uptimeMillis();
        poller = new Thread(() -> {
            int failStreak = 0;
            long lastTiltKick = 0;
            while (alive) {
                ITapService s = svc;
                if (s == null) {
                    long now = SystemClock.uptimeMillis();
                    if (now - lastBind > 2000) {
                        lastBind = now;
                        rebind();
                    }
                    failStreak++;
                }
                float[] d = null;
                if (s != null) {
                    try {
                        d = s.points();
                        if (d != null) failStreak = 0;
                        else failStreak++;
                    } catch (Throwable t) {
                        svc = null;
                        failStreak++;
                    }
                }
                // 連続失敗が続くときは接続とオーバーレイを強制復旧
                if (failStreak >= 8) {
                    failStreak = 0;
                    lastBind = 0;
                    rebind();
                    long tn = SystemClock.uptimeMillis();
                    if (tn - lastReattach > 2000) {
                        lastReattach = tn;
                        ui.post(() -> {
                            if (!alive) return;
                            try {
                                if (view.isAttachedToWindow()) {
                                    try { wm.removeView(view); } catch (Throwable ignored) {}
                                }
                                wm.addView(view, winLp);
                            } catch (Throwable ignored) {
                            }
                        });
                    }
                }
                final float[] dd = d;
                view.post(() -> view.update(dd));
                // 画面から外されていたら付け直す。
                // 加えて、長時間同じオーバーレイを張り続けるとダイアログ等の一時ウィンドウへの
                // タップが効かなくなる端末があるため、約45分ごとに強制的に remove→add する。
                long tn = SystemClock.uptimeMillis();
                boolean detached = !view.isAttachedToWindow();
                boolean periodic = (tn - lastReattach > 45L * 60 * 1000);
                if (tn - createdAt > 3000 && tn - lastReattach > 3000 && (detached || periodic)) {
                    lastReattach = tn;
                    ui.post(() -> {
                        if (!alive) return;
                        try {
                            if (view.isAttachedToWindow()) {
                                try { wm.removeView(view); } catch (Throwable ignored) {}
                            }
                            wm.addView(view, winLp);
                        } catch (Throwable ignored) {
                        }
                    });
                }
                // 傾きサービスも落ちていたら起こす（表示が生きている間は連携を維持）
                if (tn - lastTiltKick > 30000) {
                    lastTiltKick = tn;
                    if (!TiltService.running) {
                        try {
                            startForegroundService(new Intent(OverlayService.this, TiltService.class));
                        } catch (Throwable t) {
                            try {
                                startService(new Intent(OverlayService.this, TiltService.class));
                            } catch (Throwable ignored) {
                            }
                        }
                    }
                }
                // 触っている間だけ短い間隔で更新する（軽量表示のときは間隔を広げて負荷を減らす）
                boolean touching = d != null && d.length >= 4 && d[2] > 0;
                long wait = touching ? (Store.getLight(OverlayService.this) ? 40 : 20) : 100;
                try {
                    Thread.sleep(wait);
                } catch (InterruptedException e) {
                    break;
                }
            }
        }, "tapfix-overlay");
        poller.start();
    }

    @Override
    public void onDestroy() {
        alive = false;
        running = false;
        if (poller != null) poller.interrupt();
        try {
            if (view != null && wm != null) wm.removeView(view);
        } catch (Throwable ignored) {
        }
        if (bound) {
            try {
                // 第3引数 false：常駐サービスは止めず、接続だけ外す
                Shizuku.unbindUserService(args(), conn, false);
            } catch (Throwable ignored) {
            }
        }
        super.onDestroy();
    }

    private static final class OView extends View {
        // 軌跡の長さ（短くして描画の負荷を減らす）
        private static final int TRAIL = 16;
        // 指を離したあと、しばらくそのまま見せてから、薄くなって消える
        // 残像：しばらくそのまま見せる時間と、薄くなって消えるまでの時間（設定の合計時間を 27% : 73% に分ける）
        private long holdMs = 80, fadeMs = 220;
        private boolean outline = true;
        private boolean ghostBlue = true;

        private static final class Ghost {
            float rx, ry, ox, oy;
            long t;
        }

        private float[] data = null;
        private boolean run = false, em = false;
        private int lastN = 0;
        private float lastSeq = 0;
        private final Map<Integer, ArrayList<float[]>> trails = new HashMap<>();
        private final ArrayList<Ghost> ghosts = new ArrayList<>();
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final Rect last = new Rect(), cur = new Rect(), tmp = new Rect();
        private final float u;
        private boolean light = false;
        private boolean showCorr = true;

        OView(Context c) {
            super(c);
            u = c.getResources().getDisplayMetrics().density;
        }

        private void grow(Rect r, float x, float y, float pad) {
            r.union((int) (x - pad), (int) (y - pad), (int) (x + pad) + 1, (int) (y + pad) + 1);
        }

        // いま描くもの（指・軌跡・消えかけの丸・数字）が収まる範囲
        private void calcBounds(Rect out, long now) {
            out.setEmpty();
            float pad = 28 * u;
            float[] d = data;
            if (d != null && d.length >= 4) {
                int n = (int) d[2];
                for (int k = 0; k < n; k++) {
                    int b = 4 + k * 5;
                    grow(out, d[b + 1], d[b + 2], pad);
                    grow(out, d[b + 3], d[b + 4], pad);
                    ArrayList<float[]> t = trails.get((int) d[b]);
                    if (t != null) for (float[] p : t) {
                        grow(out, p[0], p[1], 8 * u);
                        grow(out, p[2], p[3], 8 * u);
                    }
                }
                if (n > 0 && !light && showCorr && Store.getOverlayText(getContext())) {
                    out.union(0, (int) (56 * u), getWidth(), (int) (92 * u));
                }
            }
            for (Ghost g : ghosts) {
                grow(out, g.rx, g.ry, pad);
                grow(out, g.ox, g.oy, pad);
            }
        }

        void update(float[] d) {
            long now = SystemClock.uptimeMillis();
            if (d == null || d.length < 4) {
                lastSeq = 0;
                if (!trails.isEmpty() || run || data != null) {
                    trails.clear();
                    run = false;
                    data = null;
                    last.setEmpty();
                    invalidate();
                }
                return;
            }
            light = Store.getLight(getContext());
            showCorr = Store.getShowCorr(getContext());
            outline = Store.getOutline(getContext());
            ghostBlue = Store.getGhostBlue(getContext());
            int gm = Store.getGhostMs(getContext());
            holdMs = gm * 27L / 100;
            fadeMs = gm - holdMs;
            boolean r = d[0] > 0.5f, e = d[1] > 0.5f;
            int n = (int) d[2], m = (int) d[3];
            HashSet<Integer> seen = new HashSet<>();
            for (int k = 0; k < n; k++) {
                int b = 4 + k * 5;
                int id = (int) d[b];
                seen.add(id);
                if (light) continue;
                ArrayList<float[]> t = trails.get(id);
                if (t == null) {
                    t = new ArrayList<>();
                    trails.put(id, t);
                }
                t.add(new float[]{d[b + 3], d[b + 4], d[b + 1], d[b + 2]});
                if (t.size() > TRAIL) t.remove(0);
            }
            if (light) trails.clear();
            else trails.keySet().retainAll(seen);
            // 離された指：一瞬のタップも取りこぼさないよう、サービス側の記録から拾う
            int base = 4 + n * 5;
            float maxSeq = lastSeq;
            boolean newGhost = false;
            for (int k = 0; k < m; k++) {
                int o = base + k * 6;
                if (o + 5 >= d.length) break;
                float seq = d[o];
                if (seq > lastSeq) {
                    Ghost g = new Ghost();
                    g.rx = d[o + 1];
                    g.ry = d[o + 2];
                    g.ox = d[o + 3];
                    g.oy = d[o + 4];
                    g.t = now - (long) d[o + 5];
                    if (holdMs + fadeMs > 0) {
                        ghosts.add(g);
                        newGhost = true;
                    }
                    if (seq > maxSeq) maxSeq = seq;
                }
            }
            lastSeq = maxSeq;
            while (ghosts.size() > 12) ghosts.remove(0);
            boolean topChanged = r != run || e != em;
            boolean redraw = n > 0 || lastN > 0 || newGhost || topChanged;
            data = d;
            run = r;
            em = e;
            lastN = n;
            if (!redraw) return;
            if (topChanged) {
                invalidate();
                calcBounds(last, now);
                return;
            }
            // 変わった部分だけ描き直す（画面全体を毎回描くと、ゲーム中は重いため）
            calcBounds(cur, now);
            tmp.set(last);
            tmp.union(cur);
            last.set(cur);
            if (!tmp.isEmpty()) invalidate(tmp);
        }

        // 丸1つ分：太い白線の丸（外側に薄い影をつけて、白い背景でも見える）＋中心の赤い点＋補正後の青い点
        private void mark(Canvas c, float rx, float ry, float ox, float oy, float alpha, boolean ghost) {
            int a = (int) (255 * alpha);
            if (a <= 0) return;
            if (!light && showCorr) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2 * u);
                paint.setColor(Color.argb((int) (230 * alpha), 255, 255, 255));
                c.drawLine(rx, ry, ox, oy, paint);
            }
            paint.setStyle(Paint.Style.STROKE);
            if (outline) {
                paint.setStrokeWidth(6 * u);
                paint.setColor(Color.argb((int) (100 * alpha), 0, 0, 0));
                c.drawCircle(rx, ry, 13 * u, paint);
            }
            paint.setStrokeWidth(3 * u);
            if (ghost && ghostBlue) paint.setColor(Color.argb(a, 30, 120, 255));
            else paint.setColor(Color.argb(a, 255, 255, 255));
            c.drawCircle(rx, ry, 13 * u, paint);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.argb(a, 255, 40, 40));
            c.drawCircle(rx, ry, 3 * u, paint);
            if (showCorr) {
                paint.setColor(Color.argb((int) (210 * alpha), 30, 120, 255));
                c.drawCircle(ox, oy, 6 * u, paint);
            }
        }

        @Override
        protected void onDraw(Canvas c) {
            long now = SystemClock.uptimeMillis();
            if (run) {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(Color.argb(200, 0, 200, 80));
                c.drawCircle(getWidth() - 10 * u, 10 * u, 4 * u, paint);
            }
            if (em && !run) {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(Color.argb(220, 200, 0, 0));
                c.drawRect(0, 0, getWidth(), 56 * u, paint);
                paint.setColor(Color.WHITE);
                paint.setTextSize(15 * u);
                paint.setTextAlign(Paint.Align.CENTER);
                c.drawText("補正を強制停止しました", getWidth() / 2f, 36 * u, paint);
            }
            // 消えかけの丸：しばらくそのまま → 薄くなる → 消える
            boolean anim = false;
            tmp.setEmpty();
            for (int i = ghosts.size() - 1; i >= 0; i--) {
                Ghost g = ghosts.get(i);
                long age = now - g.t;
                if (age >= holdMs + fadeMs) {
                    ghosts.remove(i);
                    continue;
                }
                float alpha = age <= holdMs ? 1f : 1f - (age - holdMs) / (float) Math.max(1, fadeMs);
                mark(c, g.rx, g.ry, g.ox, g.oy, alpha, true);
                grow(tmp, g.rx, g.ry, 28 * u);
                grow(tmp, g.ox, g.oy, 28 * u);
                anim = true;
            }
            if (anim) postInvalidateOnAnimation(tmp.left, tmp.top, tmp.right, tmp.bottom);
            float[] d = data;
            if (d == null || d.length < 4) return;
            int n = (int) d[2];
            for (int k = 0; k < n; k++) {
                int b = 4 + k * 5;
                int id = (int) d[b];
                float rx = d[b + 1], ry = d[b + 2], ox = d[b + 3], oy = d[b + 4];
                ArrayList<float[]> t = trails.get(id);
                if (!light && t != null && t.size() > 1) {
                    // 補正の情報をオンにすると補正後の軌跡（青）、オフにすると指の軌跡（白）
                    int o = showCorr ? 0 : 2;
                    path.reset();
                    path.moveTo(t.get(0)[o], t.get(0)[o + 1]);
                    for (int i = 1; i < t.size(); i++) path.lineTo(t.get(i)[o], t.get(i)[o + 1]);
                    paint.setStyle(Paint.Style.STROKE);
                    if (!showCorr && outline) {
                        paint.setStrokeWidth(5 * u);
                        paint.setColor(Color.argb(80, 0, 0, 0));
                        c.drawPath(path, paint);
                    }
                    paint.setStrokeWidth(3 * u);
                    paint.setColor(showCorr ? Color.argb(140, 30, 120, 255) : Color.argb(180, 255, 255, 255));
                    c.drawPath(path, paint);
                }
                mark(c, rx, ry, ox, oy, 1f, false);
            }
            if (n > 0 && !light && showCorr && Store.getOverlayText(getContext())) {
                float rx = d[5], ry = d[6], ox = d[7], oy = d[8];
                String s = String.format(Locale.US, "指 %d,%d → 補正後(青) %d,%d  差 %+d,%+d",
                        Math.round(rx), Math.round(ry), Math.round(ox), Math.round(oy),
                        Math.round(ox - rx), Math.round(oy - ry));
                paint.setStyle(Paint.Style.FILL);
                paint.setTextAlign(Paint.Align.LEFT);
                paint.setTextSize(13 * u);
                paint.setColor(Color.argb(170, 0, 0, 0));
                c.drawRect(8 * u, 64 * u, getWidth() - 8 * u, 86 * u, paint);
                paint.setColor(Color.WHITE);
                c.drawText(s, 12 * u, 80 * u, paint);
            }
        }
    }
}
