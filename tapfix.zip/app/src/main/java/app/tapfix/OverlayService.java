package app.tapfix;

import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;

import rikka.shizuku.Shizuku;

/**
 * 画面の上に、指の位置（赤）と補正後の位置（青）を重ねて表示する。
 * タッチは素通しなので、他のアプリの操作の邪魔にはならない。
 */
public class OverlayService extends Service {

    static volatile boolean running = false;

    private WindowManager wm;
    private OView view;
    private volatile ITapService svc;
    private volatile boolean alive = false;
    private boolean bound = false;
    private Thread poller;

    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            svc = ITapService.Stub.asInterface(binder);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            svc = null;
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    private Shizuku.UserServiceArgs args() {
        int vc = 1;
        try {
            vc = getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Throwable ignored) {
        }
        return new Shizuku.UserServiceArgs(new ComponentName(getPackageName(), TapService.class.getName()))
                .daemon(true)
                .processNameSuffix("tapfix")
                .version(vc);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        view = new OView(this);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        try {
            wm.addView(view, lp);
        } catch (Throwable t) {
            Toast.makeText(this, "表示できませんでした: " + t, Toast.LENGTH_LONG).show();
            running = false;
            stopSelf();
            return;
        }
        try {
            Shizuku.bindUserService(args(), conn);
            bound = true;
        } catch (Throwable t) {
            Toast.makeText(this, "Shizukuに接続できません: " + t, Toast.LENGTH_LONG).show();
        }
        alive = true;
        poller = new Thread(() -> {
            while (alive) {
                ITapService s = svc;
                float[] d = null;
                if (s != null) {
                    try {
                        d = s.points();
                    } catch (Throwable ignored) {
                    }
                }
                final float[] dd = d;
                view.post(() -> view.update(dd));
                long wait = (d != null && d.length >= 3 && d[2] > 0) ? 16 : 120;
                try {
                    Thread.sleep(wait);
                } catch (InterruptedException e) {
                    break;
                }
            }
        }, "tapfix-overlay");
        poller.start();
    }

    @Override
    public void onDestroy() {
        alive = false;
        running = false;
        if (poller != null) poller.interrupt();
        try {
            if (view != null && wm != null) wm.removeView(view);
        } catch (Throwable ignored) {
        }
        if (bound) {
            try {
                // 第3引数 false：常駐サービスは止めず、接続だけ外す
                Shizuku.unbindUserService(args(), conn, false);
            } catch (Throwable ignored) {
            }
        }
        super.onDestroy();
    }

    private static final class OView extends View {
        private static final int TRAIL = 40;

        private float[] data = null;
        private boolean run = false, em = false;
        private int lastN = 0;
        private final Map<Integer, ArrayList<float[]>> trails = new HashMap<>();
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        OView(Context c) {
            super(c);
        }

        void update(float[] d) {
            if (d == null || d.length < 3) {
                if (!trails.isEmpty() || run) {
                    trails.clear();
                    run = false;
                    data = null;
                    invalidate();
                }
                return;
            }
            boolean r = d[0] > 0.5f, e = d[1] > 0.5f;
            int n = (int) d[2];
            HashSet<Integer> seen = new HashSet<>();
            for (int k = 0; k < n; k++) {
                int b = 3 + k * 5;
                int id = (int) d[b];
                seen.add(id);
                ArrayList<float[]> t = trails.get(id);
                if (t == null) {
                    t = new ArrayList<>();
                    trails.put(id, t);
                }
                t.add(new float[]{d[b + 3], d[b + 4]});
                if (t.size() > TRAIL) t.remove(0);
            }
            trails.keySet().retainAll(seen);
            boolean redraw = n > 0 || lastN > 0 || r != run || e != em;
            data = d;
            run = r;
            em = e;
            lastN = n;
            if (redraw) invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float u = getResources().getDisplayMetrics().density;
            if (run) {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(Color.argb(200, 0, 200, 80));
                c.drawCircle(getWidth() - 10 * u, 10 * u, 4 * u, paint);
            }
            if (em && !run) {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(Color.argb(220, 200, 0, 0));
                c.drawRect(0, 0, getWidth(), 56 * u, paint);
                paint.setColor(Color.WHITE);
                paint.setTextSize(15 * u);
                paint.setTextAlign(Paint.Align.CENTER);
                c.drawText("補正を強制停止しました", getWidth() / 2f, 36 * u, paint);
            }
            float[] d = data;
            if (d == null || d.length < 3) return;
            int n = (int) d[2];
            for (int k = 0; k < n; k++) {
                int b = 3 + k * 5;
                int id = (int) d[b];
                float rx = d[b + 1], ry = d[b + 2], ox = d[b + 3], oy = d[b + 4];
                ArrayList<float[]> t = trails.get(id);
                if (t != null) {
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setStrokeWidth(3 * u);
                    paint.setColor(Color.argb(140, 30, 120, 255));
                    for (int i = 1; i < t.size(); i++) {
                        c.drawLine(t.get(i - 1)[0], t.get(i - 1)[1], t.get(i)[0], t.get(i)[1], paint);
                    }
                }
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2 * u);
                paint.setColor(Color.argb(230, 255, 255, 255));
                c.drawLine(rx, ry, ox, oy, paint);
                paint.setColor(Color.argb(230, 255, 40, 40));
                c.drawCircle(rx, ry, 14 * u, paint);
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(Color.argb(200, 30, 120, 255));
                c.drawCircle(ox, oy, 7 * u, paint);
            }
            if (n > 0) {
                float rx = d[4], ry = d[5], ox = d[6], oy = d[7];
                String s = String.format(Locale.US, "指(赤) %d,%d → 補正後(青) %d,%d  差 %+d,%+d",
                        Math.round(rx), Math.round(ry), Math.round(ox), Math.round(oy),
                        Math.round(ox - rx), Math.round(oy - ry));
                paint.setStyle(Paint.Style.FILL);
                paint.setTextAlign(Paint.Align.LEFT);
                paint.setTextSize(13 * u);
                paint.setColor(Color.argb(170, 0, 0, 0));
                c.drawRect(8 * u, 64 * u, getWidth() - 8 * u, 86 * u, paint);
                paint.setColor(Color.WHITE);
                c.drawText(s, 12 * u, 80 * u, paint);
            }
        }
    }
}
