package app.tapfix;

final class Native {
    private Native() {
    }

    static native int nOpen(String path);

    static native int nGrab(int fd, int on);

    static native int nRead(int fd, byte[] buf, int timeoutMs);

    static native void nClose(int fd);
}
