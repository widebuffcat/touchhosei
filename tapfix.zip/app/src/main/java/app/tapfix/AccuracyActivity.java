package app.tapfix;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

import java.util.Locale;
import java.util.Random;

/** 精度テスト：12か所の赤い円をタップして、狙いとのズレ（px / mm）を測る。補正の入/切で比べられる。 */
public class AccuracyActivity extends Activity {

    private static final float[] FX = {0.15f, 0.5f, 0.85f};
    private static final float[] FY = {0.12f, 0.37f, 0.62f, 0.87f};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(new TestView(this));
        hideBars();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    @SuppressWarnings("deprecation")
    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private final class TestView extends View {
        private final int cols = FX.length;
        private final int n = FX.length * FY.length;
        private final float[] tx = new float[n];
        private final float[] ty = new float[n];
        private final float[] ex = new float[n];
        private final float[] ey = new float[n];
        private final int[] order = new int[n];
        private final Random rnd = new Random();
        private int idx = 0;
        private boolean ready = false;
        private int ox, oy;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final DisplayMetrics dm = getResources().getDisplayMetrics();

        TestView(Context c) {
            super(c);
            shuffle();
        }

        private void shuffle() {
            for (int i = 0; i < n; i++) order[i] = i;
            for (int i = n - 1; i > 0; i--) {
                int j = rnd.nextInt(i + 1);
                int t = order[i];
                order[i] = order[j];
                order[j] = t;
            }
        }

        private void layoutTargets() {
            int[] loc = new int[2];
            getLocationOnScreen(loc);
            ox = loc[0];
            oy = loc[1];
            for (int j = 0; j < FY.length; j++) {
                for (int i = 0; i < cols; i++) {
                    tx[j * cols + i] = ox + FX[i] * getWidth();
                    ty[j * cols + i] = oy + FY[j] * getHeight();
                }
            }
            ready = true;
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            ready = false;
        }

        @Override
        protected void onDraw(Canvas c) {
            if (!ready) layoutTargets();
            c.drawColor(Color.BLACK);
            float u = dm.density;
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            paint.setTextAlign(Paint.Align.CENTER);
            if (idx < n) {
                int k = order[idx];
                float x = tx[k] - ox, y = ty[k] - oy;
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2 * u);
                paint.setColor(Color.RED);
                c.drawCircle(x, y, 22 * u, paint);
                c.drawLine(x - 34 * u, y, x + 34 * u, y, paint);
                c.drawLine(x, y - 34 * u, x, y + 34 * u, paint);
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(Color.WHITE);
                paint.setTextSize(16 * u);
                c.drawText("赤い十字の中心をタップ (" + (idx + 1) + "/" + n + ")", cx, cy - 10 * u, paint);
                paint.setTextSize(12 * u);
                paint.setColor(Color.GRAY);
                c.drawText("今の状態（補正中なら補正後）の精度を測ります", cx, cy + 20 * u, paint);
                c.drawText("戻るキーで中止", cx, cy + 40 * u, paint);
                return;
            }
            // 結果：狙いとのズレを mm で集計し、ズレの向きと大きさを4倍に拡大して描く
            double sum = 0, max = 0, bx = 0, by = 0;
            for (int k = 0; k < n; k++) {
                double mx = ex[k] / dm.xdpi * 25.4, my = ey[k] / dm.ydpi * 25.4;
                double mag = Math.sqrt(mx * mx + my * my);
                sum += mag;
                if (mag > max) max = mag;
                bx += ex[k];
                by += ey[k];
            }
            double pxMean = 0, pxMax = 0;
            for (int k = 0; k < n; k++) {
                double m = Math.sqrt(ex[k] * ex[k] + ey[k] * ey[k]);
                pxMean += m;
                if (m > pxMax) pxMax = m;
            }
            pxMean /= n;
            bx /= n;
            by /= n;
            for (int k = 0; k < n; k++) {
                float x = tx[k] - ox, y = ty[k] - oy;
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(1 * u);
                paint.setColor(Color.DKGRAY);
                c.drawCircle(x, y, 8 * u, paint);
                paint.setStrokeWidth(2 * u);
                paint.setColor(Color.RED);
                c.drawLine(x, y, x + ex[k] * 4, y + ey[k] * 4, paint);
                paint.setStyle(Paint.Style.FILL);
                c.drawCircle(x + ex[k] * 4, y + ey[k] * 4, 3 * u, paint);
            }
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.WHITE);
            paint.setTextSize(15 * u);
            c.drawText(String.format(Locale.US, "平均ズレ %.1f px（%.1f mm）", pxMean, sum / n), cx, cy - 36 * u, paint);
            c.drawText(String.format(Locale.US, "最大ズレ %.1f px（%.1f mm）", pxMax, max), cx, cy - 16 * u, paint);
            c.drawText(String.format(Locale.US, "全体の偏り x%+.1f  y%+.1f px", bx, by), cx, cy + 4 * u, paint);
            paint.setTextSize(11 * u);
            paint.setColor(Color.GRAY);
            c.drawText("赤い線はズレの向き（実際の4倍に拡大）", cx, cy + 24 * u, paint);
            c.drawText("画面タップでもう一度 / 戻るキーで終了", cx, cy + 40 * u, paint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                if (!ready) layoutTargets();
                if (idx < n) {
                    int k = order[idx];
                    ex[k] = e.getRawX() - tx[k];
                    ey[k] = e.getRawY() - ty[k];
                    idx++;
                } else {
                    idx = 0;
                    shuffle();
                }
                invalidate();
            }
            return true;
        }
    }
}
