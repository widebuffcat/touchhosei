package app.tapfix;

import android.app.Activity;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.io.OutputStream;
import java.util.List;
import java.util.Locale;
import java.util.Random;

import rikka.shizuku.Shizuku;

/** 精度テスト：12か所の赤い円をタップして、狙いとのズレ（px / mm）を測る。補正の入/切で比べられる。 */
public class AccuracyActivity extends Activity {

    private static final float[] FX0 = {0.15f, 0.5f, 0.85f};
    private static final float[] FY0 = {0.12f, 0.37f, 0.62f, 0.87f};
    // 画面の端まで測るテスト
    private static final float[] FX1 = {0.04f, 0.5f, 0.96f};
    private static final float[] FY1 = {0.03f, 0.37f, 0.62f, 0.97f};
    private float[] fxs = FX0, fys = FY0;
    // 横画面のテストか（偏りの反映先が、横画面のオフセットになる）
    private boolean land = false;

    private TestView view;
    private LinearLayout bar;
    private volatile ITapService svc;
    private boolean bound = false;
    // このテスト画面で測った偏りの合計と回数（「偏りを補正に反映」で平均して使う）
    private float sumBx = 0, sumBy = 0;
    private int runs = 0;
    // テスト中の傾きの記録：{左右の傾き, 前後の傾き, ズレx, ズレy}（補正オンで測ったタップだけ）
    private final TiltSensor tilt = new TiltSensor();
    private final java.util.ArrayList<float[]> tiltSamples = new java.util.ArrayList<>();
    private volatile boolean svcRunning = false;
    private volatile boolean alive = true;

    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            svc = ITapService.Stub.asInterface(binder);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            svc = null;
        }
    };

    private Shizuku.UserServiceArgs args() {
        int vc = 1;
        try {
            vc = getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Throwable ignored) {
        }
        return new Shizuku.UserServiceArgs(new ComponentName(getPackageName(), TapService.class.getName()))
                .daemon(true)
                .processNameSuffix("tapfix")
                .version(vc);
    }

    @Override
    protected void onDestroy() {
        alive = false;
        tilt.stop();
        if (bound) {
            try {
                Shizuku.unbindUserService(args(), conn, false);
            } catch (Throwable ignored) {
            }
        }
        super.onDestroy();
    }

    // ---- 傾きの解析（テスト中に集めたサンプルから、傾きによるズレの残りを求める） ----
    // ズレ ≈ 定数 + a×(左右の傾き-基準)/10 + b×(前後の傾き-基準)/10 を最小二乗で求める
    private static double[] fit3(java.util.List<float[]> s, int skip, double r0, double p0, int col) {
        double[][] a = new double[3][3];
        double[] b = new double[3];
        for (int k = 0; k < s.size(); k++) {
            if (k == skip) continue;
            float[] q = s.get(k);
            double[] f = {1, (q[0] - r0) / 10.0, (q[1] - p0) / 10.0};
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) a[i][j] += f[i] * f[j];
                b[i] += f[i] * q[col];
            }
        }
        a[0][0] += 1e-6;
        a[1][1] += 0.1;
        a[2][2] += 0.1;
        for (int c = 0; c < 3; c++) {
            int piv = c;
            for (int r = c + 1; r < 3; r++) if (Math.abs(a[r][c]) > Math.abs(a[piv][c])) piv = r;
            double[] t = a[c];
            a[c] = a[piv];
            a[piv] = t;
            double tb = b[c];
            b[c] = b[piv];
            b[piv] = tb;
            for (int r = c + 1; r < 3; r++) {
                double m = a[r][c] / a[c][c];
                for (int k = c; k < 3; k++) a[r][k] -= m * a[c][k];
                b[r] -= m * b[c];
            }
        }
        double[] x = new double[3];
        for (int r = 2; r >= 0; r--) {
            double v = b[r];
            for (int k = r + 1; k < 3; k++) v -= a[r][k] * x[k];
            x[r] = v / a[r][r];
        }
        return x;
    }

    private static double std(java.util.List<float[]> s, int col) {
        double m = 0, v = 0;
        for (float[] q : s) m += q[col];
        m /= s.size();
        for (float[] q : s) v += (q[col] - m) * (q[col] - m);
        return Math.sqrt(v / s.size());
    }

    // 傾きを使う補正のほうが、使わない補正より（1つ抜いて予測する検証で）良くなるかを調べる。
    // 戻り値 {xの定数, x左右, x前後, yの定数, y左右, y前後, 傾きありの誤差, 傾きなしの誤差}（a,b は px/度）。使えなければ null
    private static double[] analyzeTilt(java.util.List<float[]> s, double r0, double p0) {
        int n = s.size();
        if (n < 12) return null;
        if (Math.max(std(s, 0), std(s, 1)) < 1.0) return null;
        double eT = 0, eC = 0;
        for (int k = 0; k < n; k++) {
            double[] cx = fit3(s, k, r0, p0, 2), cy = fit3(s, k, r0, p0, 3);
            float[] q = s.get(k);
            double[] f = {1, (q[0] - r0) / 10.0, (q[1] - p0) / 10.0};
            double px = cx[0] * f[0] + cx[1] * f[1] + cx[2] * f[2];
            double py = cy[0] * f[0] + cy[1] * f[1] + cy[2] * f[2];
            double mx = 0, my = 0;
            for (int j = 0; j < n; j++) {
                if (j == k) continue;
                mx += s.get(j)[2];
                my += s.get(j)[3];
            }
            mx /= (n - 1);
            my /= (n - 1);
            eT += (q[2] - px) * (q[2] - px) + (q[3] - py) * (q[3] - py);
            eC += (q[2] - mx) * (q[2] - mx) + (q[3] - my) * (q[3] - my);
        }
        eT = Math.sqrt(eT / n);
        eC = Math.sqrt(eC / n);
        if (!(eT < eC * 0.97)) return new double[]{0, 0, 0, 0, 0, 0, eT, eC};
        double[] cx = fit3(s, -1, r0, p0, 2), cy = fit3(s, -1, r0, p0, 3);
        return new double[]{cx[0], cx[1] / 10.0, cx[2] / 10.0, cy[0], cy[1] / 10.0, cy[2] / 10.0, eT, eC};
    }

    // 測った偏りと傾きを、いま選んでいる補正データに反映する（補正オンで測った場合のみ）
    private void applyBias() {
        final ITapService s = svc;
        if (s == null) {
            Toast.makeText(this, "Shizukuに接続できていません。メイン画面で接続を確認してください", Toast.LENGTH_LONG).show();
            return;
        }
        if (runs == 0) return;
        final float bx = sumBx / runs, by = sumBy / runs;
        final int n = runs;
        final java.util.ArrayList<float[]> samples;
        synchronized (tiltSamples) {
            samples = new java.util.ArrayList<>(tiltSamples);
        }
        new Thread(() -> {
            String msg;
            boolean tiltChanged = false;
            float[] newTilt = null;
            try {
                float[] pts = s.points();
                if (pts == null || pts.length < 1 || pts[0] < 0.5f) {
                    msg = "補正がオフの状態で測った偏りは反映できません。補正をオンにして、もう一度テストしてください";
                } else {
                    List<Store.Profile> l = Store.load(this);
                    int a = Store.getActive(this);
                    if (a <= 0 || a - 1 >= l.size()) {
                        msg = "補正データが選ばれていません";
                    } else {
                        Store.Profile p = l.get(a - 1);
                        float nx, ny;
                        String tiltMsg = "";
                        if (land) {
                            if (p.lxs == null) {
                                throw new IllegalStateException("この補正データには横画面の補正がありません");
                            }
                            nx = Math.max(-30, Math.min(30, Math.round(p.loffX - bx)));
                            ny = Math.max(-30, Math.min(30, Math.round(p.loffY - by)));
                            p.loffX = nx;
                            p.loffY = ny;
                            Store.save(this, l);
                            s.setLandOffset(nx, ny);
                        } else {
                            float useBx = bx, useBy = by;
                            // 傾き：いまサービスが使っている傾きモデルの状態に合わせて、増分だけを足す
                            String st = "";
                            try {
                                st = s.status();
                            } catch (Throwable ignored) {
                            }
                            boolean svcOff = st.contains("傾き連携: オフ");
                            boolean svcOn = st.contains("傾き連携: オン（左右");
                            boolean haveModel = p.tilt != null && p.tilt.length >= 6;
                            java.util.ArrayList<float[]> ok = new java.util.ArrayList<>();
                            for (float[] q : samples) if (q[4] > 0.5f) ok.add(q);
                            if (!Store.getUseTilt(this)) {
                                tiltMsg = "\n傾き：「傾き連携を使う」がオフなので、傾きは反映していません";
                            } else if (!(svcOn && haveModel) && !(svcOff && !haveModel)) {
                                tiltMsg = "\n傾き：傾きを受信できていないので、傾きは反映していません（補正を開始し直してください）";
                            } else if (ok.size() < 12) {
                                tiltMsg = String.format(Locale.US,
                                        "\n傾き：補正オンで測った点が %d 点で、まだ少ないので反映していません（12点以上）", ok.size());
                            } else {
                                double r0, p0;
                                if (haveModel) {
                                    r0 = p.tilt[4];
                                    p0 = p.tilt[5];
                                } else {
                                    r0 = 0;
                                    p0 = 0;
                                    for (float[] q : ok) {
                                        r0 += q[0];
                                        p0 += q[1];
                                    }
                                    r0 /= ok.size();
                                    p0 /= ok.size();
                                }
                                double[] r = analyzeTilt(ok, r0, p0);
                                if (r == null) {
                                    tiltMsg = "\n傾き：測っている間の傾きの変化が小さいので、傾きは反映していません";
                                } else if (r[1] == 0 && r[2] == 0 && r[4] == 0 && r[5] == 0) {
                                    tiltMsg = String.format(Locale.US,
                                            "\n傾き：傾きを使っても良くならなかったので反映していません（%d点、誤差 %.1f→%.1f px）",
                                            ok.size(), r[7], r[6]);
                                } else {
                                    float[] m = haveModel ? p.tilt.clone() : new float[]{0, 0, 0, 0, (float) r0, (float) p0};
                                    // 残っているズレ（= 出力 - 狙い）を打ち消すので、引く
                                    m[0] -= (float) r[1];
                                    m[1] -= (float) r[2];
                                    m[2] -= (float) r[4];
                                    m[3] -= (float) r[5];
                                    p.tilt = m;
                                    newTilt = m;
                                    tiltChanged = true;
                                    // 基準の傾きでのズレ（定数項）を全体オフセットに回す
                                    useBx = (float) r[0];
                                    useBy = (float) r[3];
                                    tiltMsg = String.format(Locale.US,
                                            "\n傾き：%d点から解析して%sしました（予測誤差 %.1f→%.1f px）",
                                            ok.size(), haveModel ? "傾き補正を更新" : "傾き補正を新しく作成", r[7], r[6]);
                                }
                            }
                            nx = Math.max(-30, Math.min(30, Math.round(p.offX - useBx)));
                            ny = Math.max(-30, Math.min(30, Math.round(p.offY - useBy)));
                            p.offX = nx;
                            p.offY = ny;
                            Store.save(this, l);
                            s.setOffset(nx, ny);
                            if (tiltChanged) {
                                s.setTiltModel(newTilt);
                                try {
                                    startService(new Intent(this, TiltService.class));
                                } catch (Throwable ignored) {
                                }
                            }
                        }
                        // 反映したので、これまでの測定は使い切る
                        sumBx = 0;
                        sumBy = 0;
                        runs = 0;
                        synchronized (tiltSamples) {
                            tiltSamples.clear();
                        }
                        msg = String.format(Locale.US,
                                "全体オフセットを 右へ%+.0f px、下へ%+.0f px にしました（%d回のテストの平均）。%s\nもう一度テストで確認してください",
                                nx, ny, n, tiltMsg);
                    }
                }
            } catch (Throwable t) {
                msg = "反映できませんでした: " + t;
            }
            final String m = msg;
            runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_LONG).show());
        }, "tapfix-applybias").start();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        land = getIntent().getBooleanExtra("land", false);
        // 縦画面のテスト中は、傾きも一緒に測る（傾きの補正に使うサンプルを増やすため）
        if (!land) tilt.start(this, (r, p) -> { });
        // 補正が動作中かを時々確認して、タップごとに記録する（動作中に測った点だけを傾きの解析に使う）
        new Thread(() -> {
            while (alive) {
                try {
                    ITapService sv = svc;
                    if (sv != null) {
                        float[] pp = sv.points();
                        svcRunning = pp != null && pp.length > 0 && pp[0] > 0.5f;
                    }
                    Thread.sleep(400);
                } catch (Throwable t) {
                    svcRunning = false;
                    try {
                        Thread.sleep(400);
                    } catch (InterruptedException ie) {
                        return;
                    }
                }
            }
        }, "tapfix-runpoll").start();
        setRequestedOrientation(land
                ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                : android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        if (getIntent().getBooleanExtra("edge", false)) {
            fxs = FX1;
            fys = FY1;
        }
        FrameLayout frame = new FrameLayout(this);
        view = new TestView(this);
        frame.addView(view, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        // 結果が出たら下に出すボタン（スクリーンショットには写らない）
        bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setVisibility(View.GONE);
        Button shot = new Button(this);
        shot.setAllCaps(false);
        shot.setText("スクリーンショットを保存");
        shot.setOnClickListener(v -> saveShot());
        Button apply = new Button(this);
        apply.setAllCaps(false);
        apply.setText("偏りを補正に反映");
        apply.setOnClickListener(v -> applyBias());
        Button again = new Button(this);
        again.setAllCaps(false);
        again.setText("もう一度");
        again.setOnClickListener(v -> {
            bar.setVisibility(View.GONE);
            view.restart();
        });
        for (Button b : new Button[]{shot, apply, again}) {
            b.setTextSize(12);
            b.setMinWidth(0);
            b.setMinimumWidth(0);
        }
        shot.setText("画像を保存");
        bar.addView(shot);
        bar.addView(apply);
        bar.addView(again);
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        blp.bottomMargin = (int) (48 * getResources().getDisplayMetrics().density);
        frame.addView(bar, blp);

        setContentView(frame);
        hideBars();
        try {
            Shizuku.bindUserService(args(), conn);
            bound = true;
        } catch (Throwable ignored) {
        }
    }

    // 結果の画面（ボタンを除く）を画像にして、ピクチャ/tapfix に保存する
    private void saveShot() {
        if (Build.VERSION.SDK_INT < 29) {
            Toast.makeText(this, "この機能はAndroid 10以降で使えます", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            Bitmap bmp = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
            view.draw(new Canvas(bmp));
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Images.Media.DISPLAY_NAME, "tapfix_test_" + System.currentTimeMillis() + ".png");
            cv.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            cv.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/tapfix");
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            if (uri == null) throw new Exception("保存先を作れませんでした");
            try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                bmp.compress(Bitmap.CompressFormat.PNG, 100, os);
            }
            Toast.makeText(this, "保存しました（ピクチャ/tapfix）", Toast.LENGTH_LONG).show();
        } catch (Throwable t) {
            Toast.makeText(this, "保存に失敗: " + t, Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    @SuppressWarnings("deprecation")
    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private final class TestView extends View {
        private final int cols = fxs.length;
        private final int n = fxs.length * fys.length;
        private final float[] tx = new float[n];
        private final float[] ty = new float[n];
        private final float[] ex = new float[n];
        private final float[] ey = new float[n];
        private final int[] order = new int[n];
        private final Random rnd = new Random();
        private int idx = 0;
        private boolean ready = false;
        private int ox, oy;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final DisplayMetrics dm = getResources().getDisplayMetrics();

        TestView(Context c) {
            super(c);
            shuffle();
        }

        void restart() {
            idx = 0;
            shuffle();
            invalidate();
        }

        private void shuffle() {
            for (int i = 0; i < n; i++) order[i] = i;
            for (int i = n - 1; i > 0; i--) {
                int j = rnd.nextInt(i + 1);
                int t = order[i];
                order[i] = order[j];
                order[j] = t;
            }
        }

        private void layoutTargets() {
            int[] loc = new int[2];
            getLocationOnScreen(loc);
            ox = loc[0];
            oy = loc[1];
            for (int j = 0; j < fys.length; j++) {
                for (int i = 0; i < cols; i++) {
                    tx[j * cols + i] = ox + fxs[i] * getWidth();
                    ty[j * cols + i] = oy + fys[j] * getHeight();
                }
            }
            ready = true;
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            ready = false;
        }

        @Override
        protected void onDraw(Canvas c) {
            if (!ready) layoutTargets();
            c.drawColor(Color.BLACK);
            float u = dm.density;
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            paint.setTextAlign(Paint.Align.CENTER);
            if (idx < n) {
                int k = order[idx];
                float x = tx[k] - ox, y = ty[k] - oy;
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2 * u);
                paint.setColor(Color.RED);
                c.drawCircle(x, y, 22 * u, paint);
                c.drawLine(x - 34 * u, y, x + 34 * u, y, paint);
                c.drawLine(x, y - 34 * u, x, y + 34 * u, paint);
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(Color.WHITE);
                paint.setTextSize(16 * u);
                c.drawText("赤い十字の中心をタップ (" + (idx + 1) + "/" + n + ")", cx, cy - 10 * u, paint);
                paint.setTextSize(12 * u);
                paint.setColor(Color.GRAY);
                c.drawText("今の状態（補正中なら補正後）の精度を測ります", cx, cy + 20 * u, paint);
                c.drawText("戻るキーで中止", cx, cy + 40 * u, paint);
                return;
            }
            // 結果：狙いとのズレを mm で集計し、ズレの向きと大きさを4倍に拡大して描く
            double sum = 0, max = 0, bx = 0, by = 0;
            for (int k = 0; k < n; k++) {
                double mx = ex[k] / dm.xdpi * 25.4, my = ey[k] / dm.ydpi * 25.4;
                double mag = Math.sqrt(mx * mx + my * my);
                sum += mag;
                if (mag > max) max = mag;
                bx += ex[k];
                by += ey[k];
            }
            double pxMean = 0, pxMax = 0;
            for (int k = 0; k < n; k++) {
                double m = Math.sqrt(ex[k] * ex[k] + ey[k] * ey[k]);
                pxMean += m;
                if (m > pxMax) pxMax = m;
            }
            pxMean /= n;
            bx /= n;
            by /= n;
            for (int k = 0; k < n; k++) {
                float x = tx[k] - ox, y = ty[k] - oy;
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(1 * u);
                paint.setColor(Color.DKGRAY);
                c.drawCircle(x, y, 8 * u, paint);
                paint.setStrokeWidth(2 * u);
                paint.setColor(Color.RED);
                c.drawLine(x, y, x + ex[k] * 4, y + ey[k] * 4, paint);
                paint.setStyle(Paint.Style.FILL);
                c.drawCircle(x + ex[k] * 4, y + ey[k] * 4, 3 * u, paint);
            }
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.WHITE);
            paint.setTextSize(15 * u);
            c.drawText(String.format(Locale.US, "平均ズレ %.1f px（%.1f mm）", pxMean, sum / n), cx, cy - 36 * u, paint);
            c.drawText(String.format(Locale.US, "最大ズレ %.1f px（%.1f mm）", pxMax, max), cx, cy - 16 * u, paint);
            c.drawText(String.format(Locale.US, "全体の偏り x%+.1f  y%+.1f px", bx, by), cx, cy + 4 * u, paint);
            paint.setTextSize(11 * u);
            paint.setColor(Color.GRAY);
            c.drawText("赤い線はズレの向き（実際の4倍に拡大）", cx, cy + 24 * u, paint);
            c.drawText("下のボタンで保存・もう一度 / 戻るキーで終了", cx, cy + 40 * u, paint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            // 結果が出たあとは、画面タップでは何も起きない（上から引き下げる操作で再開しないように）
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN && idx < n) {
                if (!ready) layoutTargets();
                int k = order[idx];
                ex[k] = e.getRawX() - tx[k];
                ey[k] = e.getRawY() - ty[k];
                if (!land && tilt.valid) {
                    synchronized (tiltSamples) {
                        tiltSamples.add(new float[]{tilt.roll, tilt.pitch, ex[k], ey[k], svcRunning ? 1f : 0f});
                    }
                }
                idx++;
                if (idx == n) {
                    double bx = 0, by = 0;
                    for (int i = 0; i < n; i++) {
                        bx += ex[i];
                        by += ey[i];
                    }
                    sumBx += (float) (bx / n);
                    sumBy += (float) (by / n);
                    runs++;
                    if (bar != null) bar.setVisibility(View.VISIBLE);
                }
                invalidate();
            }
            return true;
        }
    }
}
