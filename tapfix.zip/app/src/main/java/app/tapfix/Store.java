package app.tapfix;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** 補正データ（プロファイル）の保存。 */
final class Store {
    private Store() {
    }

    static final class Profile {
        String name;
        int w, h;
        float[] xs, ys, dx, dy;
        // 全体オフセット(px)：補正後の位置をまとめてずらす微調整
        float offX, offY;
        // 傾き連携のモデル [横傾き→x, 前後傾き→x, 横傾き→y, 前後傾き→y (px/度), 基準roll, 基準pitch]。なければ null
        float[] tilt;
        // 横画面の補正（画面に表示される向きの座標で測ったもの）。なければ null
        int lw, lh;
        float[] lxs, lys, ldx, ldy;
        float loffX, loffY;
        // 机などに置いて（傾かない状態で）人差し指で操作するとき用の補正。なければ null
        float[] deskXs, deskYs, deskDx, deskDy;
        float deskOffX, deskOffY;
    }

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("tapfix", Context.MODE_PRIVATE);
    }

    private static JSONArray arr(float[] a) throws Exception {
        JSONArray j = new JSONArray();
        for (float v : a) j.put((double) v);
        return j;
    }

    private static float[] floats(JSONArray j) throws Exception {
        float[] a = new float[j.length()];
        for (int i = 0; i < a.length; i++) a[i] = (float) j.getDouble(i);
        return a;
    }

    static List<Profile> load(Context c) {
        List<Profile> list = new ArrayList<>();
        try {
            JSONArray all = new JSONArray(sp(c).getString("profiles", "[]"));
            for (int i = 0; i < all.length(); i++) {
                JSONObject o = all.getJSONObject(i);
                Profile p = new Profile();
                p.name = o.getString("name");
                p.w = o.getInt("w");
                p.h = o.getInt("h");
                p.xs = floats(o.getJSONArray("xs"));
                p.ys = floats(o.getJSONArray("ys"));
                p.dx = floats(o.getJSONArray("dx"));
                p.dy = floats(o.getJSONArray("dy"));
                p.offX = (float) o.optDouble("offX", 0);
                p.offY = (float) o.optDouble("offY", 0);
                if (o.has("tilt")) p.tilt = floats(o.getJSONArray("tilt"));
                if (o.has("deskXs")) {
                    p.deskXs = floats(o.getJSONArray("deskXs"));
                    p.deskYs = floats(o.getJSONArray("deskYs"));
                    p.deskDx = floats(o.getJSONArray("deskDx"));
                    p.deskDy = floats(o.getJSONArray("deskDy"));
                    p.deskOffX = (float) o.optDouble("deskOffX", 0);
                    p.deskOffY = (float) o.optDouble("deskOffY", 0);
                }
                if (o.has("lxs")) {
                    p.lw = o.optInt("lw", 0);
                    p.lh = o.optInt("lh", 0);
                    p.lxs = floats(o.getJSONArray("lxs"));
                    p.lys = floats(o.getJSONArray("lys"));
                    p.ldx = floats(o.getJSONArray("ldx"));
                    p.ldy = floats(o.getJSONArray("ldy"));
                    p.loffX = (float) o.optDouble("loffX", 0);
                    p.loffY = (float) o.optDouble("loffY", 0);
                }
                list.add(p);
            }
        } catch (Throwable ignored) {
        }
        return list;
    }

    static void save(Context c, List<Profile> list) {
        try {
            JSONArray all = new JSONArray();
            for (Profile p : list) {
                JSONObject o = new JSONObject();
                o.put("name", p.name);
                o.put("w", p.w);
                o.put("h", p.h);
                o.put("xs", arr(p.xs));
                o.put("ys", arr(p.ys));
                o.put("dx", arr(p.dx));
                o.put("dy", arr(p.dy));
                o.put("offX", (double) p.offX);
                o.put("offY", (double) p.offY);
                if (p.tilt != null) o.put("tilt", arr(p.tilt));
                if (p.deskXs != null) {
                    o.put("deskXs", arr(p.deskXs));
                    o.put("deskYs", arr(p.deskYs));
                    o.put("deskDx", arr(p.deskDx));
                    o.put("deskDy", arr(p.deskDy));
                    o.put("deskOffX", (double) p.deskOffX);
                    o.put("deskOffY", (double) p.deskOffY);
                }
                if (p.lxs != null) {
                    o.put("lw", p.lw);
                    o.put("lh", p.lh);
                    o.put("lxs", arr(p.lxs));
                    o.put("lys", arr(p.lys));
                    o.put("ldx", arr(p.ldx));
                    o.put("ldy", arr(p.ldy));
                    o.put("loffX", (double) p.loffX);
                    o.put("loffY", (double) p.loffY);
                }
                all.put(o);
            }
            sp(c).edit().putString("profiles", all.toString()).apply();
        } catch (Throwable ignored) {
        }
    }

    // 0 = 補正なし、1以上 = プロファイル(番号-1)
    static int getActive(Context c) {
        return sp(c).getInt("active", 0);
    }

    static void setActive(Context c, int i) {
        sp(c).edit().putInt("active", i).apply();
    }

    // フリック抑制：指のブレを無視する距離(px)。0で無効
    static int getSlop(Context c) {
        return sp(c).getInt("slop", 20);
    }

    static void setSlop(Context c, int v) {
        sp(c).edit().putInt("slop", v).apply();
    }

    // 傾き（ジャイロ）連携を使うか。補正データに傾きの情報があるときだけ効く
    static boolean getUseTilt(Context c) {
        return sp(c).getBoolean("use_tilt", true);
    }

    static void setUseTilt(Context c, boolean v) {
        sp(c).edit().putBoolean("use_tilt", v).apply();
    }

    // タップ位置を平均する時間(ms)。0で無効
    static int getAvg(Context c) {
        return sp(c).getInt("avg_ms", 20);
    }

    static void setAvg(Context c, int v) {
        sp(c).edit().putInt("avg_ms", v).apply();
    }

    // タップ位置の表示をオンにしておきたいか（システムに止められたあとの復帰用）
    static boolean getOverlay(Context c) {
        return sp(c).getBoolean("overlay", true);
    }

    static void setOverlay(Context c, boolean v) {
        sp(c).edit().putBoolean("overlay", v).apply();
    }

    // タップ位置の表示：上部の座標・ズレの数字を出すか
    static boolean getOverlayText(Context c) {
        return sp(c).getBoolean("overlay_text", true);
    }

    static void setOverlayText(Context c, boolean v) {
        sp(c).edit().putBoolean("overlay_text", v).apply();
    }

    // タップ位置の表示：軽量表示（軌跡・線・数字を省いて、ゲームなどの負荷を減らす）
    static boolean getLight(Context c) {
        return sp(c).getBoolean("overlay_light", false);
    }

    static void setLight(Context c, boolean v) {
        sp(c).edit().putBoolean("overlay_light", v).apply();
    }

    // 机置き（傾かない状態）の判定を使うか／そのしきい値（単位 0.001 rad/s：1秒間の回転の揺れがこれより小さいと「机置き」）
    static boolean getDeskOn(Context c) {
        return sp(c).getBoolean("desk_on", true);
    }

    static void setDeskOn(Context c, boolean v) {
        sp(c).edit().putBoolean("desk_on", v).apply();
    }

    static int getDeskThr(Context c) {
        return sp(c).getInt("desk_thr", 15);
    }

    static void setDeskThr(Context c, int v) {
        sp(c).edit().putInt("desk_thr", v).apply();
    }

    // 権限の自動設定（重ねて表示・電池・自動削除）を済ませたか。入れ直すと消えるので、入れ直したら自動でもう一度行う
    static boolean permSetupDone(Context c) {
        return sp(c).getBoolean("perm_setup_done", false);
    }

    static void setPermSetupDone(Context c) {
        sp(c).edit().putBoolean("perm_setup_done", true).apply();
    }

    // 直近の精度テストの結果（key: hand / edge / desk）
    static void setLastTest(Context c, String key, String text) {
        sp(c).edit().putString("last_test_" + key, text).apply();
    }

    static String getLastTest(Context c, String key) {
        return sp(c).getString("last_test_" + key, "");
    }

    static void clearLastTests(Context c) {
        sp(c).edit().remove("last_test_hand").remove("last_test_edge").remove("last_test_desk").apply();
    }

    // ---- 補正データのバックアップ（アンインストールしても残すため、Shizukuの常駐サービス側に保存する） ----
    static String dump(Context c) {
        return sp(c).getString("profiles", "[]");
    }

    static boolean restoreChecked(Context c) {
        return sp(c).getBoolean("restore_checked", false);
    }

    static void setRestoreChecked(Context c) {
        sp(c).edit().putBoolean("restore_checked", true).apply();
    }

    static String lastBackedUp(Context c) {
        return sp(c).getString("last_backup", "");
    }

    static void setLastBackedUp(Context c, String s) {
        sp(c).edit().putString("last_backup", s).apply();
    }

    /** バックアップのJSONから、いまの補正データに無い名前のものだけを足す。足した数を返す（失敗は -1）。 */
    static int mergeFromBackup(Context c, String backup) {
        try {
            JSONObject root = new JSONObject(backup);
            JSONArray theirs = root.getJSONArray("profiles");
            JSONArray mine = new JSONArray(dump(c));
            java.util.HashSet<String> names = new java.util.HashSet<>();
            for (int i = 0; i < mine.length(); i++) names.add(mine.getJSONObject(i).optString("name"));
            int added = 0;
            for (int i = 0; i < theirs.length(); i++) {
                JSONObject o = theirs.getJSONObject(i);
                if (names.add(o.optString("name"))) {
                    mine.put(o);
                    added++;
                }
            }
            if (added > 0) sp(c).edit().putString("profiles", mine.toString()).apply();
            return added;
        } catch (Throwable t) {
            return -1;
        }
    }

    static String wrapBackup(Context c, String profilesJson) {
        try {
            JSONObject o = new JSONObject();
            o.put("app", "tapfix");
            o.put("saved_at", System.currentTimeMillis());
            o.put("profiles", new JSONArray(profilesJson));
            return o.toString();
        } catch (Throwable t) {
            return "";
        }
    }

    // 補正の強さ（%）。格子と傾きによる補正の量にかける（全体オフセットにはかけない）
    static int getStrength(Context c) {
        return sp(c).getInt("strength", 100);
    }

    static void setStrength(Context c, int v) {
        sp(c).edit().putInt("strength", v).apply();
    }

    // タップ表示に、補正の情報（青い点・線・軌跡・数字）を描くか
    static boolean getShowCorr(Context c) {
        return sp(c).getBoolean("overlay_corr", true);
    }

    static void setShowCorr(Context c, boolean v) {
        sp(c).edit().putBoolean("overlay_corr", v).apply();
    }

    static void add(Context c, Profile p) {
        List<Profile> l = load(c);
        l.add(p);
        save(c, l);
        setActive(c, l.size());
    }
}
