package app.tapfix;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** 補正データ（プロファイル）の保存。 */
final class Store {
    private Store() {
    }

    static final class Profile {
        String name;
        int w, h;
        float[] xs, ys, dx, dy;
    }

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("tapfix", Context.MODE_PRIVATE);
    }

    private static JSONArray arr(float[] a) throws Exception {
        JSONArray j = new JSONArray();
        for (float v : a) j.put((double) v);
        return j;
    }

    private static float[] floats(JSONArray j) throws Exception {
        float[] a = new float[j.length()];
        for (int i = 0; i < a.length; i++) a[i] = (float) j.getDouble(i);
        return a;
    }

    static List<Profile> load(Context c) {
        List<Profile> list = new ArrayList<>();
        try {
            JSONArray all = new JSONArray(sp(c).getString("profiles", "[]"));
            for (int i = 0; i < all.length(); i++) {
                JSONObject o = all.getJSONObject(i);
                Profile p = new Profile();
                p.name = o.getString("name");
                p.w = o.getInt("w");
                p.h = o.getInt("h");
                p.xs = floats(o.getJSONArray("xs"));
                p.ys = floats(o.getJSONArray("ys"));
                p.dx = floats(o.getJSONArray("dx"));
                p.dy = floats(o.getJSONArray("dy"));
                list.add(p);
            }
        } catch (Throwable ignored) {
        }
        return list;
    }

    static void save(Context c, List<Profile> list) {
        try {
            JSONArray all = new JSONArray();
            for (Profile p : list) {
                JSONObject o = new JSONObject();
                o.put("name", p.name);
                o.put("w", p.w);
                o.put("h", p.h);
                o.put("xs", arr(p.xs));
                o.put("ys", arr(p.ys));
                o.put("dx", arr(p.dx));
                o.put("dy", arr(p.dy));
                all.put(o);
            }
            sp(c).edit().putString("profiles", all.toString()).apply();
        } catch (Throwable ignored) {
        }
    }

    // 0 = 補正なし、1以上 = プロファイル(番号-1)
    static int getActive(Context c) {
        return sp(c).getInt("active", 0);
    }

    static void setActive(Context c, int i) {
        sp(c).edit().putInt("active", i).apply();
    }

    static void add(Context c, Profile p) {
        List<Profile> l = load(c);
        l.add(p);
        save(c, l);
        setActive(c, l.size());
    }
}
