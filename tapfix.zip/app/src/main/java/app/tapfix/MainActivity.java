package app.tapfix;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.function.Consumer;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {

    private static final int REQ = 100;

    private ITapService svc;
    private boolean running = false;
    private boolean binding = false;
    private boolean spinnerInit = false;

    private TextView statusView, logView;
    private Button toggle, overlayBtn;
    private TextView slopLabel, offLabel, avgLabel, strLabel, deskLabel;
    private SeekBar seekX, seekY;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            if (svc != null) refreshStatus();
            handler.postDelayed(this, 1000);
        }
    };
    private Spinner spinner;
    private ScrollView scroll;
    private List<Store.Profile> profiles = new ArrayList<>();

    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            svc = ITapService.Stub.asInterface(binder);
            binding = false;
            bg(() -> svc.setLibDir(getApplicationInfo().nativeLibraryDir), s -> refreshStatus());
            syncBackup();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            svc = null;
            binding = false;
            running = false;
            showStatus("接続が切れました（Shizukuを確認してください）");
        }
    };

    private final Shizuku.OnRequestPermissionResultListener permListener =
            (requestCode, grantResult) -> {
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    bind();
                } else {
                    log("Shizukuの許可が拒否されました");
                }
            };

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(14), dp(14), dp(14));

        statusView = new TextView(this);
        statusView.setTextSize(16);
        statusView.setText("接続中…");
        root.addView(statusView);

        toggle = button("補正を開始", v -> onToggle());
        root.addView(toggle);

        // メッセージ欄：画面全体をスクロールできるようにしたので、ボタンのすぐ下に置く
        logView = new TextView(this);
        logView.setTextSize(12);
        root.addView(logView);

        overlayBtn = button("タップ位置を表示：オフ", v -> onOverlay());
        root.addView(overlayBtn);
        CheckBox textBox = new CheckBox(this);
        textBox.setText("上部に座標とズレの数字を表示する");
        textBox.setChecked(Store.getOverlayText(this));
        textBox.setOnCheckedChangeListener((b, checked) -> Store.setOverlayText(this, checked));
        root.addView(textBox);
        CheckBox corrBox = new CheckBox(this);
        corrBox.setText("タップ表示に補正の情報を描く（青い点・結ぶ線・数字）");
        corrBox.setChecked(Store.getShowCorr(this));
        corrBox.setOnCheckedChangeListener((b, checked) -> Store.setShowCorr(this, checked));
        root.addView(corrBox);
        CheckBox lightBox = new CheckBox(this);
        lightBox.setText("軽量表示（軌跡・線・数字を省く。ゲーム中の負荷を減らす）");
        lightBox.setChecked(Store.getLight(this));
        lightBox.setOnCheckedChangeListener((b, checked) -> Store.setLight(this, checked));
        root.addView(lightBox);
        CheckBox tiltBox = new CheckBox(this);
        tiltBox.setText("傾き（ジャイロ）連携を使う（補正データに傾きの情報があるとき）");
        tiltBox.setChecked(Store.getUseTilt(this));
        tiltBox.setOnCheckedChangeListener((b, checked) -> {
            Store.setUseTilt(this, checked);
            if (svc != null && running) applyTiltLive();
        });
        root.addView(tiltBox);

        TextView lbl = new TextView(this);
        lbl.setText("使う補正データ");
        lbl.setPadding(0, dp(12), 0, 0);
        root.addView(lbl);

        spinner = new Spinner(this);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!spinnerInit) return;
                Store.setActive(MainActivity.this, position);
                syncOffsetUi();
                if (running) {
                    log("補正データを切り替えたので、いったん止めてもう一度「開始」を押してください");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        root.addView(spinner);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button cal = button("標準で測る（15点）", v -> onCalibrate(0, false));
        Button fine = button("細かく測る（45＋15点）", v -> onCalibrate(1, false));
        row.addView(cal, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(fine, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(row);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        Button test = button("精度テスト", v -> startActivity(new Intent(this, AccuracyActivity.class)));
        Button testEdge = button("端の精度テスト", v -> startActivity(
                new Intent(this, AccuracyActivity.class).putExtra("edge", true)));
        row2.addView(test, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row2.addView(testEdge, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(row2);
        LinearLayout rowL = new LinearLayout(this);
        rowL.setOrientation(LinearLayout.HORIZONTAL);
        Button calL = button("横画面を測る（標準）", v -> onCalibrate(0, true));
        Button fineL = button("横画面を測る（細かく）", v -> onCalibrate(1, true));
        rowL.addView(calL, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        rowL.addView(fineL, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(rowL);
        LinearLayout rowL2 = new LinearLayout(this);
        rowL2.setOrientation(LinearLayout.HORIZONTAL);
        Button testL = button("横画面の精度テスト", v -> startActivity(
                new Intent(this, AccuracyActivity.class).putExtra("land", true)));
        Button testLE = button("横画面の端のテスト", v -> startActivity(
                new Intent(this, AccuracyActivity.class).putExtra("land", true).putExtra("edge", true)));
        rowL2.addView(testL, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        rowL2.addView(testLE, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(rowL2);
        LinearLayout rowD = new LinearLayout(this);
        rowD.setOrientation(LinearLayout.HORIZONTAL);
        Button calD = button("机置きを測る（標準）", v -> onCalibrate(0, false, true));
        Button fineD = button("机置きを測る（細かく）", v -> onCalibrate(1, false, true));
        rowD.addView(calD, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        rowD.addView(fineD, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(rowD);
        Button del = button("選択中を削除", v -> onDelete());
        root.addView(del);

        slopLabel = new TextView(this);
        slopLabel.setPadding(0, dp(12), 0, 0);
        root.addView(slopLabel);
        SeekBar seek = new SeekBar(this);
        seek.setMax(80);
        seek.setProgress(Store.getSlop(this));
        showSlop(Store.getSlop(this));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                Store.setSlop(MainActivity.this, progress);
                showSlop(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                final int v = bar.getProgress();
                if (svc != null) bg(() -> {
                    svc.setSlop(v);
                    return "";
                }, s -> refreshStatus());
            }
        });
        root.addView(seek);

        CheckBox deskBox = new CheckBox(this);
        deskBox.setText("机置き（傾かず静止）の判定を使う：ジャイロで静止を検出したら、机置き用の補正に切り替える");
        deskBox.setChecked(Store.getDeskOn(this));
        deskBox.setOnCheckedChangeListener((b, checked) -> {
            Store.setDeskOn(this, checked);
            sendDeskThreshold();
        });
        root.addView(deskBox);
        deskLabel = new TextView(this);
        deskLabel.setPadding(0, dp(8), 0, 0);
        root.addView(deskLabel);
        SeekBar seekDesk = new SeekBar(this);
        seekDesk.setMax(57);
        seekDesk.setProgress(Store.getDeskThr(this) - 3);
        showDeskThr(Store.getDeskThr(this));
        seekDesk.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                Store.setDeskThr(MainActivity.this, progress + 3);
                showDeskThr(progress + 3);
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                sendDeskThreshold();
            }
        });
        root.addView(seekDesk);

        strLabel = new TextView(this);
        strLabel.setPadding(0, dp(12), 0, 0);
        root.addView(strLabel);
        SeekBar seekStr = new SeekBar(this);
        seekStr.setMax(30);
        seekStr.setProgress(Store.getStrength(this) / 5);
        showStrength(Store.getStrength(this));
        seekStr.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                Store.setStrength(MainActivity.this, progress * 5);
                showStrength(progress * 5);
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                final int v = bar.getProgress() * 5;
                if (svc != null) bg(() -> {
                    svc.setStrength(v);
                    return "";
                }, s -> refreshStatus());
            }
        });
        root.addView(seekStr);

        avgLabel = new TextView(this);
        avgLabel.setPadding(0, dp(12), 0, 0);
        root.addView(avgLabel);
        SeekBar seekAvg = new SeekBar(this);
        seekAvg.setMax(20);
        seekAvg.setProgress(Store.getAvg(this) / 5);
        showAvg(Store.getAvg(this));
        seekAvg.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                Store.setAvg(MainActivity.this, progress * 5);
                showAvg(progress * 5);
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                final int v = bar.getProgress() * 5;
                if (svc != null) bg(() -> {
                    svc.setAvg(v);
                    return "";
                }, s -> refreshStatus());
            }
        });
        root.addView(seekAvg);

        offLabel = new TextView(this);
        offLabel.setPadding(0, dp(12), 0, 0);
        root.addView(offLabel);
        SeekBar.OnSeekBarChangeListener offListener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                showOffset();
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                applyOffset();
            }
        };
        seekX = new SeekBar(this);
        seekX.setMax(60);
        seekX.setProgress(30);
        seekX.setOnSeekBarChangeListener(offListener);
        root.addView(seekX);
        seekY = new SeekBar(this);
        seekY.setMax(60);
        seekY.setProgress(30);
        seekY.setOnSeekBarChangeListener(offListener);
        root.addView(seekY);
        showOffset();

        TextView help = new TextView(this);
        help.setTextSize(12);
        help.setText("・傾き連携：「細かく測る」のとき、タップの瞬間の端末の傾き（左右・前後）も一緒に記録します。傾きで補正が変わる効果があると判断されたときだけ、補正データに傾きの情報が入ります。補正中は傾きを読み取り続けるため、小さな通知が出ます。\n"
                + "・タップ位置の平均時間：押した直後は指の接触面が広がる途中で、位置が不安定です。この時間だけ位置をためて平均し、その位置を押した場所として送ります。長いほどブレは減りますが、反応が少し遅れます（0でオフ）。\n"
                + "・画面の端の補正：「細かく測る」は画面の端（約5%）まで測ります。端の外側の少しの範囲は、傾きを延長して補正します。「端の精度テスト」で端のズレを確認できます。\n"
                + "・タップ位置の表示が勝手に消えるときは、端末の設定でこのアプリの電池の使用を「制限なし（最適化しない）」にしてください。\n"
                + "・全体オフセット：精度テストの「全体の偏り」が x−7 なら、右へ +7 のように、逆向きに動かします（補正をオンにして測った偏りが目安）。補正中でもスライダーで即反映され、補正データごとに保存されます。\n"
                + "・精度の調整：「細かく測る」は格子45点＋ランダム15点を測り、タップごとのブレを平均して滑らかに補正します（保存時にブレの大きさも出ます）。「精度テスト」で、狙いとのズレを px / mm で測れます。補正を入れた状態と切った状態で比べてください。\n"
                + "・フリック抑制：押した位置から指がこの距離より動くまでは、位置を動かさずタップとして扱います（0でオフ）。大きいほど意図しないフリックが減りますが、スクロールやフリック入力の出だしが少し重くなります。スライダーを動かすと補正中でも即反映されます。\n"
                + "・補正が効かなくなったり、画面が操作できなくなったら、音量＋と音量−を同時に2秒押し続けると補正を止められます。\n"
                + "・横画面の補正：「使う補正データ」を選んで「横画面を測る」を押すと、画面が横向きになるので、普段横で持つ持ち方で測ります。選んだ補正データに追加で保存され（縦の補正はそのまま）、横画面にしたとき自動で切り替わります。左向き・右向きのどちらの横でも同じ補正を使います。傾き連携・全体オフセットのスライダーは縦画面用です。横画面のオフセットは「横画面の精度テスト」→「偏りを補正に反映」で調整できます。補正データを選び直したら、停止して「補正を開始」を押し直してください。\n"
                + "・精度テスト中も傾きを測っています。縦画面で「偏りを補正に反映」を押すと、補正オンで測った点（12点以上）から傾きによるズレの残りを解析し、良くなると判断したときだけ傾き補正を更新（傾き補正がなければ新規作成）して、全体オフセットと一緒に反映します。同じ持ち方・同じ補正状態で何回か測ってから押すほど確実です。\n"
                + "・補正の強さ：格子と傾きによる補正の量に割合をかけます（100%が測った通り）。補正が強すぎると感じるときは、90%や80%に下げてみてください。全体オフセットにはかかりません。\n"
                + "・指が2本以上のとき（ピンチなど）は、フリック抑制とタップ位置の平均を自動で外して、動きをそのまま通します。\n"
                + "・机置き：スマホを机などに置いて（傾かず静止して）人差し指で操作するときは、手で持って親指で操作するときと補正が違います。「使う補正データ」を選んで、スマホを机に置いたまま「机置きを測る」を押すと、その補正データに机置き用の補正が追加されます。補正中は、ジャイロで1秒間の揺れを見て、静止していれば机置き用に、手で持っていれば普段の補正（傾き連携を含む）に、タップの瞬間ごとに自動で切り替わります。状態表示に「判定」と揺れの大きさが出るので、手持ちと机置きで値を見て、判定のしきい値を合わせてください。机置き用のオフセットは、机に置いたまま精度テスト→「偏りを補正に反映」で調整できます（縦画面のみ）。\n"
                + "・補正データのバックアップ：補正データは、Shizukuの常駐サービス側にも自動で控えを保存します（/data/local/tmp と /sdcard/tapfix）。アンインストールして入れ直しても、Shizukuを起動して接続すると、控えにだけある補正データが自動で戻ります（名前が同じものは戻しません）。\n"
                + "・補正の入る向き：縦は常に補正。横は、横画面の補正を測ってあるときだけ補正（なければ素通し）。上下逆さまの縦は素通しです。\n"
                + "・タップ表示：指の位置は白線の丸（中心の小さな赤点）、補正後の位置は青い点です（「補正の情報を描く」をオフにすると、白い丸・赤い点・指の軌跡だけになります）。指を離すと一瞬残り、薄くなって消えます。ゲーム中に重いときは「軽量表示」をオンにしてください。\n"
                + "・端末を再起動したら、Shizukuを起動し直してから「補正を開始」を押してください。");
        help.setPadding(0, dp(10), 0, dp(6));
        root.addView(help);

        // 画面に収まらない分はスクロールで見られるように、全体を ScrollView に入れる
        scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
        Shizuku.addRequestPermissionResultListener(permListener);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshProfiles();
        syncBackup();
        // タップ位置の表示を「オン」にしていたのに止められていたら、立ち上げ直す
        if (Store.getOverlay(this) && !OverlayService.running && Settings.canDrawOverlays(this)) {
            try {
                startService(new Intent(this, OverlayService.class));
                OverlayService.running = true;
            } catch (Throwable ignored) {
            }
        }
        updateOverlayBtn();
        if (svc == null) {
            connect();
        } else {
            refreshStatus();
        }
        handler.postDelayed(poll, 1000);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(poll);
        super.onPause();
    }

    // 補正中に「傾き連携」のオン/オフを切り替えたとき、すぐ反映する
    private void applyTiltLive() {
        int sel = spinner.getSelectedItemPosition();
        float[] tm = new float[0];
        if (sel > 0 && sel - 1 < profiles.size()) {
            Store.Profile p = profiles.get(sel - 1);
            if (p.tilt != null && p.tilt.length >= 6 && Store.getUseTilt(this)) tm = p.tilt;
        }
        final float[] ftm = tm;
        boolean deskAny = sel > 0 && sel - 1 < profiles.size() && profiles.get(sel - 1).deskXs != null;
        try {
            if (ftm.length >= 6 || deskAny) startService(new Intent(this, TiltService.class));
            else stopService(new Intent(this, TiltService.class));
        } catch (Throwable ignored) {
        }
        bg(() -> {
            svc.setTiltModel(ftm);
            return "";
        }, s -> refreshStatus());
    }

    // 補正データを、アンインストールしても残る場所（Shizukuの常駐サービス側）にバックアップする。
    // 入れ直した直後は、バックアップにだけある補正データを（名前が重複しないものだけ）復元する
    private void syncBackup() {
        final ITapService s = svc;
        if (s == null) return;
        new Thread(() -> {
            try {
                String msg = null;
                if (!Store.restoreChecked(this)) {
                    String b = s.readBackup();
                    if (b != null && b.length() > 0) {
                        int added = Store.mergeFromBackup(this, b);
                        if (added < 0) return;
                        if (added > 0) msg = "バックアップから補正データを " + added + " 件復元しました";
                    }
                    Store.setRestoreChecked(this);
                }
                String cur = Store.dump(this);
                if (!cur.equals(Store.lastBackedUp(this))) {
                    String w = Store.wrapBackup(this, cur);
                    if (w.length() > 0 && s.writeBackup(w)) Store.setLastBackedUp(this, cur);
                }
                if (msg != null) {
                    final String m = msg;
                    runOnUiThread(() -> {
                        refreshProfiles();
                        log(m);
                    });
                }
            } catch (Throwable ignored) {
            }
        }, "tapfix-backup").start();
    }

    private void showDeskThr(int milli) {
        deskLabel.setText(String.format(java.util.Locale.US,
                "机置きの判定しきい値（1秒間の回転の揺れがこれより小さいと机置き）: %.3f rad/s", milli / 1000.0));
    }

    private void sendDeskThreshold() {
        final float thr = Store.getDeskOn(this) ? Store.getDeskThr(this) / 1000f : 0f;
        if (svc != null) bg(() -> {
            svc.setDeskThreshold(thr);
            return "";
        }, s -> refreshStatus());
    }

    private void showStrength(int pct) {
        strLabel.setText("補正の強さ（格子・傾きの補正にかける割合。全体オフセットは別）: " + pct + " %");
    }

    private void showAvg(int ms) {
        avgLabel.setText("タップ位置の平均時間（押した直後の位置のブレを平均）: " + (ms == 0 ? "オフ" : ms + " ms"));
    }

    private void showOffset() {
        offLabel.setText(String.format(Locale.US,
                "全体オフセット（選択中の補正データ）: 右へ %+d px、下へ %+d px",
                seekX.getProgress() - 30, seekY.getProgress() - 30));
    }

    // 選択中の補正データのオフセットをスライダーに反映する（「補正なし」のときは無効）
    private void syncOffsetUi() {
        int sel = spinner.getSelectedItemPosition();
        boolean ok = sel > 0 && sel - 1 < profiles.size();
        float ox = ok ? profiles.get(sel - 1).offX : 0, oy = ok ? profiles.get(sel - 1).offY : 0;
        seekX.setEnabled(ok);
        seekY.setEnabled(ok);
        seekX.setProgress(Math.round(ox) + 30);
        seekY.setProgress(Math.round(oy) + 30);
        showOffset();
    }

    private void applyOffset() {
        int sel = spinner.getSelectedItemPosition();
        if (sel <= 0 || sel - 1 >= profiles.size()) return;
        Store.Profile p = profiles.get(sel - 1);
        p.offX = seekX.getProgress() - 30;
        p.offY = seekY.getProgress() - 30;
        Store.save(this, profiles);
        final float ox = p.offX, oy = p.offY;
        if (svc != null && running) {
            bg(() -> {
                svc.setOffset(ox, oy);
                return "";
            }, s -> refreshStatus());
        }
    }

    private void showSlop(int v) {
        slopLabel.setText("フリック抑制（指のブレを無視する距離）: " + (v == 0 ? "オフ" : v + " px"));
    }

    private void updateOverlayBtn() {
        overlayBtn.setText(OverlayService.running ? "タップ位置を表示：オン（押すと消す）" : "タップ位置を表示：オフ（押すと表示）");
    }

    private void onOverlay() {
        if (OverlayService.running) {
            Store.setOverlay(this, false);
            stopService(new Intent(this, OverlayService.class));
            OverlayService.running = false;
            updateOverlayBtn();
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            log("「他のアプリの上に重ねて表示」を許可してから、戻ってもう一度押してください");
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        Store.setOverlay(this, true);
        startService(new Intent(this, OverlayService.class));
        OverlayService.running = true;
        updateOverlayBtn();
    }

    @Override
    protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener);
        super.onDestroy();
    }

    private int versionCode() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Throwable t) {
            return 1;
        }
    }

    private Shizuku.UserServiceArgs args() {
        // daemon(true): アプリを閉じても補正が動き続ける
        return new Shizuku.UserServiceArgs(new ComponentName(getPackageName(), TapService.class.getName()))
                .daemon(true)
                .processNameSuffix("tapfix")
                .version(versionCode());
    }

    private void connect() {
        try {
            if (!Shizuku.pingBinder()) {
                showStatus("Shizukuが動いていません。Shizukuアプリで開始してから、この画面に戻ってください");
                return;
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(REQ);
                return;
            }
            bind();
        } catch (Throwable t) {
            log("エラー: " + t);
        }
    }

    private void bind() {
        if (binding || svc != null) return;
        try {
            binding = true;
            Shizuku.bindUserService(args(), conn);
        } catch (Throwable t) {
            binding = false;
            log("bind失敗: " + t);
        }
    }

    private void bg(Callable<String> c, Consumer<String> done) {
        new Thread(() -> {
            String r;
            try {
                r = c.call();
            } catch (Throwable t) {
                r = "エラー: " + t;
            }
            final String out = r;
            runOnUiThread(() -> done.accept(out));
        }).start();
    }

    private void refreshStatus() {
        if (svc == null) return;
        bg(() -> svc.status(), this::showStatus);
    }

    private void showStatus(String s) {
        running = s.startsWith("動作中");
        statusView.setText(s);
        toggle.setText(running ? "補正を停止" : "補正を開始");
    }

    private void refreshProfiles() {
        profiles = Store.load(this);
        List<String> names = new ArrayList<>();
        names.add("補正なし（素通し）");
        for (Store.Profile p : profiles) {
            String sfx = (p.lxs != null ? "（横あり）" : "") + (p.deskXs != null ? "（机あり）" : "");
            names.add(p.name + sfx);
        }
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, names);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerInit = false;
        spinner.setAdapter(ad);
        int a = Math.min(Store.getActive(this), names.size() - 1);
        spinner.setSelection(Math.max(0, a));
        spinnerInit = true;
        syncOffsetUi();
    }

    private void onToggle() {
        if (svc == null) {
            connect();
            return;
        }
        if (running) {
            stopService(new Intent(this, TiltService.class));
            bg(() -> svc.stop(), s -> refreshStatus());
            return;
        }
        int sel = spinner.getSelectedItemPosition();
        float[] none = new float[0];
        float[] xs = none, ys = none, dx = none, dy = none;
        float[] lxs = none, lys = none, ldx = none, ldy = none;
        float lox = 0, loy = 0;
        float[] kxs = none, kys = none, kdx = none, kdy = none;
        float kox = 0, koy = 0;
        float ox = 0, oy = 0;
        float[] tm = new float[0];
        if (sel > 0 && sel - 1 < profiles.size()) {
            Store.Profile p = profiles.get(sel - 1);
            if (p.tilt != null && p.tilt.length >= 6 && Store.getUseTilt(this)) tm = p.tilt;
            ox = p.offX;
            oy = p.offY;
            xs = p.xs;
            ys = p.ys;
            dx = p.dx;
            dy = p.dy;
            if (p.deskXs != null) {
                kxs = p.deskXs;
                kys = p.deskYs;
                kdx = p.deskDx;
                kdy = p.deskDy;
                kox = p.deskOffX;
                koy = p.deskOffY;
            }
            if (p.lxs != null) {
                lxs = p.lxs;
                lys = p.lys;
                ldx = p.ldx;
                ldy = p.ldy;
                lox = p.loffX;
                loy = p.loffY;
            }
        }
        final float[] flxs = lxs, flys = lys, fldx = ldx, fldy = ldy;
        final float flox = lox, floy = loy;
        final float[] fkxs = kxs, fkys = kys, fkdx = kdx, fkdy = kdy;
        final float fkox = kox, fkoy = koy;
        final boolean deskData = kxs.length >= 2;
        final float deskThr = Store.getDeskOn(this) ? Store.getDeskThr(this) / 1000f : 0f;
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        final int w = Math.min(dm.widthPixels, dm.heightPixels);
        final int h = Math.max(dm.widthPixels, dm.heightPixels);
        final float[] fxs = xs, fys = ys, fdx = dx, fdy = dy;
        final int slop = Store.getSlop(this);
        final float fox = ox, foy = oy;
        final int avg = Store.getAvg(this);
        final int strengthPct = Store.getStrength(this);
        final float[] ftm = tm;
        // 傾きの情報があるときだけ、傾きを送り続けるサービスを動かす
        try {
            if (ftm.length >= 6 || deskData) startService(new Intent(this, TiltService.class));
            else stopService(new Intent(this, TiltService.class));
        } catch (Throwable ignored) {
        }
        bg(() -> {
            String r = svc.start(w, h, fxs, fys, fdx, fdy, slop, fox, foy, avg);
            svc.setTiltModel(ftm);
            svc.setLandscape(flxs, flys, fldx, fldy, flox, floy);
            svc.setStrength(strengthPct);
            svc.setDesk(fkxs, fkys, fkdx, fkdy, fkox, fkoy);
            svc.setDeskThreshold(deskThr);
            return r;
        }, s -> {
            if (s.startsWith("ERR") || s.startsWith("エラー")) log(s);
            refreshStatus();
        });
    }

    private void onCalibrate(int mode, boolean land) {
        onCalibrate(mode, land, false);
    }

    private void onCalibrate(int mode, boolean land, boolean desk) {
        final Intent it = new Intent(this, CalibrationActivity.class).putExtra("mode", mode);
        if (land || desk) {
            int sel = spinner.getSelectedItemPosition();
            if (sel <= 0 || sel - 1 >= profiles.size()) {
                log("横画面・机置きの補正は、縦画面の補正データに追加します。先に「使う補正データ」で補正データを選んでください");
                return;
            }
            it.putExtra("land", land).putExtra("desk", desk).putExtra("profile", sel);
        }
        if (svc == null) {
            startActivity(it);
            return;
        }
        // 補正中だと正しく測れないので、先に止める
        bg(() -> svc.stop(), s -> {
            showStatus("停止中");
            startActivity(it);
        });
    }

    private void onDelete() {
        int sel = spinner.getSelectedItemPosition();
        if (sel <= 0 || sel - 1 >= profiles.size()) return;
        profiles.remove(sel - 1);
        Store.save(this, profiles);
        Store.setActive(this, 0);
        refreshProfiles();
    }

    private void log(String s) {
        logView.append(s + "\n");
        // 新しいメッセージが見えるように、先頭までスクロールを戻す
        scroll.post(() -> scroll.smoothScrollTo(0, 0));
    }
}
