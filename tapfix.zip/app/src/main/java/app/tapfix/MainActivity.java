package app.tapfix;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.function.Consumer;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {

    private static final int REQ = 100;

    private ITapService svc;
    private boolean running = false;
    private boolean binding = false;
    private boolean spinnerInit = false;

    private TextView statusView, logView;
    private Button toggle, overlayBtn;
    private TextView slopLabel, offLabel, avgLabel, strLabel, deskLabel;
    private LinearLayout detail;
    private Button detailBtn;
    private TextView statusDetail, ghostLabel;
    // 補正を開始し終えたあとに続ける処理（ガイド付きセットアップ用）
    private Runnable afterStart = null;
    // ガイド付きセットアップの現在のステップ（-1 は動いていない）
    private int wiz = -1;
    private static final int REQ_WIZ = 100;
    private SeekBar seekX, seekY;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            if (svc != null) refreshStatus();
            handler.postDelayed(this, 1000);
        }
    };
    private Spinner spinner;
    private ScrollView scroll;
    private List<Store.Profile> profiles = new ArrayList<>();

    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            svc = ITapService.Stub.asInterface(binder);
            binding = false;
            bg(() -> svc.setLibDir(getApplicationInfo().nativeLibraryDir), s -> refreshStatus());
            syncBackup();
            setupPerms();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            svc = null;
            binding = false;
            running = false;
            showStatus("接続が切れました（Shizukuを確認してください）");
        }
    };

    private final Shizuku.OnRequestPermissionResultListener permListener =
            (requestCode, grantResult) -> {
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    bind();
                } else {
                    log("Shizukuの許可が拒否されました");
                }
            };

    // リスナーを保持して、ボタン操作のあとに「指を離した」処理を呼べるようにするSeekBar
    private static class StepSeekBar extends SeekBar {
        SeekBar.OnSeekBarChangeListener listener;

        StepSeekBar(android.content.Context c) {
            super(c);
        }

        @Override
        public void setOnSeekBarChangeListener(SeekBar.OnSeekBarChangeListener l) {
            listener = l;
            super.setOnSeekBarChangeListener(l);
        }
    }

    // スライドバーの左右に −／＋ ボタンを付ける。タップで1ずつ、長押しで連続して動かす
    private View stepRow(final SeekBar bar) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.addView(stepButton(bar, "−", -1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        row.addView(bar, lp);
        row.addView(stepButton(bar, "+", 1));
        return row;
    }

    private Button stepButton(final SeekBar bar, String label, final int dir) {
        final Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(20);
        b.setPadding(0, 0, 0, 0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(48), dp(48)));
        final Handler h = new Handler(Looper.getMainLooper());
        final Runnable[] rep = new Runnable[1];
        rep[0] = new Runnable() {
            @Override
            public void run() {
                if (!stepBar(bar, dir)) return;
                h.postDelayed(this, 70);
            }
        };
        b.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        v.setPressed(true);
                        stepBar(bar, dir);
                        h.postDelayed(rep[0], 400);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.setPressed(false);
                        h.removeCallbacks(rep[0]);
                        if (bar instanceof StepSeekBar) {
                            SeekBar.OnSeekBarChangeListener l = ((StepSeekBar) bar).listener;
                            if (l != null) l.onStopTrackingTouch(bar);
                        }
                        return true;
                }
                return true;
            }
        });
        return b;
    }

    // 1つ動かす。動かせたら true（端に着いたら false）
    private boolean stepBar(SeekBar bar, int dir) {
        int v = bar.getProgress() + dir;
        if (v < 0 || v > bar.getMax()) return false;
        bar.setProgress(v);
        return true;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(14), dp(14), dp(14));

        statusView = new TextView(this);
        statusView.setTextSize(16);
        statusView.setText("接続中…");
        root.addView(statusView);

        toggle = button("補正を開始", v -> onToggle());
        root.addView(toggle);

        // メッセージ欄：画面全体をスクロールできるようにしたので、ボタンのすぐ下に置く
        logView = new TextView(this);
        logView.setTextSize(12);
        root.addView(logView);

        // いつも見える部分：ガイド付きセットアップと、使う補正データだけ。細かい設定は「詳細設定」にしまう
        Button wizBtn = button("補正のセットアップ（ガイド付き）", v -> wizStart());
        root.addView(wizBtn);
        TextView lbl = new TextView(this);
        lbl.setText("使う補正データ");
        lbl.setPadding(0, dp(12), 0, 0);
        root.addView(lbl);

        spinner = new Spinner(this);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!spinnerInit) return;
                Store.setActive(MainActivity.this, position);
                syncOffsetUi();
                if (running) {
                    log("補正データを切り替えたので、いったん止めてもう一度「開始」を押してください");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        root.addView(spinner);
        Button del = button("選択中の補正データを削除", v -> onDelete());
        root.addView(del);

        detail = new LinearLayout(this);
        detail.setOrientation(LinearLayout.VERTICAL);
        detail.setVisibility(View.GONE);
        detailBtn = button("詳細設定・個別の操作を開く", v -> {
            boolean open = detail.getVisibility() != View.VISIBLE;
            detail.setVisibility(open ? View.VISIBLE : View.GONE);
            detailBtn.setText(open ? "詳細設定・個別の操作を閉じる" : "詳細設定・個別の操作を開く");
        });
        root.addView(detailBtn);
        root.addView(detail);

        statusDetail = new TextView(this);
        statusDetail.setTextSize(12);
        detail.addView(statusDetail);
        overlayBtn = button("タップ位置を表示：オフ", v -> onOverlay());
        detail.addView(overlayBtn);
        CheckBox textBox = new CheckBox(this);
        textBox.setText("上部に座標とズレの数字を表示する");
        textBox.setChecked(Store.getOverlayText(this));
        textBox.setOnCheckedChangeListener((b, checked) -> Store.setOverlayText(this, checked));
        detail.addView(textBox);
        CheckBox corrBox = new CheckBox(this);
        corrBox.setText("タップ表示に補正の情報を描く（青い点・結ぶ線・数字）");
        corrBox.setChecked(Store.getShowCorr(this));
        corrBox.setOnCheckedChangeListener((b, checked) -> Store.setShowCorr(this, checked));
        detail.addView(corrBox);
        CheckBox lightBox = new CheckBox(this);
        lightBox.setText("軽量表示（軌跡・線・数字を省く。ゲーム中の負荷を減らす）");
        lightBox.setChecked(Store.getLight(this));
        lightBox.setOnCheckedChangeListener((b, checked) -> Store.setLight(this, checked));
        detail.addView(lightBox);
        CheckBox outlineBox = new CheckBox(this);
        outlineBox.setText("タップマークと軌跡に縁取り（暗い影）をつける");
        outlineBox.setChecked(Store.getOutline(this));
        outlineBox.setOnCheckedChangeListener((b, checked) -> Store.setOutline(this, checked));
        detail.addView(outlineBox);
        CheckBox ghostBlueBox = new CheckBox(this);
        ghostBlueBox.setText("残像（指を離したあとの丸）を青にする（オフなら白）");
        ghostBlueBox.setChecked(Store.getGhostBlue(this));
        ghostBlueBox.setOnCheckedChangeListener((b, checked) -> Store.setGhostBlue(this, checked));
        detail.addView(ghostBlueBox);
        ghostLabel = new TextView(this);
        ghostLabel.setPadding(0, dp(8), 0, 0);
        detail.addView(ghostLabel);
        SeekBar seekGhost = new StepSeekBar(this);
        seekGhost.setMax(150);
        seekGhost.setProgress(Store.getGhostMs(this) / 10);
        showGhost(Store.getGhostMs(this));
        seekGhost.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                Store.setGhostMs(MainActivity.this, progress * 10);
                showGhost(progress * 10);
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
            }
        });
        detail.addView(stepRow(seekGhost));
        CheckBox tiltBox = new CheckBox(this);
        tiltBox.setText("傾き（ジャイロ）連携を使う（補正データに傾きの情報があるとき）");
        tiltBox.setChecked(Store.getUseTilt(this));
        tiltBox.setOnCheckedChangeListener((b, checked) -> {
            Store.setUseTilt(this, checked);
            if (svc != null && running) applyTiltLive();
        });
        detail.addView(tiltBox);


        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button cal = button("標準で測る（15点）", v -> onCalibrate(0, false));
        Button fine = button("細かく測る（45＋15点）", v -> onCalibrate(1, false));
        row.addView(cal, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(fine, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        detail.addView(row);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        Button test = button("精度テスト", v -> startActivity(new Intent(this, AccuracyActivity.class)));
        Button testEdge = button("端の精度テスト", v -> startActivity(
                new Intent(this, AccuracyActivity.class).putExtra("edge", true)));
        row2.addView(test, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row2.addView(testEdge, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        detail.addView(row2);
        LinearLayout rowL = new LinearLayout(this);
        rowL.setOrientation(LinearLayout.HORIZONTAL);
        Button calL = button("横画面を測る（標準）", v -> onCalibrate(0, true));
        Button fineL = button("横画面を測る（細かく）", v -> onCalibrate(1, true));
        rowL.addView(calL, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        rowL.addView(fineL, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        detail.addView(rowL);
        LinearLayout rowL2 = new LinearLayout(this);
        rowL2.setOrientation(LinearLayout.HORIZONTAL);
        Button testL = button("横画面の精度テスト", v -> startActivity(
                new Intent(this, AccuracyActivity.class).putExtra("land", true)));
        Button testLE = button("横画面の端のテスト", v -> startActivity(
                new Intent(this, AccuracyActivity.class).putExtra("land", true).putExtra("edge", true)));
        rowL2.addView(testL, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        rowL2.addView(testLE, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        detail.addView(rowL2);
        LinearLayout rowD = new LinearLayout(this);
        rowD.setOrientation(LinearLayout.HORIZONTAL);
        Button calD = button("机置きを測る（標準）", v -> onCalibrate(0, false, true));
        Button fineD = button("机置きを測る（細かく）", v -> onCalibrate(1, false, true));
        rowD.addView(calD, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        rowD.addView(fineD, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        detail.addView(rowD);

        slopLabel = new TextView(this);
        slopLabel.setPadding(0, dp(12), 0, 0);
        detail.addView(slopLabel);
        SeekBar seek = new StepSeekBar(this);
        seek.setMax(80);
        seek.setProgress(Store.getSlop(this));
        showSlop(Store.getSlop(this));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                Store.setSlop(MainActivity.this, progress);
                showSlop(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                final int v = bar.getProgress();
                if (svc != null) bg(() -> {
                    svc.setSlop(v);
                    return "";
                }, s -> refreshStatus());
            }
        });
        detail.addView(stepRow(seek));

        CheckBox deskBox = new CheckBox(this);
        deskBox.setText("机置き（傾かず静止）の判定を使う：ジャイロで静止を検出したら、机置き用の補正に切り替える");
        deskBox.setChecked(Store.getDeskOn(this));
        deskBox.setOnCheckedChangeListener((b, checked) -> {
            Store.setDeskOn(this, checked);
            sendDeskThreshold();
        });
        detail.addView(deskBox);
        deskLabel = new TextView(this);
        deskLabel.setPadding(0, dp(8), 0, 0);
        detail.addView(deskLabel);
        SeekBar seekDesk = new StepSeekBar(this);
        seekDesk.setMax(57);
        seekDesk.setProgress(Store.getDeskThr(this) - 3);
        showDeskThr(Store.getDeskThr(this));
        seekDesk.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                Store.setDeskThr(MainActivity.this, progress + 3);
                showDeskThr(progress + 3);
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                sendDeskThreshold();
            }
        });
        detail.addView(stepRow(seekDesk));

        strLabel = new TextView(this);
        strLabel.setPadding(0, dp(12), 0, 0);
        detail.addView(strLabel);
        SeekBar seekStr = new StepSeekBar(this);
        seekStr.setMax(150);
        seekStr.setProgress(Store.getStrength(this));
        showStrength(Store.getStrength(this));
        seekStr.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                Store.setStrength(MainActivity.this, progress);
                showStrength(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                final int v = bar.getProgress();
                if (svc != null) bg(() -> {
                    svc.setStrength(v);
                    return "";
                }, s -> refreshStatus());
            }
        });
        detail.addView(stepRow(seekStr));

        avgLabel = new TextView(this);
        avgLabel.setPadding(0, dp(12), 0, 0);
        detail.addView(avgLabel);
        SeekBar seekAvg = new StepSeekBar(this);
        seekAvg.setMax(100);
        seekAvg.setProgress(Store.getAvg(this));
        showAvg(Store.getAvg(this));
        seekAvg.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                Store.setAvg(MainActivity.this, progress);
                showAvg(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                final int v = bar.getProgress();
                if (svc != null) bg(() -> {
                    svc.setAvg(v);
                    return "";
                }, s -> refreshStatus());
            }
        });
        detail.addView(stepRow(seekAvg));

        offLabel = new TextView(this);
        offLabel.setPadding(0, dp(12), 0, 0);
        detail.addView(offLabel);
        SeekBar.OnSeekBarChangeListener offListener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                showOffset();
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                applyOffset();
            }
        };
        seekX = new StepSeekBar(this);
        seekX.setMax(60);
        seekX.setProgress(30);
        seekX.setOnSeekBarChangeListener(offListener);
        detail.addView(stepRow(seekX));
        seekY = new StepSeekBar(this);
        seekY.setMax(60);
        seekY.setProgress(30);
        seekY.setOnSeekBarChangeListener(offListener);
        detail.addView(stepRow(seekY));
        showOffset();

        TextView help = new TextView(this);
        help.setTextSize(12);
        help.setText("・基本の使い方：上の「補正のセットアップ（ガイド付き）」を押すと、手持ち補正→精度テスト→端の精度テスト→机置き補正→机置き精度テスト→結果の順に、ダイアログで案内します。個別に測り直したいときは、この「詳細設定」から行います。\n"
                + "・傾き連携：「細かく測る」のとき、タップの瞬間の端末の傾き（左右・前後）も一緒に記録します。傾きで補正が変わる効果があると判断されたときだけ、補正データに傾きの情報が入ります。補正中は傾きを読み取り続けるため、小さな通知が出ます。\n"
                + "・タップ位置の平均時間：押した直後は指の接触面が広がる途中で、位置が不安定です。この時間だけ位置をためて平均し、その位置を押した場所として送ります。長いほどブレは減りますが、反応が少し遅れます（0でオフ）。\n"
                + "・画面の端の補正：「細かく測る」は画面の端（約5%）まで測ります。端の外側の少しの範囲は、傾きを延長して補正します。「端の精度テスト」で端のズレを確認できます。\n"
                + "・インストール後、Shizukuに接続すると、「他のアプリの上に重ねて表示」の許可、電池の使用「制限なし」、「権限を消して空き容量を増やす」のオフを自動で設定します（入れ直したときだけ、1回行います）。タップ位置の表示は、最初からオンです。\n"
                + "・全体オフセット：精度テストの「全体の偏り」が x−7 なら、右へ +7 のように、逆向きに動かします（補正をオンにして測った偏りが目安）。補正中でもスライダーで即反映され、補正データごとに保存されます。\n"
                + "・精度の調整：「細かく測る」は格子45点＋ランダム15点を測り、タップごとのブレを平均して滑らかに補正します（保存時にブレの大きさも出ます）。「精度テスト」で、狙いとのズレを px / mm で測れます。補正を入れた状態と切った状態で比べてください。\n"
                + "・フリック抑制：押した位置から指がこの距離より動くまでは、位置を動かさずタップとして扱います（0でオフ）。大きいほど意図しないフリックが減りますが、スクロールやフリック入力の出だしが少し重くなります。スライダーを動かすと補正中でも即反映されます。\n"
                + "・補正が効かなくなったり、画面が操作できなくなったら、音量＋と音量−を同時に2秒押し続けると補正を止められます。\n"
                + "・横画面の補正：「使う補正データ」を選んで「横画面を測る」を押すと、画面が横向きになるので、普段横で持つ持ち方で測ります。選んだ補正データに追加で保存され（縦の補正はそのまま）、横画面にしたとき自動で切り替わります。左向き・右向きのどちらの横でも同じ補正を使います。傾き連携・全体オフセットのスライダーは縦画面用です。横画面のオフセットは「横画面の精度テスト」→「偏りを補正に反映」で調整できます。補正データを選び直したら、停止して「補正を開始」を押し直してください。\n"
                + "・精度テスト中も傾きを測っています。縦画面で「偏りを補正に反映」を押すと、補正オンで測った点（12点以上）から傾きによるズレの残りを解析し、良くなると判断したときだけ傾き補正を更新（傾き補正がなければ新規作成）して、全体オフセットと一緒に反映します。同じ持ち方・同じ補正状態で何回か測ってから押すほど確実です。\n"
                + "・補正の強さ：格子と傾きによる補正の量に割合をかけます（100%が測った通り）。補正が強すぎると感じるときは、90%や80%に下げてみてください。全体オフセットにはかかりません。\n"
                + "・指が2本以上のとき（ピンチなど）は、フリック抑制とタップ位置の平均を自動で外して、動きをそのまま通します。\n"
                + "・机置き：スマホを机などに置いて（傾かず静止して）人差し指で操作するときは、手で持って親指で操作するときと補正が違います。「使う補正データ」を選んで、スマホを机に置いたまま「机置きを測る」を押すと、その補正データに机置き用の補正が追加されます。補正中は、ジャイロで1秒間の揺れを見て、静止していれば机置き用に、手で持っていれば普段の補正（傾き連携を含む）に、タップの瞬間ごとに自動で切り替わります。状態表示に「判定」と揺れの大きさが出るので、手持ちと机置きで値を見て、判定のしきい値を合わせてください。机置き用のオフセットは、机に置いたまま精度テスト→「偏りを補正に反映」で調整できます（縦画面のみ）。\n"
                + "・補正データのバックアップ：補正データは、Shizukuの常駐サービス側にも自動で控えを保存します（/data/local/tmp と /sdcard/tapfix）。アンインストールして入れ直しても、Shizukuを起動して接続すると、控えにだけある補正データが自動で戻ります（名前が同じものは戻しません）。\n"
                + "・補正の入る向き：縦は常に補正。横は、横画面の補正を測ってあるときだけ補正（なければ素通し）。上下逆さまの縦は素通しです。\n"
                + "・タップ表示：指の位置は白線の丸（中心の小さな赤点）、補正後の位置は青い点です（「補正の情報を描く」をオフにすると、白い丸・赤い点・指の軌跡だけになります）。指を離すと一瞬残り、薄くなって消えます。ゲーム中に重いときは「軽量表示」をオンにしてください。\n"
                + "・端末を再起動したら、Shizukuを起動し直してから「補正を開始」を押してください。");
        help.setPadding(0, dp(10), 0, dp(6));
        detail.addView(help);

        // 画面に収まらない分はスクロールで見られるように、全体を ScrollView に入れる
        scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
        Shizuku.addRequestPermissionResultListener(permListener);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshProfiles();
        syncBackup();
        // タップ位置の表示を「オン」にしていたのに止められていたら、立ち上げ直す
        ensureOverlay();
        updateOverlayBtn();
        if (svc == null) {
            connect();
        } else {
            refreshStatus();
        }
        handler.postDelayed(poll, 1000);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(poll);
        super.onPause();
    }

    // 補正中に「傾き連携」のオン/オフを切り替えたとき、すぐ反映する
    private void applyTiltLive() {
        int sel = spinner.getSelectedItemPosition();
        float[] tm = new float[0];
        if (sel > 0 && sel - 1 < profiles.size()) {
            Store.Profile p = profiles.get(sel - 1);
            if (p.tilt != null && p.tilt.length >= 6 && Store.getUseTilt(this)) tm = p.tilt;
        }
        final float[] ftm = tm;
        boolean deskAny = sel > 0 && sel - 1 < profiles.size() && profiles.get(sel - 1).deskXs != null;
        try {
            if (ftm.length >= 6 || deskAny) startService(new Intent(this, TiltService.class));
            else stopService(new Intent(this, TiltService.class));
        } catch (Throwable ignored) {
        }
        bg(() -> {
            svc.setTiltModel(ftm);
            return "";
        }, s -> refreshStatus());
    }

    // 補正データを、アンインストールしても残る場所（Shizukuの常駐サービス側）にバックアップする。
    // 入れ直した直後は、バックアップにだけある補正データを（名前が重複しないものだけ）復元する
    private void syncBackup() {
        final ITapService s = svc;
        if (s == null) return;
        new Thread(() -> {
            try {
                String msg = null;
                if (!Store.restoreChecked(this)) {
                    String b = s.readBackup();
                    if (b != null && b.length() > 0) {
                        int added = Store.mergeFromBackup(this, b);
                        if (added < 0) return;
                        if (added > 0) msg = "バックアップから補正データを " + added + " 件復元しました";
                    }
                    Store.setRestoreChecked(this);
                }
                String cur = Store.dump(this);
                if (!cur.equals(Store.lastBackedUp(this))) {
                    String w = Store.wrapBackup(this, cur);
                    if (w.length() > 0 && s.writeBackup(w)) Store.setLastBackedUp(this, cur);
                }
                if (msg != null) {
                    final String m = msg;
                    runOnUiThread(() -> {
                        refreshProfiles();
                        log(m);
                    });
                }
            } catch (Throwable ignored) {
            }
        }, "tapfix-backup").start();
    }

    private void showDeskThr(int milli) {
        deskLabel.setText(String.format(java.util.Locale.US,
                "机置きの判定しきい値（1秒間の回転の揺れがこれより小さいと机置き）: %.3f rad/s", milli / 1000.0));
    }

    private void sendDeskThreshold() {
        final float thr = Store.getDeskOn(this) ? Store.getDeskThr(this) / 1000f : 0f;
        if (svc != null) bg(() -> {
            svc.setDeskThreshold(thr);
            return "";
        }, s -> refreshStatus());
    }

    private void showGhost(int ms) {
        ghostLabel.setText(ms == 0 ? "タップマークの残像：なし（指を離すとすぐ消える）"
                : "タップマークの残像：指を離してから " + String.format(java.util.Locale.US, "%.2f", ms / 1000.0) + " 秒で消える");
    }

    private void showStrength(int pct) {
        strLabel.setText("補正の強さ（格子・傾きの補正にかける割合。全体オフセットは別）: " + pct + " %");
    }

    private void showAvg(int ms) {
        avgLabel.setText("タップ位置の平均時間（押した直後の位置のブレを平均）: " + (ms == 0 ? "オフ" : ms + " ms"));
    }

    private void showOffset() {
        offLabel.setText(String.format(Locale.US,
                "全体オフセット（選択中の補正データ）: 右へ %+d px、下へ %+d px",
                seekX.getProgress() - 30, seekY.getProgress() - 30));
    }

    // 選択中の補正データのオフセットをスライダーに反映する（「補正なし」のときは無効）
    private void syncOffsetUi() {
        int sel = spinner.getSelectedItemPosition();
        boolean ok = sel > 0 && sel - 1 < profiles.size();
        float ox = ok ? profiles.get(sel - 1).offX : 0, oy = ok ? profiles.get(sel - 1).offY : 0;
        seekX.setEnabled(ok);
        seekY.setEnabled(ok);
        seekX.setProgress(Math.round(ox) + 30);
        seekY.setProgress(Math.round(oy) + 30);
        showOffset();
    }

    private void applyOffset() {
        int sel = spinner.getSelectedItemPosition();
        if (sel <= 0 || sel - 1 >= profiles.size()) return;
        Store.Profile p = profiles.get(sel - 1);
        p.offX = seekX.getProgress() - 30;
        p.offY = seekY.getProgress() - 30;
        Store.save(this, profiles);
        final float ox = p.offX, oy = p.offY;
        if (svc != null && running) {
            bg(() -> {
                svc.setOffset(ox, oy);
                return "";
            }, s -> refreshStatus());
        }
    }

    private void showSlop(int v) {
        slopLabel.setText("フリック抑制（指のブレを無視する距離）: " + (v == 0 ? "オフ" : v + " px"));
    }

    private void updateOverlayBtn() {
        overlayBtn.setText(OverlayService.running ? "タップ位置を表示：オン（押すと消す）" : "タップ位置を表示：オフ（押すと表示）");
    }

    private void onOverlay() {
        if (OverlayService.running) {
            Store.setOverlay(this, false);
            stopService(new Intent(this, OverlayService.class));
            OverlayService.running = false;
            updateOverlayBtn();
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            log("「他のアプリの上に重ねて表示」を許可してから、戻ってもう一度押してください");
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        Store.setOverlay(this, true);
        startService(new Intent(this, OverlayService.class));
        OverlayService.running = true;
        updateOverlayBtn();
    }

    @Override
    protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener);
        super.onDestroy();
    }

    private int versionCode() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Throwable t) {
            return 1;
        }
    }

    private Shizuku.UserServiceArgs args() {
        // daemon(true): アプリを閉じても補正が動き続ける
        return new Shizuku.UserServiceArgs(new ComponentName(getPackageName(), TapService.class.getName()))
                .daemon(true)
                .processNameSuffix("tapfix")
                .version(versionCode());
    }

    private void connect() {
        try {
            if (!Shizuku.pingBinder()) {
                showStatus("Shizukuが動いていません。Shizukuアプリで開始してから、この画面に戻ってください");
                return;
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(REQ);
                return;
            }
            bind();
        } catch (Throwable t) {
            log("エラー: " + t);
        }
    }

    private void bind() {
        if (binding || svc != null) return;
        try {
            binding = true;
            Shizuku.bindUserService(args(), conn);
        } catch (Throwable t) {
            binding = false;
            log("bind失敗: " + t);
        }
    }

    private void bg(Callable<String> c, Consumer<String> done) {
        new Thread(() -> {
            String r;
            try {
                r = c.call();
            } catch (Throwable t) {
                r = "エラー: " + t;
            }
            final String out = r;
            runOnUiThread(() -> done.accept(out));
        }).start();
    }

    private void refreshStatus() {
        if (svc == null) return;
        bg(() -> svc.status(), this::showStatus);
    }

    private void showStatus(String s) {
        running = s.startsWith("動作中");
        // いつも見える所には1行目だけ。くわしい状態（判定・オフセットなど）は「詳細設定」の中に出す
        int nl = s.indexOf('\n');
        statusView.setText(nl > 0 ? s.substring(0, nl) : s);
        if (statusDetail != null) statusDetail.setText(s);
        toggle.setText(running ? "補正を停止" : "補正を開始");
    }

    private void refreshProfiles() {
        profiles = Store.load(this);
        List<String> names = new ArrayList<>();
        names.add("補正なし（素通し）");
        for (Store.Profile p : profiles) {
            String sfx = (p.lxs != null ? "（横あり）" : "") + (p.deskXs != null ? "（机あり）" : "");
            names.add(p.name + sfx);
        }
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, names);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerInit = false;
        spinner.setAdapter(ad);
        int a = Math.min(Store.getActive(this), names.size() - 1);
        spinner.setSelection(Math.max(0, a));
        spinnerInit = true;
        syncOffsetUi();
    }

    private void onToggle() {
        if (svc == null) {
            connect();
            return;
        }
        if (running) {
            stopService(new Intent(this, TiltService.class));
            bg(() -> svc.stop(), s -> refreshStatus());
            return;
        }
        int sel = spinner.getSelectedItemPosition();
        float[] none = new float[0];
        float[] xs = none, ys = none, dx = none, dy = none;
        float[] lxs = none, lys = none, ldx = none, ldy = none;
        float lox = 0, loy = 0;
        float[] kxs = none, kys = none, kdx = none, kdy = none;
        float kox = 0, koy = 0;
        float ox = 0, oy = 0;
        float[] tm = new float[0];
        if (sel > 0 && sel - 1 < profiles.size()) {
            Store.Profile p = profiles.get(sel - 1);
            if (p.tilt != null && p.tilt.length >= 6 && Store.getUseTilt(this)) tm = p.tilt;
            ox = p.offX;
            oy = p.offY;
            xs = p.xs;
            ys = p.ys;
            dx = p.dx;
            dy = p.dy;
            if (p.deskXs != null) {
                kxs = p.deskXs;
                kys = p.deskYs;
                kdx = p.deskDx;
                kdy = p.deskDy;
                kox = p.deskOffX;
                koy = p.deskOffY;
            }
            if (p.lxs != null) {
                lxs = p.lxs;
                lys = p.lys;
                ldx = p.ldx;
                ldy = p.ldy;
                lox = p.loffX;
                loy = p.loffY;
            }
        }
        final float[] flxs = lxs, flys = lys, fldx = ldx, fldy = ldy;
        final float flox = lox, floy = loy;
        final float[] fkxs = kxs, fkys = kys, fkdx = kdx, fkdy = kdy;
        final float fkox = kox, fkoy = koy;
        final boolean deskData = kxs.length >= 2;
        final float deskThr = Store.getDeskOn(this) ? Store.getDeskThr(this) / 1000f : 0f;
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        final int w = Math.min(dm.widthPixels, dm.heightPixels);
        final int h = Math.max(dm.widthPixels, dm.heightPixels);
        final float[] fxs = xs, fys = ys, fdx = dx, fdy = dy;
        final int slop = Store.getSlop(this);
        final float fox = ox, foy = oy;
        final int avg = Store.getAvg(this);
        final int strengthPct = Store.getStrength(this);
        final float[] ftm = tm;
        // 傾きの情報があるときだけ、傾きを送り続けるサービスを動かす
        try {
            if (ftm.length >= 6 || deskData) startService(new Intent(this, TiltService.class));
            else stopService(new Intent(this, TiltService.class));
        } catch (Throwable ignored) {
        }
        bg(() -> {
            String r = svc.start(w, h, fxs, fys, fdx, fdy, slop, fox, foy, avg);
            svc.setTiltModel(ftm);
            svc.setLandscape(flxs, flys, fldx, fldy, flox, floy);
            svc.setStrength(strengthPct);
            svc.setScale(Store.pxScale(MainActivity.this));
            svc.setDesk(fkxs, fkys, fkdx, fkdy, fkox, fkoy);
            svc.setDeskThreshold(deskThr);
            return r;
        }, s -> {
            boolean failed = s.startsWith("ERR") || s.startsWith("エラー");
            if (failed) log(s);
            refreshStatus();
            Runnable r = afterStart;
            afterStart = null;
            if (r != null) {
                if (failed) {
                    wiz = -1;
                    new AlertDialog.Builder(this).setTitle("補正を開始できませんでした")
                            .setMessage(s + "\n\nShizukuが動いているか確認してから、もう一度セットアップを始めてください。")
                            .setPositiveButton("閉じる", null).show();
                } else {
                    r.run();
                }
            }
        });
    }

    private void onCalibrate(int mode, boolean land) {
        onCalibrate(mode, land, false);
    }

    private void onCalibrate(int mode, boolean land, boolean desk) {
        final Intent it = new Intent(this, CalibrationActivity.class).putExtra("mode", mode);
        if (land || desk) {
            int sel = spinner.getSelectedItemPosition();
            if (sel <= 0 || sel - 1 >= profiles.size()) {
                log("横画面・机置きの補正は、縦画面の補正データに追加します。先に「使う補正データ」で補正データを選んでください");
                return;
            }
            it.putExtra("land", land).putExtra("desk", desk).putExtra("profile", sel);
        }
        if (svc == null) {
            startActivity(it);
            return;
        }
        // 補正中だと正しく測れないので、先に止める
        bg(() -> svc.stop(), s -> {
            showStatus("停止中");
            startActivity(it);
        });
    }

    private void onDelete() {
        int sel = spinner.getSelectedItemPosition();
        if (sel <= 0 || sel - 1 >= profiles.size()) return;
        profiles.remove(sel - 1);
        Store.save(this, profiles);
        Store.setActive(this, 0);
        refreshProfiles();
    }

    // ---------------- ガイド付きセットアップ ----------------
    // 手持ち補正 → 精度テスト → 端の精度テスト → 机置き補正 → 机置き精度テスト → 補正結果 の順に、ダイアログで案内する

    private static final String[] WIZ_TITLE = {
            "手持ちの補正", "精度テスト", "端の精度テスト", "机置きの補正", "机置きの精度テスト", "補正の結果"};

    private void wizStart() {
        if (svc == null) {
            log("Shizukuに接続できていません。Shizukuを起動して、この画面に戻ってからもう一度押してください");
            connect();
            return;
        }
        Store.clearLastTests(this);
        wiz = 0;
        wizShow();
    }

    private String wizMessage() {
        switch (wiz) {
            case 0:
                return "普段、スマホを手で持って操作する持ち方で、画面に出る赤い十字の中心を、いつも使う指（親指など）でタップしていきます。\n\n"
                        + "「細かく測る」（60点・数分）で測ります。測り終えたら、名前をつけて保存してください。\n"
                        + "測っている間、補正は止まります。";
            case 1:
                return "いま測った補正が効いた状態で、精度を確認します。赤い円を12か所タップしてください。\n\n"
                        + "終わったら「偏りを補正に反映」を押すと、全体のズレと傾きの補正が調整されます（何回かテストしてから押すほど確実です）。\n"
                        + "終わったら戻るキーで、次へ進みます。";
            case 2:
                return "画面の端の精度を確認します。端の円をタップしてください。\n\n"
                        + "終わったら戻るキーで、次へ進みます。";
            case 3:
                return "ここからは机置き用です。スマホを机などの平らな場所に置いて、動かない状態にしてください。\n\n"
                        + "手で持たずに、人差し指で、赤い十字の中心をタップしていきます。"
                        + "スマホが静止しているときだけ、この補正に自動で切り替わります。\n"
                        + "測り終えたら保存してください（保存先は、いま選ばれている補正データです）。";
            case 4:
                return "スマホを机に置いたまま、人差し指で精度を確認します。補正は、いま測った机置き用に自動で切り替わります。\n\n"
                        + "終わったら「偏りを補正に反映」で、机置き用のオフセットを調整できます。戻るキーで、結果へ進みます。";
            default:
                return wizSummary();
        }
    }

    private String wizSummary() {
        StringBuilder sb = new StringBuilder();
        List<Store.Profile> l = Store.load(this);
        int a = Store.getActive(this);
        if (a >= 1 && a <= l.size()) {
            Store.Profile p = l.get(a - 1);
            sb.append("補正データ「").append(p.name).append("」\n");
            sb.append("・手持ち：格子 ").append(p.xs.length).append("×").append(p.ys.length)
                    .append(" / 傾き補正 ").append(p.tilt != null ? "あり" : "なし")
                    .append(String.format(java.util.Locale.US, " / 全体オフセット x%+.0f y%+.0f px", p.offX, p.offY)).append("\n");
            sb.append("・机置き：").append(p.deskXs != null
                    ? String.format(java.util.Locale.US, "あり / オフセット x%+.0f y%+.0f px", p.deskOffX, p.deskOffY)
                    : "なし").append("\n");
        } else {
            sb.append("補正データが選ばれていません\n");
        }
        sb.append("\n精度テストの結果（最後に測ったもの）\n");
        String[][] rows = {{"hand", "手持ち"}, {"edge", "端"}, {"desk", "机置き"}};
        for (String[] r : rows) {
            String t = Store.getLastTest(this, r[0]);
            sb.append("・").append(r[1]).append("：").append(t.isEmpty() ? "未測定" : t).append("\n");
        }
        sb.append("\nこのあと、手持ちと机置きは自動で切り替わります。傾いたり強すぎたりしたら、詳細設定の「補正の強さ」などで調整できます。");
        return sb.toString();
    }

    private void wizShow() {
        if (wiz < 0) return;
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle("ステップ " + (wiz + 1) + " / 6：" + WIZ_TITLE[wiz])
                .setMessage(wizMessage())
                .setCancelable(false);
        if (wiz == 5) {
            b.setPositiveButton("完了", (d, w) -> wiz = -1);
        } else {
            b.setPositiveButton("開始", (d, w) -> wizRun());
            b.setNeutralButton("飛ばす", (d, w) -> {
                wiz++;
                wizShow();
            });
            b.setNegativeButton("中止", (d, w) -> wiz = -1);
        }
        b.show();
    }

    private void wizRun() {
        final int sel = spinner.getSelectedItemPosition();
        switch (wiz) {
            case 0:
                wizStop(() -> startActivityForResult(
                        new Intent(this, CalibrationActivity.class).putExtra("mode", 1), REQ_WIZ));
                break;
            case 1:
                wizCorrection(false, () -> startActivityForResult(new Intent(this, AccuracyActivity.class), REQ_WIZ));
                break;
            case 2:
                wizCorrection(false, () -> startActivityForResult(
                        new Intent(this, AccuracyActivity.class).putExtra("edge", true), REQ_WIZ));
                break;
            case 3:
                if (sel <= 0 || sel - 1 >= profiles.size()) {
                    wizNeedProfile();
                    return;
                }
                wizStop(() -> startActivityForResult(new Intent(this, CalibrationActivity.class)
                        .putExtra("mode", 1).putExtra("desk", true).putExtra("profile", sel), REQ_WIZ));
                break;
            default:
                // 机置きの補正を読み込ませるため、補正をいったん止めて入れ直す
                wizCorrection(true, () -> startActivityForResult(new Intent(this, AccuracyActivity.class), REQ_WIZ));
                break;
        }
    }

    private void wizNeedProfile() {
        wiz = -1;
        new AlertDialog.Builder(this).setTitle("補正データがありません")
                .setMessage("先に「手持ちの補正」を測って保存してください。もう一度、セットアップを最初から始めてください。")
                .setPositiveButton("閉じる", null).show();
    }

    // 補正を止めてから続ける（測っている間は補正を止める）
    private void wizStop(Runnable next) {
        if (svc == null) {
            next.run();
            return;
        }
        bg(() -> svc.stop(), s -> {
            showStatus("停止中");
            next.run();
        });
    }

    // 補正を動かしてから続ける。入れ直しが必要なとき（restart）は、いったん止めてから開始する
    private void wizCorrection(boolean restart, Runnable next) {
        if (svc == null) {
            wiz = -1;
            log("Shizukuに接続できていません");
            return;
        }
        if (running && !restart) {
            next.run();
            return;
        }
        final Runnable begin = () -> {
            refreshProfiles();
            afterStart = next;
            onToggle();
        };
        if (running) {
            bg(() -> svc.stop(), s -> {
                running = false;
                begin.run();
            });
        } else {
            begin.run();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_WIZ || wiz < 0) return;
        refreshProfiles();
        if ((wiz == 0 || wiz == 3) && resultCode != RESULT_OK) {
            // 保存されなかった：やり直すか選んでもらう
            new AlertDialog.Builder(this)
                    .setTitle("保存されませんでした")
                    .setMessage("この補正は保存されていません。もう一度測りますか？")
                    .setCancelable(false)
                    .setPositiveButton("もう一度測る", (d, w) -> wizRun())
                    .setNeutralButton("飛ばす", (d, w) -> {
                        wiz++;
                        wizShow();
                    })
                    .setNegativeButton("中止", (d, w) -> wiz = -1)
                    .show();
            return;
        }
        wiz++;
        wizShow();
    }

    // ---------------- 権限の自動設定・タップ表示の自動起動 ----------------

    // 入れ直した直後に、「他のアプリの上に重ねて表示」「電池の使用を制限なし」「権限を消して空き容量を増やす」をオフ、を自動で済ませる
    private void setupPerms() {
        final ITapService s = svc;
        if (s == null || Store.permSetupDone(this)) return;
        new Thread(() -> {
            try {
                String r = s.setupPermissions(getPackageName());
                if (r != null && r.startsWith("OK")) {
                    Store.setPermSetupDone(this);
                    runOnUiThread(() -> {
                        ensureOverlay();
                        updateOverlayBtn();
                    });
                } else if (r != null) {
                    final String m = r;
                    runOnUiThread(() -> log("権限の自動設定に失敗しました：\n" + m));
                }
            } catch (Throwable ignored) {
            }
        }, "tapfix-perms").start();
    }

    private void ensureOverlay() {
        if (Store.getOverlay(this) && !OverlayService.running && Settings.canDrawOverlays(this)) {
            try {
                startService(new Intent(this, OverlayService.class));
                OverlayService.running = true;
            } catch (Throwable ignored) {
            }
        }
    }

    private void log(String s) {
        logView.append(s + "\n");
        // 新しいメッセージが見えるように、先頭までスクロールを戻す
        scroll.post(() -> scroll.smoothScrollTo(0, 0));
    }
}
