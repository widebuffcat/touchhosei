package app.tapfix;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.function.Consumer;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {

    private static final int REQ = 100;

    private ITapService svc;
    private boolean running = false;
    private boolean binding = false;
    private boolean spinnerInit = false;

    private TextView statusView, logView;
    private Button toggle, overlayBtn;
    private TextView slopLabel, offLabel, avgLabel;
    private SeekBar seekX, seekY;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            if (svc != null) refreshStatus();
            handler.postDelayed(this, 1000);
        }
    };
    private Spinner spinner;
    private ScrollView scroll;
    private List<Store.Profile> profiles = new ArrayList<>();

    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            svc = ITapService.Stub.asInterface(binder);
            binding = false;
            bg(() -> svc.setLibDir(getApplicationInfo().nativeLibraryDir), s -> refreshStatus());
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            svc = null;
            binding = false;
            running = false;
            showStatus("接続が切れました（Shizukuを確認してください）");
        }
    };

    private final Shizuku.OnRequestPermissionResultListener permListener =
            (requestCode, grantResult) -> {
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    bind();
                } else {
                    log("Shizukuの許可が拒否されました");
                }
            };

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(14), dp(14), dp(14));

        statusView = new TextView(this);
        statusView.setTextSize(16);
        statusView.setText("接続中…");
        root.addView(statusView);

        toggle = button("補正を開始", v -> onToggle());
        root.addView(toggle);

        // メッセージ欄：画面全体をスクロールできるようにしたので、ボタンのすぐ下に置く
        logView = new TextView(this);
        logView.setTextSize(12);
        root.addView(logView);

        overlayBtn = button("タップ位置を表示：オフ", v -> onOverlay());
        root.addView(overlayBtn);
        CheckBox textBox = new CheckBox(this);
        textBox.setText("上部に座標とズレの数字を表示する");
        textBox.setChecked(Store.getOverlayText(this));
        textBox.setOnCheckedChangeListener((b, checked) -> Store.setOverlayText(this, checked));
        root.addView(textBox);

        TextView lbl = new TextView(this);
        lbl.setText("使う補正データ");
        lbl.setPadding(0, dp(12), 0, 0);
        root.addView(lbl);

        spinner = new Spinner(this);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!spinnerInit) return;
                Store.setActive(MainActivity.this, position);
                syncOffsetUi();
                if (running) {
                    log("補正データを切り替えたので、いったん止めてもう一度「開始」を押してください");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        root.addView(spinner);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button cal = button("標準で測る（15点）", v -> onCalibrate(0));
        Button fine = button("細かく測る（45＋15点）", v -> onCalibrate(1));
        row.addView(cal, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(fine, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(row);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        Button test = button("精度テスト", v -> startActivity(new Intent(this, AccuracyActivity.class)));
        Button testEdge = button("端の精度テスト", v -> startActivity(
                new Intent(this, AccuracyActivity.class).putExtra("edge", true)));
        row2.addView(test, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row2.addView(testEdge, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(row2);
        Button del = button("選択中を削除", v -> onDelete());
        root.addView(del);

        slopLabel = new TextView(this);
        slopLabel.setPadding(0, dp(12), 0, 0);
        root.addView(slopLabel);
        SeekBar seek = new SeekBar(this);
        seek.setMax(80);
        seek.setProgress(Store.getSlop(this));
        showSlop(Store.getSlop(this));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                Store.setSlop(MainActivity.this, progress);
                showSlop(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                final int v = bar.getProgress();
                if (svc != null) bg(() -> {
                    svc.setSlop(v);
                    return "";
                }, s -> refreshStatus());
            }
        });
        root.addView(seek);

        avgLabel = new TextView(this);
        avgLabel.setPadding(0, dp(12), 0, 0);
        root.addView(avgLabel);
        SeekBar seekAvg = new SeekBar(this);
        seekAvg.setMax(20);
        seekAvg.setProgress(Store.getAvg(this) / 5);
        showAvg(Store.getAvg(this));
        seekAvg.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                Store.setAvg(MainActivity.this, progress * 5);
                showAvg(progress * 5);
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                final int v = bar.getProgress() * 5;
                if (svc != null) bg(() -> {
                    svc.setAvg(v);
                    return "";
                }, s -> refreshStatus());
            }
        });
        root.addView(seekAvg);

        offLabel = new TextView(this);
        offLabel.setPadding(0, dp(12), 0, 0);
        root.addView(offLabel);
        SeekBar.OnSeekBarChangeListener offListener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                showOffset();
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                applyOffset();
            }
        };
        seekX = new SeekBar(this);
        seekX.setMax(60);
        seekX.setProgress(30);
        seekX.setOnSeekBarChangeListener(offListener);
        root.addView(seekX);
        seekY = new SeekBar(this);
        seekY.setMax(60);
        seekY.setProgress(30);
        seekY.setOnSeekBarChangeListener(offListener);
        root.addView(seekY);
        showOffset();

        TextView help = new TextView(this);
        help.setTextSize(12);
        help.setText("・タップ位置の平均時間：押した直後は指の接触面が広がる途中で、位置が不安定です。この時間だけ位置をためて平均し、その位置を押した場所として送ります。長いほどブレは減りますが、反応が少し遅れます（0でオフ）。\n"
                + "・画面の端の補正：「細かく測る」は画面の端（約5%）まで測ります。端の外側の少しの範囲は、傾きを延長して補正します。「端の精度テスト」で端のズレを確認できます。\n"
                + "・タップ位置の表示が勝手に消えるときは、端末の設定でこのアプリの電池の使用を「制限なし（最適化しない）」にしてください。\n"
                + "・全体オフセット：精度テストの「全体の偏り」が x−7 なら、右へ +7 のように、逆向きに動かします（補正をオンにして測った偏りが目安）。補正中でもスライダーで即反映され、補正データごとに保存されます。\n"
                + "・精度の調整：「細かく測る」は格子45点＋ランダム15点を測り、タップごとのブレを平均して滑らかに補正します（保存時にブレの大きさも出ます）。「精度テスト」で、狙いとのズレを px / mm で測れます。補正を入れた状態と切った状態で比べてください。\n"
                + "・フリック抑制：押した位置から指がこの距離より動くまでは、位置を動かさずタップとして扱います（0でオフ）。大きいほど意図しないフリックが減りますが、スクロールやフリック入力の出だしが少し重くなります。スライダーを動かすと補正中でも即反映されます。\n"
                + "・補正が効かなくなったり、画面が操作できなくなったら、音量＋と音量−を同時に2秒押し続けると補正を止められます。\n"
                + "・補正は縦画面のみ有効です（横画面では位置はそのまま、補正だけ無効になります）。\n"
                + "・端末を再起動したら、Shizukuを起動し直してから「補正を開始」を押してください。");
        help.setPadding(0, dp(10), 0, dp(6));
        root.addView(help);

        // 画面に収まらない分はスクロールで見られるように、全体を ScrollView に入れる
        scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
        Shizuku.addRequestPermissionResultListener(permListener);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshProfiles();
        // タップ位置の表示を「オン」にしていたのに止められていたら、立ち上げ直す
        if (Store.getOverlay(this) && !OverlayService.running && Settings.canDrawOverlays(this)) {
            try {
                startService(new Intent(this, OverlayService.class));
                OverlayService.running = true;
            } catch (Throwable ignored) {
            }
        }
        updateOverlayBtn();
        if (svc == null) {
            connect();
        } else {
            refreshStatus();
        }
        handler.postDelayed(poll, 1000);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(poll);
        super.onPause();
    }

    private void showAvg(int ms) {
        avgLabel.setText("タップ位置の平均時間（押した直後の位置のブレを平均）: " + (ms == 0 ? "オフ" : ms + " ms"));
    }

    private void showOffset() {
        offLabel.setText(String.format(Locale.US,
                "全体オフセット（選択中の補正データ）: 右へ %+d px、下へ %+d px",
                seekX.getProgress() - 30, seekY.getProgress() - 30));
    }

    // 選択中の補正データのオフセットをスライダーに反映する（「補正なし」のときは無効）
    private void syncOffsetUi() {
        int sel = spinner.getSelectedItemPosition();
        boolean ok = sel > 0 && sel - 1 < profiles.size();
        float ox = ok ? profiles.get(sel - 1).offX : 0, oy = ok ? profiles.get(sel - 1).offY : 0;
        seekX.setEnabled(ok);
        seekY.setEnabled(ok);
        seekX.setProgress(Math.round(ox) + 30);
        seekY.setProgress(Math.round(oy) + 30);
        showOffset();
    }

    private void applyOffset() {
        int sel = spinner.getSelectedItemPosition();
        if (sel <= 0 || sel - 1 >= profiles.size()) return;
        Store.Profile p = profiles.get(sel - 1);
        p.offX = seekX.getProgress() - 30;
        p.offY = seekY.getProgress() - 30;
        Store.save(this, profiles);
        final float ox = p.offX, oy = p.offY;
        if (svc != null && running) {
            bg(() -> {
                svc.setOffset(ox, oy);
                return "";
            }, s -> refreshStatus());
        }
    }

    private void showSlop(int v) {
        slopLabel.setText("フリック抑制（指のブレを無視する距離）: " + (v == 0 ? "オフ" : v + " px"));
    }

    private void updateOverlayBtn() {
        overlayBtn.setText(OverlayService.running ? "タップ位置を表示：オン（押すと消す）" : "タップ位置を表示：オフ（押すと表示）");
    }

    private void onOverlay() {
        if (OverlayService.running) {
            Store.setOverlay(this, false);
            stopService(new Intent(this, OverlayService.class));
            OverlayService.running = false;
            updateOverlayBtn();
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            log("「他のアプリの上に重ねて表示」を許可してから、戻ってもう一度押してください");
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        Store.setOverlay(this, true);
        startService(new Intent(this, OverlayService.class));
        OverlayService.running = true;
        updateOverlayBtn();
    }

    @Override
    protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener);
        super.onDestroy();
    }

    private int versionCode() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Throwable t) {
            return 1;
        }
    }

    private Shizuku.UserServiceArgs args() {
        // daemon(true): アプリを閉じても補正が動き続ける
        return new Shizuku.UserServiceArgs(new ComponentName(getPackageName(), TapService.class.getName()))
                .daemon(true)
                .processNameSuffix("tapfix")
                .version(versionCode());
    }

    private void connect() {
        try {
            if (!Shizuku.pingBinder()) {
                showStatus("Shizukuが動いていません。Shizukuアプリで開始してから、この画面に戻ってください");
                return;
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(REQ);
                return;
            }
            bind();
        } catch (Throwable t) {
            log("エラー: " + t);
        }
    }

    private void bind() {
        if (binding || svc != null) return;
        try {
            binding = true;
            Shizuku.bindUserService(args(), conn);
        } catch (Throwable t) {
            binding = false;
            log("bind失敗: " + t);
        }
    }

    private void bg(Callable<String> c, Consumer<String> done) {
        new Thread(() -> {
            String r;
            try {
                r = c.call();
            } catch (Throwable t) {
                r = "エラー: " + t;
            }
            final String out = r;
            runOnUiThread(() -> done.accept(out));
        }).start();
    }

    private void refreshStatus() {
        if (svc == null) return;
        bg(() -> svc.status(), this::showStatus);
    }

    private void showStatus(String s) {
        running = s.startsWith("動作中");
        statusView.setText(s);
        toggle.setText(running ? "補正を停止" : "補正を開始");
    }

    private void refreshProfiles() {
        profiles = Store.load(this);
        List<String> names = new ArrayList<>();
        names.add("補正なし（素通し）");
        for (Store.Profile p : profiles) names.add(p.name);
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, names);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerInit = false;
        spinner.setAdapter(ad);
        int a = Math.min(Store.getActive(this), names.size() - 1);
        spinner.setSelection(Math.max(0, a));
        spinnerInit = true;
        syncOffsetUi();
    }

    private void onToggle() {
        if (svc == null) {
            connect();
            return;
        }
        if (running) {
            bg(() -> svc.stop(), s -> refreshStatus());
            return;
        }
        int sel = spinner.getSelectedItemPosition();
        float[] none = new float[0];
        float[] xs = none, ys = none, dx = none, dy = none;
        float ox = 0, oy = 0;
        if (sel > 0 && sel - 1 < profiles.size()) {
            Store.Profile p = profiles.get(sel - 1);
            ox = p.offX;
            oy = p.offY;
            xs = p.xs;
            ys = p.ys;
            dx = p.dx;
            dy = p.dy;
        }
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        final int w = Math.min(dm.widthPixels, dm.heightPixels);
        final int h = Math.max(dm.widthPixels, dm.heightPixels);
        final float[] fxs = xs, fys = ys, fdx = dx, fdy = dy;
        final int slop = Store.getSlop(this);
        final float fox = ox, foy = oy;
        final int avg = Store.getAvg(this);
        bg(() -> svc.start(w, h, fxs, fys, fdx, fdy, slop, fox, foy, avg), s -> {
            if (s.startsWith("ERR") || s.startsWith("エラー")) log(s);
            refreshStatus();
        });
    }

    private void onCalibrate(int mode) {
        final Intent it = new Intent(this, CalibrationActivity.class).putExtra("mode", mode);
        if (svc == null) {
            startActivity(it);
            return;
        }
        // 補正中だと正しく測れないので、先に止める
        bg(() -> svc.stop(), s -> {
            showStatus("停止中");
            startActivity(it);
        });
    }

    private void onDelete() {
        int sel = spinner.getSelectedItemPosition();
        if (sel <= 0 || sel - 1 >= profiles.size()) return;
        profiles.remove(sel - 1);
        Store.save(this, profiles);
        Store.setActive(this, 0);
        refreshProfiles();
    }

    private void log(String s) {
        logView.append(s + "\n");
        // 新しいメッセージが見えるように、先頭までスクロールを戻す
        scroll.post(() -> scroll.smoothScrollTo(0, 0));
    }
}
