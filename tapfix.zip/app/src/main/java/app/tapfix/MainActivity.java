package app.tapfix;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.function.Consumer;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {

    private static final int REQ = 100;

    private ITapService svc;
    private boolean running = false;
    private boolean binding = false;
    private boolean spinnerInit = false;

    private TextView statusView, logView;
    private Button toggle, overlayBtn;
    private TextView slopLabel;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            if (svc != null) refreshStatus();
            handler.postDelayed(this, 1000);
        }
    };
    private Spinner spinner;
    private ScrollView scroll;
    private List<Store.Profile> profiles = new ArrayList<>();

    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            svc = ITapService.Stub.asInterface(binder);
            binding = false;
            bg(() -> svc.setLibDir(getApplicationInfo().nativeLibraryDir), s -> refreshStatus());
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            svc = null;
            binding = false;
            running = false;
            showStatus("接続が切れました（Shizukuを確認してください）");
        }
    };

    private final Shizuku.OnRequestPermissionResultListener permListener =
            (requestCode, grantResult) -> {
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    bind();
                } else {
                    log("Shizukuの許可が拒否されました");
                }
            };

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(14), dp(14), dp(14));

        statusView = new TextView(this);
        statusView.setTextSize(16);
        statusView.setText("接続中…");
        root.addView(statusView);

        toggle = button("補正を開始", v -> onToggle());
        root.addView(toggle);

        overlayBtn = button("タップ位置を表示：オフ", v -> onOverlay());
        root.addView(overlayBtn);

        TextView lbl = new TextView(this);
        lbl.setText("使う補正データ");
        lbl.setPadding(0, dp(12), 0, 0);
        root.addView(lbl);

        spinner = new Spinner(this);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!spinnerInit) return;
                Store.setActive(MainActivity.this, position);
                if (running) {
                    log("補正データを切り替えたので、いったん止めてもう一度「開始」を押してください");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        root.addView(spinner);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button cal = button("新規キャリブレーション", v -> onCalibrate());
        Button del = button("選択中を削除", v -> onDelete());
        row.addView(cal, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(del, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(row);

        slopLabel = new TextView(this);
        slopLabel.setPadding(0, dp(12), 0, 0);
        root.addView(slopLabel);
        SeekBar seek = new SeekBar(this);
        seek.setMax(80);
        seek.setProgress(Store.getSlop(this));
        showSlop(Store.getSlop(this));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                Store.setSlop(MainActivity.this, progress);
                showSlop(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                final int v = bar.getProgress();
                if (svc != null) bg(() -> {
                    svc.setSlop(v);
                    return "";
                }, s -> refreshStatus());
            }
        });
        root.addView(seek);

        TextView help = new TextView(this);
        help.setTextSize(12);
        help.setText("・フリック抑制：押した位置から指がこの距離より動くまでは、位置を動かさずタップとして扱います（0でオフ）。大きいほど意図しないフリックが減りますが、スクロールやフリック入力の出だしが少し重くなります。スライダーを動かすと補正中でも即反映されます。\n"
                + "・補正が効かなくなったり、画面が操作できなくなったら、音量＋と音量−を同時に2秒押し続けると補正を止められます。\n"
                + "・補正は縦画面のみ有効です（横画面では位置はそのまま、補正だけ無効になります）。\n"
                + "・端末を再起動したら、Shizukuを起動し直してから「補正を開始」を押してください。");
        help.setPadding(0, dp(10), 0, dp(6));
        root.addView(help);

        scroll = new ScrollView(this);
        logView = new TextView(this);
        logView.setTextSize(12);
        scroll.addView(logView);
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        Shizuku.addRequestPermissionResultListener(permListener);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshProfiles();
        updateOverlayBtn();
        if (svc == null) {
            connect();
        } else {
            refreshStatus();
        }
        handler.postDelayed(poll, 1000);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(poll);
        super.onPause();
    }

    private void showSlop(int v) {
        slopLabel.setText("フリック抑制（指のブレを無視する距離）: " + (v == 0 ? "オフ" : v + " px"));
    }

    private void updateOverlayBtn() {
        overlayBtn.setText(OverlayService.running ? "タップ位置を表示：オン（押すと消す）" : "タップ位置を表示：オフ（押すと表示）");
    }

    private void onOverlay() {
        if (OverlayService.running) {
            stopService(new Intent(this, OverlayService.class));
            OverlayService.running = false;
            updateOverlayBtn();
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            log("「他のアプリの上に重ねて表示」を許可してから、戻ってもう一度押してください");
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        startService(new Intent(this, OverlayService.class));
        OverlayService.running = true;
        updateOverlayBtn();
    }

    @Override
    protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener);
        super.onDestroy();
    }

    private int versionCode() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Throwable t) {
            return 1;
        }
    }

    private Shizuku.UserServiceArgs args() {
        // daemon(true): アプリを閉じても補正が動き続ける
        return new Shizuku.UserServiceArgs(new ComponentName(getPackageName(), TapService.class.getName()))
                .daemon(true)
                .processNameSuffix("tapfix")
                .version(versionCode());
    }

    private void connect() {
        try {
            if (!Shizuku.pingBinder()) {
                showStatus("Shizukuが動いていません。Shizukuアプリで開始してから、この画面に戻ってください");
                return;
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(REQ);
                return;
            }
            bind();
        } catch (Throwable t) {
            log("エラー: " + t);
        }
    }

    private void bind() {
        if (binding || svc != null) return;
        try {
            binding = true;
            Shizuku.bindUserService(args(), conn);
        } catch (Throwable t) {
            binding = false;
            log("bind失敗: " + t);
        }
    }

    private void bg(Callable<String> c, Consumer<String> done) {
        new Thread(() -> {
            String r;
            try {
                r = c.call();
            } catch (Throwable t) {
                r = "エラー: " + t;
            }
            final String out = r;
            runOnUiThread(() -> done.accept(out));
        }).start();
    }

    private void refreshStatus() {
        if (svc == null) return;
        bg(() -> svc.status(), this::showStatus);
    }

    private void showStatus(String s) {
        running = s.startsWith("動作中");
        statusView.setText(s);
        toggle.setText(running ? "補正を停止" : "補正を開始");
    }

    private void refreshProfiles() {
        profiles = Store.load(this);
        List<String> names = new ArrayList<>();
        names.add("補正なし（素通し）");
        for (Store.Profile p : profiles) names.add(p.name);
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, names);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerInit = false;
        spinner.setAdapter(ad);
        int a = Math.min(Store.getActive(this), names.size() - 1);
        spinner.setSelection(Math.max(0, a));
        spinnerInit = true;
    }

    private void onToggle() {
        if (svc == null) {
            connect();
            return;
        }
        if (running) {
            bg(() -> svc.stop(), s -> refreshStatus());
            return;
        }
        int sel = spinner.getSelectedItemPosition();
        float[] none = new float[0];
        float[] xs = none, ys = none, dx = none, dy = none;
        if (sel > 0 && sel - 1 < profiles.size()) {
            Store.Profile p = profiles.get(sel - 1);
            xs = p.xs;
            ys = p.ys;
            dx = p.dx;
            dy = p.dy;
        }
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        final int w = Math.min(dm.widthPixels, dm.heightPixels);
        final int h = Math.max(dm.widthPixels, dm.heightPixels);
        final float[] fxs = xs, fys = ys, fdx = dx, fdy = dy;
        final int slop = Store.getSlop(this);
        bg(() -> svc.start(w, h, fxs, fys, fdx, fdy, slop), s -> {
            if (s.startsWith("ERR") || s.startsWith("エラー")) log(s);
            refreshStatus();
        });
    }

    private void onCalibrate() {
        if (svc == null) {
            startActivity(new Intent(this, CalibrationActivity.class));
            return;
        }
        // 補正中だと正しく測れないので、先に止める
        bg(() -> svc.stop(), s -> {
            showStatus("停止中");
            startActivity(new Intent(this, CalibrationActivity.class));
        });
    }

    private void onDelete() {
        int sel = spinner.getSelectedItemPosition();
        if (sel <= 0 || sel - 1 >= profiles.size()) return;
        profiles.remove(sel - 1);
        Store.save(this, profiles);
        Store.setActive(this, 0);
        refreshProfiles();
    }

    private void log(String s) {
        logView.append(s + "\n");
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }
}
