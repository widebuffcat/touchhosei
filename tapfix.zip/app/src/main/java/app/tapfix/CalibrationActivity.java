package app.tapfix;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class CalibrationActivity extends Activity {

    // mode 0: 標準 3×5=15点 / mode 1: 細かく 5×9=45点（多項式で滑らかに近似）
    private static final float[] FX0 = {0.1f, 0.5f, 0.9f};
    private static final float[] FY0 = {0.06f, 0.28f, 0.5f, 0.72f, 0.94f};
    // 細かいモードは画面の端（約5%）まで測る。端は指の側面で触れるため、ズレ方が変わりやすい
    private static final float[] FX1 = {0.05f, 0.275f, 0.5f, 0.725f, 0.95f};
    private static final float[] FY1 = {0.03f, 0.15f, 0.27f, 0.39f, 0.5f, 0.61f, 0.73f, 0.85f, 0.97f};
    // 横画面用は、縦画面の格子の縦横を入れ替えたもの（画面の形に合わせる）
    private static final float[] LFX0 = FY0;
    private static final float[] LFY0 = FX0;
    private static final float[] LFX1 = FY1;
    private static final float[] LFY1 = FX1;
    private float[] fx = FX0, fy = FY0;
    private int mode = 0;
    // 横画面の補正を測るか（その場合は、選んでいる補正データに追加で保存する）
    private boolean land = false;
    // 机などに置いて（傾かない状態で）人差し指で操作するとき用の補正を測るか（傾きは使わない）
    private boolean desk = false;
    private boolean noTilt = false;
    private int profileIdx = 0;

    // 次数 deg 以下の項 u^i v^j (i+j<=deg)
    private static int[][] terms(int deg) {
        List<int[]> l = new ArrayList<>();
        for (int sum = 0; sum <= deg; sum++) {
            for (int j = 0; j <= sum; j++) l.add(new int[]{sum - j, j});
        }
        return l.toArray(new int[0][]);
    }

    private static double term(int[][] T, int t, double u, double v) {
        return Math.pow(u, T[t][0]) * Math.pow(v, T[t][1]);
    }

    /** 近似に使う測定データ。rs, ps は傾き（基準からの差を10度で割ったもの）。傾きを使わないときは null */
    private static final class Data {
        final float[] tx, ty, rs, ps;
        final int w, h;

        Data(float[] tx, float[] ty, float[] rs, float[] ps, int w, int h) {
            this.tx = tx;
            this.ty = ty;
            this.rs = rs;
            this.ps = ps;
            this.w = w;
            this.h = h;
        }
    }

    // k 番目の測定点の特徴量（位置の多項式＋傾き2つ）
    private static void feats(Data D, int[][] T, boolean tilt, int k, double[] f) {
        double u = D.tx[k] / (double) D.w - 0.5, v = D.ty[k] / (double) D.h - 0.5;
        for (int t = 0; t < T.length; t++) f[t] = term(T, t, u, v);
        if (tilt) {
            f[T.length] = D.rs[k];
            f[T.length + 1] = D.ps[k];
        }
    }

    // 最小二乗（正規方程式をガウス・ジョルダン法で解く）
    private static double[] fit(Data D, int[][] T, boolean tilt, float[] d, boolean[] use) {
        int m = T.length + (tilt ? 2 : 0);
        double[][] a = new double[m][m + 1];
        double[] f = new double[m];
        for (int k = 0; k < D.tx.length; k++) {
            if (!use[k]) continue;
            feats(D, T, tilt, k, f);
            for (int r = 0; r < m; r++) {
                for (int c = 0; c < m; c++) a[r][c] += f[r] * f[c];
                a[r][m] += f[r] * d[k];
            }
        }
        for (int r = 0; r < m; r++) a[r][r] += (tilt && r >= T.length) ? 0.1 : 1e-6;
        for (int i = 0; i < m; i++) {
            int p = i;
            for (int r = i + 1; r < m; r++) if (Math.abs(a[r][i]) > Math.abs(a[p][i])) p = r;
            double[] tmp = a[i];
            a[i] = a[p];
            a[p] = tmp;
            double piv = a[i][i];
            if (Math.abs(piv) < 1e-12) continue;
            for (int c = i; c <= m; c++) a[i][c] /= piv;
            for (int r = 0; r < m; r++) {
                if (r == i) continue;
                double g = a[r][i];
                if (g == 0) continue;
                for (int c = i; c <= m; c++) a[r][c] -= g * a[i][c];
            }
        }
        double[] sol = new double[m];
        for (int i = 0; i < m; i++) sol[i] = a[i][m];
        return sol;
    }

    private static double predict(Data D, int[][] T, boolean tilt, double[] c, int k) {
        double[] f = new double[c.length];
        feats(D, T, tilt, k, f);
        double s = 0;
        for (int t = 0; t < c.length; t++) s += c[t] * f[t];
        return s;
    }

    private static double[] residuals(Data D, int[][] T, boolean tilt, float[] dx, float[] dy,
                                      double[] cx, double[] cy) {
        double[] res = new double[D.tx.length];
        for (int k = 0; k < res.length; k++) {
            double ex = dx[k] - predict(D, T, tilt, cx, k), ey = dy[k] - predict(D, T, tilt, cy, k);
            res[k] = Math.sqrt(ex * ex + ey * ey);
        }
        return res;
    }

    private static double rmsOf(double[] res, boolean[] use) {
        double sum = 0;
        int cnt = 0;
        for (int k = 0; k < res.length; k++) {
            if (use[k]) {
                sum += res[k] * res[k];
                cnt++;
            }
        }
        return Math.sqrt(sum / Math.max(1, cnt));
    }

    // 1点ずつ抜いて予測し直した誤差（交差検証）。次数や傾きを増やしすぎて「ブレまで覚える」のを避ける物差し
    private static double looError(Data D, int[][] T, boolean tilt, float[] dx, float[] dy, boolean[] use) {
        double sum = 0;
        int cnt = 0;
        boolean[] u2 = use.clone();
        for (int k = 0; k < D.tx.length; k++) {
            if (!use[k]) continue;
            u2[k] = false;
            double[] cx = fit(D, T, tilt, dx, u2);
            double[] cy = fit(D, T, tilt, dy, u2);
            double ex = dx[k] - predict(D, T, tilt, cx, k), ey = dy[k] - predict(D, T, tilt, cy, k);
            sum += ex * ex + ey * ey;
            cnt++;
            u2[k] = true;
        }
        return Math.sqrt(sum / Math.max(1, cnt));
    }

    private static double stdOf(float[] a) {
        double m = 0;
        for (float v : a) m += v;
        m /= a.length;
        double s = 0;
        for (float v : a) s += (v - m) * (v - m);
        return Math.sqrt(s / a.length);
    }

    /**
     * 測った補正量(dx,dy)を、滑らかな面に近似した値で置き換える。タップごとのブレを平均化する。
     * tr, tp が null でなければ、タップ時の端末の傾きも説明変数に加えて、効果があれば使う。
     * tiltOut[0]=1 のとき tiltOut[1..6] = {x←左右, x←前後, y←左右, y←前後 (px/度), 基準roll, 基準pitch}
     */
    private static String smoothFit(float[] tx, float[] ty, float[] dx, float[] dy, float[] tr, float[] tp,
                                    int w, int h, float ydpi, int gridN, float[] tiltOut) {
        int n = tx.length;
        boolean[] use = new boolean[n];
        Arrays.fill(use, true);
        double r0 = 0, p0 = 0;
        float[] rs = null, ps = null;
        String tiltNote = "";
        boolean tiltPossible = false;
        if (tr != null && tp != null) {
            for (int k = 0; k < n; k++) {
                r0 += tr[k];
                p0 += tp[k];
            }
            r0 /= n;
            p0 /= n;
            rs = new float[n];
            ps = new float[n];
            for (int k = 0; k < n; k++) {
                rs[k] = (float) ((tr[k] - r0) / 10.0);
                ps[k] = (float) ((tp[k] - p0) / 10.0);
            }
            // 傾きがほとんど変わらないと、効果を測れない
            tiltPossible = Math.max(stdOf(tr), stdOf(tp)) >= 1.0;
            if (!tiltPossible) tiltNote = "、傾きの変化が小さいので傾き連携は使わない";
        }
        Data D = new Data(tx, ty, rs, ps, w, h);
        int bestDeg = 3;
        boolean bestTilt = false;
        double bestErr = Double.MAX_VALUE, bestNoTilt = Double.MAX_VALUE;
        for (int deg = 2; deg <= 4; deg++) {
            int[][] T = terms(deg);
            for (int tl = 0; tl <= (tiltPossible ? 1 : 0); tl++) {
                boolean tilt = tl == 1;
                int m = T.length + (tilt ? 2 : 0);
                if (n < m * 2 + 4) continue;
                double e = looError(D, T, tilt, dx, dy, use);
                if (!tilt && e < bestNoTilt) bestNoTilt = e;
                if (e < bestErr) {
                    bestErr = e;
                    bestDeg = deg;
                    bestTilt = tilt;
                }
            }
        }
        int[][] T = terms(bestDeg);
        double[] cx = fit(D, T, bestTilt, dx, use);
        double[] cy = fit(D, T, bestTilt, dy, use);
        double[] res = residuals(D, T, bestTilt, dx, dy, cx, cy);
        double rms = rmsOf(res, use);
        // 極端にずれた1タップ（押し間違い）は外してもう一度
        boolean[] use2 = use.clone();
        int dropped = 0;
        for (int k = 0; k < n; k++) {
            if (res[k] > 2.5 * rms && res[k] > 12) {
                use2[k] = false;
                dropped++;
            }
        }
        if (dropped > 0 && n - dropped >= 20) {
            cx = fit(D, T, bestTilt, dx, use2);
            cy = fit(D, T, bestTilt, dy, use2);
            res = residuals(D, T, bestTilt, dx, dy, cx, cy);
            rms = rmsOf(res, use2);
        } else {
            dropped = 0;
        }
        // 格子点(先頭 gridN 個)の補正量を、近似した面（位置の項だけ。傾きは基準値の分）の値に置き換える。
        // ランダム点は近似にだけ使う
        for (int k = 0; k < gridN; k++) {
            double u = tx[k] / (double) w - 0.5, v = ty[k] / (double) h - 0.5;
            double sx = 0, sy = 0;
            for (int t = 0; t < T.length; t++) {
                double q = term(T, t, u, v);
                sx += cx[t] * q;
                sy += cy[t] * q;
            }
            dx[k] = (float) sx;
            dy[k] = (float) sy;
        }
        tiltOut[0] = 0;
        if (bestTilt) {
            tiltOut[0] = 1;
            tiltOut[1] = (float) (cx[T.length] / 10.0);
            tiltOut[2] = (float) (cx[T.length + 1] / 10.0);
            tiltOut[3] = (float) (cy[T.length] / 10.0);
            tiltOut[4] = (float) (cy[T.length + 1] / 10.0);
            tiltOut[5] = (float) r0;
            tiltOut[6] = (float) p0;
            tiltNote = String.format(Locale.US, "、傾き連携: 使う（予測誤差 %.1f → %.1f px）", bestNoTilt, bestErr);
        } else if (tiltPossible) {
            tiltNote = "、傾き連携: 効果がないので使わない";
        }
        return String.format(Locale.US, "タップのばらつき: 平均 %.1f px（約 %.1f mm）、%d 点を%d次の面で近似、外れ値 %d 点を除外%s",
                rms, rms / ydpi * 25.4, n, bestDeg, dropped, tiltNote);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        mode = getIntent().getIntExtra("mode", 0);
        land = getIntent().getBooleanExtra("land", false);
        desk = getIntent().getBooleanExtra("desk", false) && !land;
        noTilt = land || desk;
        profileIdx = getIntent().getIntExtra("profile", 0);
        setRequestedOrientation(land
                ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                : android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        if (land) {
            fx = mode == 1 ? LFX1 : LFX0;
            fy = mode == 1 ? LFY1 : LFY0;
        } else if (mode == 1) {
            fx = FX1;
            fy = FY1;
        }
        calView = new CalView(this);
        setContentView(calView);
        hideBars();
    }

    private final TiltSensor tilt = new TiltSensor();
    private View calView;

    @Override
    protected void onResume() {
        super.onResume();
        if (mode == 1 && !noTilt) tilt.start(this, (r, p) -> {
            if (calView != null) calView.postInvalidate();
        });
    }

    @Override
    protected void onPause() {
        tilt.stop();
        super.onPause();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    @SuppressWarnings("deprecation")
    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void onDone(final Store.Profile p, String note) {
        final EditText et = new EditText(this);
        List<Store.Profile> l = Store.load(this);
        et.setText((mode == 1 ? "細かい・持ち方" : "持ち方") + (l.size() + 1));
        new AlertDialog.Builder(this)
                .setTitle("名前をつけて保存")
                .setMessage(note)
                .setView(et)
                .setCancelable(false)
                .setPositiveButton("保存", (d, w) -> {
                    String n = et.getText().toString().trim();
                    p.name = n.isEmpty() ? "持ち方" : n;
                    Store.add(this, p);
                    Toast.makeText(this, "保存しました", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .setNegativeButton("破棄", (d, w) -> finish())
                .show();
    }

    // 横画面の補正を、選んでいる補正データに追加で保存する
    private void onDoneLand(int lw, int lh, float[] lxs, float[] lys, float[] ldx, float[] ldy, String note) {
        List<Store.Profile> l = Store.load(this);
        final int ix = profileIdx - 1;
        if (ix < 0 || ix >= l.size()) {
            Toast.makeText(this, "保存先の補正データが見つかりません", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        final String nm = l.get(ix).name;
        final float[] fxs = lxs, fys = lys, fdx = ldx, fdy = ldy;
        final int flw = lw, flh = lh;
        new AlertDialog.Builder(this)
                .setTitle("横画面の補正を保存")
                .setMessage("「" + nm + "」に、横画面の補正を追加します（すでにあれば置き換えます）。\n" + note)
                .setCancelable(false)
                .setPositiveButton("保存", (d, w) -> {
                    List<Store.Profile> l2 = Store.load(this);
                    if (ix < l2.size()) {
                        Store.Profile p = l2.get(ix);
                        p.lw = flw;
                        p.lh = flh;
                        p.lxs = fxs;
                        p.lys = fys;
                        p.ldx = fdx;
                        p.ldy = fdy;
                        p.loffX = 0;
                        p.loffY = 0;
                        Store.save(this, l2);
                        Toast.makeText(this, "保存しました（補正を開始し直すと反映されます）", Toast.LENGTH_LONG).show();
                    }
                    finish();
                })
                .setNegativeButton("破棄", (d, w) -> finish())
                .show();
    }

    // 机置き用の補正を、選んでいる補正データに追加で保存する
    private void onDoneDesk(float[] kxs, float[] kys, float[] kdx, float[] kdy, String note) {
        List<Store.Profile> l = Store.load(this);
        final int ix = profileIdx - 1;
        if (ix < 0 || ix >= l.size()) {
            Toast.makeText(this, "保存先の補正データが見つかりません", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        final String nm = l.get(ix).name;
        new AlertDialog.Builder(this)
                .setTitle("机置きの補正を保存")
                .setMessage("「" + nm + "」に、机置き用の補正を追加します（すでにあれば置き換えます）。\n"
                        + "スマホが傾かず静止しているときだけ、この補正に切り替わります。\n" + note)
                .setCancelable(false)
                .setPositiveButton("保存", (d, w) -> {
                    List<Store.Profile> l2 = Store.load(this);
                    if (ix < l2.size()) {
                        Store.Profile p = l2.get(ix);
                        p.deskXs = kxs;
                        p.deskYs = kys;
                        p.deskDx = kdx;
                        p.deskDy = kdy;
                        p.deskOffX = 0;
                        p.deskOffY = 0;
                        Store.save(this, l2);
                        Toast.makeText(this, "保存しました（補正を開始し直すと反映されます）", Toast.LENGTH_LONG).show();
                    }
                    finish();
                })
                .setNegativeButton("破棄", (d, w) -> finish())
                .show();
    }

    private final class CalView extends View {
        private final int cols = fx.length;
        private final int rows = fy.length;
        private final int gridN = cols * rows;
        // 細かいモードは、格子のあとにランダムな位置を15点足して精度を上げる
        private final int total = gridN + (mode == 1 ? 15 : 0);
        private final float[] tx = new float[total];
        private final float[] ty = new float[total];
        private final float[] dx = new float[total];
        private final float[] dy = new float[total];
        private final float[] tr = new float[total];
        private final float[] tp = new float[total];
        private boolean tiltOk = true;
        private final float[] tiltOut = new float[7];
        private final float[] rfx = new float[total];
        private final float[] rfy = new float[total];
        private int idx = 0;
        private boolean ready = false;
        private int ox, oy;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        CalView(Context c) {
            super(c);
            makeRandom();
        }

        // 画面を3×5の区画に分け、区画ごとに1点ずつランダムな位置を作る（偏らない）。順番もランダム
        private void makeRandom() {
            int extra = total - gridN;
            if (extra <= 0) return;
            Random rnd = new Random();
            int[] cell = new int[extra];
            for (int i = 0; i < extra; i++) cell[i] = i;
            for (int i = extra - 1; i > 0; i--) {
                int j = rnd.nextInt(i + 1);
                int t = cell[i];
                cell[i] = cell[j];
                cell[j] = t;
            }
            int cc = land ? 5 : 3, rr = (extra + cc - 1) / cc;
            for (int i = 0; i < extra; i++) {
                int c = cell[i] % cc, r = cell[i] / cc;
                rfx[gridN + i] = 0.03f + 0.94f * (c + 0.15f + 0.7f * rnd.nextFloat()) / cc;
                rfy[gridN + i] = 0.03f + 0.94f * (r + 0.15f + 0.7f * rnd.nextFloat()) / rr;
            }
        }

        private void layoutTargets() {
            int[] loc = new int[2];
            getLocationOnScreen(loc);
            ox = loc[0];
            oy = loc[1];
            for (int j = 0; j < rows; j++) {
                for (int i = 0; i < cols; i++) {
                    tx[j * cols + i] = ox + fx[i] * getWidth();
                    ty[j * cols + i] = oy + fy[j] * getHeight();
                }
            }
            for (int k = gridN; k < total; k++) {
                tx[k] = ox + rfx[k] * getWidth();
                ty[k] = oy + rfy[k] * getHeight();
            }
            ready = true;
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            ready = false;
        }

        @Override
        protected void onDraw(Canvas c) {
            if (!ready) layoutTargets();
            c.drawColor(Color.BLACK);
            float u = getResources().getDisplayMetrics().density;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.DKGRAY);
            for (int k = 0; k < idx && k < total; k++) c.drawCircle(tx[k] - ox, ty[k] - oy, 5 * u, paint);
            if (idx < total) {
                float x = tx[idx] - ox, y = ty[idx] - oy;
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2 * u);
                paint.setColor(Color.RED);
                c.drawCircle(x, y, 22 * u, paint);
                c.drawLine(x - 34 * u, y, x + 34 * u, y, paint);
                c.drawLine(x, y - 34 * u, x, y + 34 * u, paint);
            }
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.WHITE);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(16 * u);
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            c.drawText(land ? "【横画面】普段の持ち方で、赤い十字の中心を"
                    : (desk ? "【机置き】机などに置いて、人差し指で、赤い十字の中心を" : "普段の持ち方で、赤い十字の中心を"), cx, cy - 40 * u, paint);
            c.drawText("指でタップしてください (" + Math.min(idx + 1, total) + "/" + total + ")", cx, cy - 10 * u, paint);
            if (idx >= gridN && idx < total) {
                paint.setTextSize(12 * u);
                paint.setColor(Color.GRAY);
                c.drawText("仕上げ：ランダムな位置です", cx, cy + 10 * u, paint);
            }
            paint.setTextSize(12 * u);
            paint.setColor(Color.GRAY);
            c.drawText("戻るキーで中止", cx, cy + 30 * u, paint);
            if (mode == 1 && !noTilt) {
                c.drawText(tilt.valid
                        ? String.format(Locale.US, "傾き 左右 %+.0f° / 前後 %+.0f°", tilt.roll, tilt.pitch)
                        : "傾きセンサー: 検出なし（傾き連携なしで測ります）", cx, cy + 50 * u, paint);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN && idx < total) {
                if (!ready) layoutTargets();
                dx[idx] = tx[idx] - e.getRawX();
                dy[idx] = ty[idx] - e.getRawY();
                // タップした瞬間の端末の傾きも記録する（細かいモードのみ）
                if (mode == 1 && !noTilt && tilt.valid) {
                    tr[idx] = tilt.roll;
                    tp[idx] = tilt.pitch;
                } else {
                    tiltOk = false;
                }
                idx++;
                invalidate();
                if (idx == total) {
                    String note = "";
                    if (mode == 1) {
                        note = smoothFit(tx, ty, dx, dy, tiltOk ? tr : null, tiltOk ? tp : null,
                                getWidth(), getHeight(), getResources().getDisplayMetrics().ydpi, gridN, tiltOut);
                    }
                    if (land) {
                        float[] lxs = new float[cols], lys = new float[rows];
                        for (int i = 0; i < cols; i++) lxs[i] = tx[i];
                        for (int j = 0; j < rows; j++) lys[j] = ty[j * cols];
                        onDoneLand(getWidth(), getHeight(), lxs, lys,
                                Arrays.copyOf(dx, gridN), Arrays.copyOf(dy, gridN), note);
                        return true;
                    }
                    if (desk) {
                        float[] kxs = new float[cols], kys = new float[rows];
                        for (int i = 0; i < cols; i++) kxs[i] = tx[i];
                        for (int j = 0; j < rows; j++) kys[j] = ty[j * cols];
                        onDoneDesk(kxs, kys, Arrays.copyOf(dx, gridN), Arrays.copyOf(dy, gridN), note);
                        return true;
                    }
                    Store.Profile p = new Store.Profile();
                    p.w = getWidth();
                    p.h = getHeight();
                    p.xs = new float[cols];
                    p.ys = new float[rows];
                    for (int i = 0; i < cols; i++) p.xs[i] = tx[i];
                    for (int j = 0; j < rows; j++) p.ys[j] = ty[j * cols];
                    if (mode == 1 && tiltOut[0] > 0.5f) p.tilt = Arrays.copyOfRange(tiltOut, 1, 7);
                    p.dx = Arrays.copyOf(dx, gridN);
                    p.dy = Arrays.copyOf(dy, gridN);
                    onDone(p, note);
                }
            }
            return true;
        }
    }
}
