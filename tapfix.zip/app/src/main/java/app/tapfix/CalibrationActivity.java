package app.tapfix;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class CalibrationActivity extends Activity {

    // mode 0: 標準 3×5=15点 / mode 1: 細かく 5×9=45点（多項式で滑らかに近似）
    private static final float[] FX0 = {0.1f, 0.5f, 0.9f};
    private static final float[] FY0 = {0.06f, 0.28f, 0.5f, 0.72f, 0.94f};
    // 細かいモードは画面の端（約5%）まで測る。端は指の側面で触れるため、ズレ方が変わりやすい
    private static final float[] FX1 = {0.05f, 0.275f, 0.5f, 0.725f, 0.95f};
    private static final float[] FY1 = {0.03f, 0.15f, 0.27f, 0.39f, 0.5f, 0.61f, 0.73f, 0.85f, 0.97f};
    private float[] fx = FX0, fy = FY0;
    private int mode = 0;

    // 次数 deg 以下の項 u^i v^j (i+j<=deg)
    private static int[][] terms(int deg) {
        List<int[]> l = new ArrayList<>();
        for (int sum = 0; sum <= deg; sum++) {
            for (int j = 0; j <= sum; j++) l.add(new int[]{sum - j, j});
        }
        return l.toArray(new int[0][]);
    }

    private static double term(int[][] T, int t, double u, double v) {
        return Math.pow(u, T[t][0]) * Math.pow(v, T[t][1]);
    }

    // 多項式の最小二乗（正規方程式をガウス・ジョルダン法で解く）。u,v は中心を0にした 0〜1 の座標
    private static double[] fit(int[][] T, float[] tx, float[] ty, float[] d, boolean[] use, int w, int h) {
        int m = T.length;
        double[][] a = new double[m][m + 1];
        double[] f = new double[m];
        for (int k = 0; k < tx.length; k++) {
            if (!use[k]) continue;
            double u = tx[k] / (double) w - 0.5, v = ty[k] / (double) h - 0.5;
            for (int t = 0; t < m; t++) f[t] = term(T, t, u, v);
            for (int r = 0; r < m; r++) {
                for (int c = 0; c < m; c++) a[r][c] += f[r] * f[c];
                a[r][m] += f[r] * d[k];
            }
        }
        for (int r = 0; r < m; r++) a[r][r] += 1e-6;
        for (int i = 0; i < m; i++) {
            int p = i;
            for (int r = i + 1; r < m; r++) if (Math.abs(a[r][i]) > Math.abs(a[p][i])) p = r;
            double[] tmp = a[i];
            a[i] = a[p];
            a[p] = tmp;
            double piv = a[i][i];
            if (Math.abs(piv) < 1e-12) continue;
            for (int c = i; c <= m; c++) a[i][c] /= piv;
            for (int r = 0; r < m; r++) {
                if (r == i) continue;
                double g = a[r][i];
                if (g == 0) continue;
                for (int c = i; c <= m; c++) a[r][c] -= g * a[i][c];
            }
        }
        double[] sol = new double[m];
        for (int i = 0; i < m; i++) sol[i] = a[i][m];
        return sol;
    }

    private static double eval(int[][] T, double[] c, double u, double v) {
        double s = 0;
        for (int t = 0; t < c.length; t++) s += c[t] * term(T, t, u, v);
        return s;
    }

    private static double[] residuals(int[][] T, float[] tx, float[] ty, float[] dx, float[] dy,
                                      double[] cx, double[] cy, int w, int h) {
        double[] res = new double[tx.length];
        for (int k = 0; k < tx.length; k++) {
            double u = tx[k] / (double) w - 0.5, v = ty[k] / (double) h - 0.5;
            double ex = dx[k] - eval(T, cx, u, v), ey = dy[k] - eval(T, cy, u, v);
            res[k] = Math.sqrt(ex * ex + ey * ey);
        }
        return res;
    }

    private static double rmsOf(double[] res, boolean[] use) {
        double sum = 0;
        int cnt = 0;
        for (int k = 0; k < res.length; k++) {
            if (use[k]) {
                sum += res[k] * res[k];
                cnt++;
            }
        }
        return Math.sqrt(sum / Math.max(1, cnt));
    }

    // 1点ずつ抜いて予測し直した誤差（交差検証）。次数を上げすぎて「ブレまで覚える」のを避けるための物差し
    private static double looError(int[][] T, float[] tx, float[] ty, float[] dx, float[] dy,
                                   boolean[] use, int w, int h) {
        double sum = 0;
        int cnt = 0;
        boolean[] u2 = use.clone();
        for (int k = 0; k < tx.length; k++) {
            if (!use[k]) continue;
            u2[k] = false;
            double[] cx = fit(T, tx, ty, dx, u2, w, h);
            double[] cy = fit(T, tx, ty, dy, u2, w, h);
            double u = tx[k] / (double) w - 0.5, v = ty[k] / (double) h - 0.5;
            double ex = dx[k] - eval(T, cx, u, v), ey = dy[k] - eval(T, cy, u, v);
            sum += ex * ex + ey * ey;
            cnt++;
            u2[k] = true;
        }
        return Math.sqrt(sum / Math.max(1, cnt));
    }

    /** 測った補正量(dx,dy)を、滑らかな面に近似した値で置き換える。タップごとのブレを平均化する。 */
    private static String smoothFit(float[] tx, float[] ty, float[] dx, float[] dy, int w, int h, float ydpi, int gridN) {
        int n = tx.length;
        boolean[] use = new boolean[n];
        Arrays.fill(use, true);
        // 2〜4次のうち、交差検証の誤差が一番小さい次数を選ぶ（点が少ないときは低い次数だけ）
        int bestDeg = 3;
        double bestErr = Double.MAX_VALUE;
        for (int deg = 2; deg <= 4; deg++) {
            int[][] T = terms(deg);
            if (n < T.length * 2 + 4) continue;
            double e = looError(T, tx, ty, dx, dy, use, w, h);
            if (e < bestErr) {
                bestErr = e;
                bestDeg = deg;
            }
        }
        int[][] T = terms(bestDeg);
        double[] cx = fit(T, tx, ty, dx, use, w, h);
        double[] cy = fit(T, tx, ty, dy, use, w, h);
        double[] res = residuals(T, tx, ty, dx, dy, cx, cy, w, h);
        double rms = rmsOf(res, use);
        // 極端にずれた1タップ（押し間違い）は外してもう一度
        boolean[] use2 = use.clone();
        int dropped = 0;
        for (int k = 0; k < n; k++) {
            if (res[k] > 2.5 * rms && res[k] > 12) {
                use2[k] = false;
                dropped++;
            }
        }
        if (dropped > 0 && n - dropped >= 20) {
            cx = fit(T, tx, ty, dx, use2, w, h);
            cy = fit(T, tx, ty, dy, use2, w, h);
            res = residuals(T, tx, ty, dx, dy, cx, cy, w, h);
            rms = rmsOf(res, use2);
        } else {
            dropped = 0;
        }
        // 格子点(先頭 gridN 個)の補正量を、近似した面の値に置き換える。ランダム点は近似にだけ使う
        for (int k = 0; k < gridN; k++) {
            double u = tx[k] / (double) w - 0.5, v = ty[k] / (double) h - 0.5;
            dx[k] = (float) eval(T, cx, u, v);
            dy[k] = (float) eval(T, cy, u, v);
        }
        return String.format(Locale.US, "タップのばらつき: 平均 %.1f px（約 %.1f mm）、%d 点を%d次の面で近似、外れ値 %d 点を除外",
                rms, rms / ydpi * 25.4, n, bestDeg, dropped);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        mode = getIntent().getIntExtra("mode", 0);
        if (mode == 1) {
            fx = FX1;
            fy = FY1;
        }
        setContentView(new CalView(this));
        hideBars();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    @SuppressWarnings("deprecation")
    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void onDone(final Store.Profile p, String note) {
        final EditText et = new EditText(this);
        List<Store.Profile> l = Store.load(this);
        et.setText((mode == 1 ? "細かい・持ち方" : "持ち方") + (l.size() + 1));
        new AlertDialog.Builder(this)
                .setTitle("名前をつけて保存")
                .setMessage(note)
                .setView(et)
                .setCancelable(false)
                .setPositiveButton("保存", (d, w) -> {
                    String n = et.getText().toString().trim();
                    p.name = n.isEmpty() ? "持ち方" : n;
                    Store.add(this, p);
                    Toast.makeText(this, "保存しました", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .setNegativeButton("破棄", (d, w) -> finish())
                .show();
    }

    private final class CalView extends View {
        private final int cols = fx.length;
        private final int rows = fy.length;
        private final int gridN = cols * rows;
        // 細かいモードは、格子のあとにランダムな位置を15点足して精度を上げる
        private final int total = gridN + (mode == 1 ? 15 : 0);
        private final float[] tx = new float[total];
        private final float[] ty = new float[total];
        private final float[] dx = new float[total];
        private final float[] dy = new float[total];
        private final float[] rfx = new float[total];
        private final float[] rfy = new float[total];
        private int idx = 0;
        private boolean ready = false;
        private int ox, oy;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        CalView(Context c) {
            super(c);
            makeRandom();
        }

        // 画面を3×5の区画に分け、区画ごとに1点ずつランダムな位置を作る（偏らない）。順番もランダム
        private void makeRandom() {
            int extra = total - gridN;
            if (extra <= 0) return;
            Random rnd = new Random();
            int[] cell = new int[extra];
            for (int i = 0; i < extra; i++) cell[i] = i;
            for (int i = extra - 1; i > 0; i--) {
                int j = rnd.nextInt(i + 1);
                int t = cell[i];
                cell[i] = cell[j];
                cell[j] = t;
            }
            int cc = 3, rr = (extra + cc - 1) / cc;
            for (int i = 0; i < extra; i++) {
                int c = cell[i] % cc, r = cell[i] / cc;
                rfx[gridN + i] = 0.03f + 0.94f * (c + 0.15f + 0.7f * rnd.nextFloat()) / cc;
                rfy[gridN + i] = 0.03f + 0.94f * (r + 0.15f + 0.7f * rnd.nextFloat()) / rr;
            }
        }

        private void layoutTargets() {
            int[] loc = new int[2];
            getLocationOnScreen(loc);
            ox = loc[0];
            oy = loc[1];
            for (int j = 0; j < rows; j++) {
                for (int i = 0; i < cols; i++) {
                    tx[j * cols + i] = ox + fx[i] * getWidth();
                    ty[j * cols + i] = oy + fy[j] * getHeight();
                }
            }
            for (int k = gridN; k < total; k++) {
                tx[k] = ox + rfx[k] * getWidth();
                ty[k] = oy + rfy[k] * getHeight();
            }
            ready = true;
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            ready = false;
        }

        @Override
        protected void onDraw(Canvas c) {
            if (!ready) layoutTargets();
            c.drawColor(Color.BLACK);
            float u = getResources().getDisplayMetrics().density;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.DKGRAY);
            for (int k = 0; k < idx && k < total; k++) c.drawCircle(tx[k] - ox, ty[k] - oy, 5 * u, paint);
            if (idx < total) {
                float x = tx[idx] - ox, y = ty[idx] - oy;
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2 * u);
                paint.setColor(Color.RED);
                c.drawCircle(x, y, 22 * u, paint);
                c.drawLine(x - 34 * u, y, x + 34 * u, y, paint);
                c.drawLine(x, y - 34 * u, x, y + 34 * u, paint);
            }
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.WHITE);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(16 * u);
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            c.drawText("普段の持ち方で、赤い十字の中心を", cx, cy - 40 * u, paint);
            c.drawText("指でタップしてください (" + Math.min(idx + 1, total) + "/" + total + ")", cx, cy - 10 * u, paint);
            if (idx >= gridN && idx < total) {
                paint.setTextSize(12 * u);
                paint.setColor(Color.GRAY);
                c.drawText("仕上げ：ランダムな位置です", cx, cy + 10 * u, paint);
            }
            paint.setTextSize(12 * u);
            paint.setColor(Color.GRAY);
            c.drawText("戻るキーで中止", cx, cy + 30 * u, paint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN && idx < total) {
                if (!ready) layoutTargets();
                dx[idx] = tx[idx] - e.getRawX();
                dy[idx] = ty[idx] - e.getRawY();
                idx++;
                invalidate();
                if (idx == total) {
                    String note = "";
                    if (mode == 1) {
                        note = smoothFit(tx, ty, dx, dy, getWidth(), getHeight(),
                                getResources().getDisplayMetrics().ydpi, gridN);
                    }
                    Store.Profile p = new Store.Profile();
                    p.w = getWidth();
                    p.h = getHeight();
                    p.xs = new float[cols];
                    p.ys = new float[rows];
                    for (int i = 0; i < cols; i++) p.xs[i] = tx[i];
                    for (int j = 0; j < rows; j++) p.ys[j] = ty[j * cols];
                    p.dx = Arrays.copyOf(dx, gridN);
                    p.dy = Arrays.copyOf(dy, gridN);
                    onDone(p, note);
                }
            }
            return true;
        }
    }
}
