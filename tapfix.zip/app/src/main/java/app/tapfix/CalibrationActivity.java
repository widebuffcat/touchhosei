package app.tapfix;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class CalibrationActivity extends Activity {

    private static final float[] FX = {0.1f, 0.5f, 0.9f};
    private static final float[] FY = {0.06f, 0.28f, 0.5f, 0.72f, 0.94f};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(new CalView(this));
        hideBars();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    @SuppressWarnings("deprecation")
    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void onDone(final Store.Profile p) {
        final EditText et = new EditText(this);
        List<Store.Profile> l = Store.load(this);
        et.setText("持ち方" + (l.size() + 1));
        new AlertDialog.Builder(this)
                .setTitle("名前をつけて保存")
                .setView(et)
                .setCancelable(false)
                .setPositiveButton("保存", (d, w) -> {
                    String n = et.getText().toString().trim();
                    p.name = n.isEmpty() ? "持ち方" : n;
                    Store.add(this, p);
                    Toast.makeText(this, "保存しました", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .setNegativeButton("破棄", (d, w) -> finish())
                .show();
    }

    private final class CalView extends View {
        private final int cols = FX.length;
        private final int rows = FY.length;
        private final int n = cols * rows;
        private final float[] tx = new float[n];
        private final float[] ty = new float[n];
        private final float[] dx = new float[n];
        private final float[] dy = new float[n];
        private int idx = 0;
        private boolean ready = false;
        private int ox, oy;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        CalView(Context c) {
            super(c);
        }

        private void layoutTargets() {
            int[] loc = new int[2];
            getLocationOnScreen(loc);
            ox = loc[0];
            oy = loc[1];
            for (int j = 0; j < rows; j++) {
                for (int i = 0; i < cols; i++) {
                    tx[j * cols + i] = ox + FX[i] * getWidth();
                    ty[j * cols + i] = oy + FY[j] * getHeight();
                }
            }
            ready = true;
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            ready = false;
        }

        @Override
        protected void onDraw(Canvas c) {
            if (!ready) layoutTargets();
            c.drawColor(Color.BLACK);
            float u = getResources().getDisplayMetrics().density;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.DKGRAY);
            for (int k = 0; k < idx && k < n; k++) c.drawCircle(tx[k] - ox, ty[k] - oy, 5 * u, paint);
            if (idx < n) {
                float x = tx[idx] - ox, y = ty[idx] - oy;
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2 * u);
                paint.setColor(Color.RED);
                c.drawCircle(x, y, 22 * u, paint);
                c.drawLine(x - 34 * u, y, x + 34 * u, y, paint);
                c.drawLine(x, y - 34 * u, x, y + 34 * u, paint);
            }
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.WHITE);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(16 * u);
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            c.drawText("普段の持ち方で、赤い十字の中心を", cx, cy - 40 * u, paint);
            c.drawText("指でタップしてください (" + Math.min(idx + 1, n) + "/" + n + ")", cx, cy - 10 * u, paint);
            paint.setTextSize(12 * u);
            paint.setColor(Color.GRAY);
            c.drawText("戻るキーで中止", cx, cy + 30 * u, paint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN && idx < n) {
                if (!ready) layoutTargets();
                dx[idx] = tx[idx] - e.getRawX();
                dy[idx] = ty[idx] - e.getRawY();
                idx++;
                invalidate();
                if (idx == n) {
                    Store.Profile p = new Store.Profile();
                    p.w = getWidth();
                    p.h = getHeight();
                    p.xs = new float[cols];
                    p.ys = new float[rows];
                    for (int i = 0; i < cols; i++) p.xs[i] = tx[i];
                    for (int j = 0; j < rows; j++) p.ys[j] = ty[j * cols];
                    p.dx = dx.clone();
                    p.dy = dy.clone();
                    onDone(p);
                }
            }
            return true;
        }
    }
}
