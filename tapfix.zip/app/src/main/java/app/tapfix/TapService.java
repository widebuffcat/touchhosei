package app.tapfix;

import android.os.SystemClock;
import android.view.InputDevice;
import android.view.InputEvent;
import android.view.MotionEvent;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Shizukuのユーザーサービス（shell権限・常駐）。
 * タッチデバイスを占有し、補正した座標で打ち直す。
 */
public class TapService extends ITapService.Stub {

    private boolean nativeLoaded = false;
    private String libDir = "";
    private boolean scanned = false;
    private String touchPath = null;
    private final ArrayList<String> keyPaths = new ArrayList<>();
    private final ArrayList<Thread> keyThreads = new ArrayList<>();
    private volatile long volDown = 0;
    private volatile long volUp = 0;
    private volatile int keyEvents = 0;
    private volatile int slopPx = 0;
    private volatile float offX = 0, offY = 0;
    // タップ位置を平均する時間(ms)。0でオフ
    private volatile int avgMs = 0;
    private volatile float[] snap = new float[]{0, 0, 0};
    private int touchDeviceId = 0;
    private int rawMaxX = 1080;
    private int rawMaxY = 2460;

    private Object imObj;
    private Method injM;
    private Object dmg;
    private Method getRealDisplay;
    private Method getRotationM;
    private boolean rotFail = false;

    private volatile boolean running = false;
    private volatile boolean emergency = false;
    private Thread worker;
    private volatile int injected = 0;
    private volatile int fails = 0;
    private volatile int lastRot = 0;
    private volatile String lastErr = "";

    public TapService() {
    }

    @Override
    public void destroy() {
        running = false;
        System.exit(0);
    }

    // ---------- 準備 ----------

    @Override
    public String setLibDir(String dir) {
        libDir = dir == null ? "" : dir;
        return libDir;
    }

    private String ensureNative() {
        if (nativeLoaded) return null;
        if (libDir.isEmpty()) return "ライブラリの場所が未設定です";
        StringBuilder e = new StringBuilder();
        File src = new File(libDir, "libtapnative.so");
        try {
            System.load(src.getPath());
            nativeLoaded = true;
            return null;
        } catch (Throwable t) {
            e.append("直接load失敗: ").append(t).append("\n");
        }
        try {
            File dst = new File("/data/local/tmp/libtapnative.so");
            Files.copy(src.toPath(), dst.toPath(), StandardCopyOption.REPLACE_EXISTING);
            dst.setReadable(true, false);
            System.load(dst.getPath());
            nativeLoaded = true;
            return null;
        } catch (Throwable t) {
            e.append("tmp経由も失敗: ").append(t).append("\n");
        }
        return e.toString();
    }

    private static String geteventRaw(String path) {
        StringBuilder sb = new StringBuilder();
        try {
            java.lang.Process p = new ProcessBuilder("getevent", "-lp", path)
                    .redirectErrorStream(true).start();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line).append("\n");
            }
            p.destroy();
        } catch (Throwable t) {
            sb.append("getevent失敗: ").append(t).append("\n");
        }
        return sb.toString();
    }

    private static int parseMax(String raw, String label, int def) {
        for (String line : raw.split("\n")) {
            if (line.contains(label)) {
                Matcher m = Pattern.compile("max\\s+(\\d+)").matcher(line);
                if (m.find()) return Integer.parseInt(m.group(1));
            }
        }
        return def;
    }

    private void scan() {
        if (scanned) return;
        File[] fs = new File("/dev/input").listFiles();
        if (fs != null) {
            Arrays.sort(fs);
            for (File f : fs) {
                if (!f.getName().startsWith("event")) continue;
                String raw = geteventRaw(f.getPath());
                if (touchPath == null && raw.contains("ABS_MT_POSITION_X")) {
                    touchPath = f.getPath();
                    rawMaxX = parseMax(raw, "ABS_MT_POSITION_X", rawMaxX);
                    rawMaxY = parseMax(raw, "ABS_MT_POSITION_Y", rawMaxY);
                }
                // 音量＋と音量−が別デバイスのことがあるので、どちらか一方でも持つものを全部監視する
                if (raw.contains("KEY_VOLUMEDOWN") || raw.contains("KEY_VOLUMEUP")) {
                    keyPaths.add(f.getPath());
                }
            }
        }
        scanned = true;
    }

    private void initInject() throws Exception {
        if (imObj != null) return;
        Object im;
        try {
            Class<?> c = Class.forName("android.hardware.input.InputManagerGlobal");
            im = c.getMethod("getInstance").invoke(null);
        } catch (Throwable ignored) {
            Class<?> c = Class.forName("android.hardware.input.InputManager");
            im = c.getMethod("getInstance").invoke(null);
        }
        injM = im.getClass().getMethod("injectInputEvent", InputEvent.class, int.class);
        imObj = im;
    }

    private static int findTouchDeviceId() {
        try {
            int[] ids = InputDevice.getDeviceIds();
            for (int id : ids) {
                InputDevice d = InputDevice.getDevice(id);
                if (d != null && (d.getSources() & InputDevice.SOURCE_TOUCHSCREEN) == InputDevice.SOURCE_TOUCHSCREEN) {
                    return id;
                }
            }
        } catch (Throwable ignored) {
        }
        return 0;
    }

    private void buzz() {
        new Thread(() -> {
            try {
                new ProcessBuilder("cmd", "vibrator_manager", "vibrate", "-f", "400")
                        .redirectErrorStream(true).start().waitFor();
            } catch (Throwable ignored) {
            }
        }, "tapfix-buzz").start();
    }

    private int queryRotation() {
        try {
            if (dmg == null) {
                Class<?> c = Class.forName("android.hardware.display.DisplayManagerGlobal");
                dmg = c.getMethod("getInstance").invoke(null);
                getRealDisplay = c.getMethod("getRealDisplay", int.class);
            }
            Object d = getRealDisplay.invoke(dmg, 0);
            if (getRotationM == null) getRotationM = d.getClass().getMethod("getRotation");
            lastRot = (Integer) getRotationM.invoke(d);
            return lastRot;
        } catch (Throwable t) {
            rotFail = true;
            return 0;
        }
    }

    // ---------- 開始・停止 ----------

    @Override
    public synchronized String start(int w, int h, float[] xs, float[] ys, float[] dx, float[] dy, int slop, float offX, float offY, int avgMs) {
        stopInternal();
        String err = ensureNative();
        if (err != null) return "ERR " + err;
        scan();
        if (touchPath == null) return "ERR タッチデバイスが見つかりません";
        try {
            initInject();
        } catch (Throwable t) {
            return "ERR 注入の準備に失敗: " + t;
        }
        int fd = Native.nOpen(touchPath);
        if (fd < 0) return "ERR open失敗 errno=" + (-fd);
        int g = Native.nGrab(fd, 1);
        if (g != 0) {
            Native.nClose(fd);
            return "ERR 占有失敗 errno=" + g;
        }
        slopPx = Math.max(0, Math.min(200, slop));
        this.offX = offX;
        this.offY = offY;
        this.avgMs = Math.max(0, Math.min(200, avgMs));
        touchDeviceId = findTouchDeviceId();
        final Pipe pipe = new Pipe(w, h, xs, ys, dx, dy);
        volDown = 0;
        volUp = 0;
        keyEvents = 0;
        injected = 0;
        fails = 0;
        lastErr = "";
        emergency = false;
        running = true;
        final int ffd = fd;
        worker = new Thread(() -> runLoop(ffd, pipe), "tapfix-worker");
        worker.start();
        keyThreads.clear();
        for (final String kp : keyPaths) {
            Thread t = new Thread(() -> keyLoop(kp), "tapfix-keys");
            t.start();
            keyThreads.add(t);
        }
        return "OK";
    }

    @Override
    public synchronized String stop() {
        stopInternal();
        return "OK";
    }

    private void stopInternal() {
        running = false;
        try {
            if (worker != null) worker.join(1500);
            for (Thread t : keyThreads) t.join(1500);
        } catch (InterruptedException ignored) {
        }
        worker = null;
        keyThreads.clear();
    }

    @Override
    public String status() {
        StringBuilder sb = new StringBuilder();
        sb.append(running ? "動作中" : "停止中");
        sb.append("\n注入 ").append(injected).append(" 回 / 失敗 ").append(fails).append(" 回");
        sb.append("\n画面の向き=").append(lastRot).append(rotFail ? "（取得失敗）" : "");
        if (scanned) {
            sb.append("\n音量キー監視: ").append(keyPaths.size()).append("台 / 検知 ").append(keyEvents).append(" 回");
            if (keyPaths.isEmpty()) sb.append("（見つからないため強制停止は使えません）");
        }
        sb.append("\n全体オフセット: x ").append(String.format(java.util.Locale.US, "%+.0f", offX))
                .append(" / y ").append(String.format(java.util.Locale.US, "%+.0f", offY)).append(" px");
        sb.append("\nタップ位置の平均: ").append(avgMs == 0 ? "オフ" : avgMs + " ms");
        sb.append("\nフリック抑制: ").append(slopPx == 0 ? "オフ" : slopPx + " px");
        if (emergency) sb.append("\n音量キーの同時長押しで停止しました");
        if (!lastErr.isEmpty()) sb.append("\n").append(lastErr);
        return sb.toString();
    }

    @Override
    public void setAvg(int ms) {
        avgMs = Math.max(0, Math.min(200, ms));
    }

    @Override
    public void setOffset(float ox, float oy) {
        offX = Math.max(-100, Math.min(100, ox));
        offY = Math.max(-100, Math.min(100, oy));
    }

    @Override
    public void setSlop(int px) {
        slopPx = Math.max(0, Math.min(200, px));
    }

    // [動作中(0/1), 強制停止(0/1), 指の数n, (id, 生x, 生y, 補正後x, 補正後y) × n]
    @Override
    public float[] points() {
        float[] s = snap;
        float[] o = Arrays.copyOf(s, s.length);
        o[0] = running ? 1 : 0;
        o[1] = emergency ? 1 : 0;
        return o;
    }

    // ---------- 本体ループ ----------

    private void runLoop(int fd, Pipe pipe) {
        byte[] buf = new byte[24 * 64];
        try {
            while (running) {
                int r = Native.nRead(fd, buf, pipe.holding() ? 3 : 100);
                if (r < 0) {
                    lastErr = "読取エラー errno=" + (-r);
                    break;
                }
                for (int off = 0; off + 24 <= r; off += 24) {
                    ByteBuffer bb = ByteBuffer.wrap(buf, off + 16, 8).order(ByteOrder.LITTLE_ENDIAN);
                    int type = bb.getShort() & 0xffff;
                    int code = bb.getShort() & 0xffff;
                    int value = bb.getInt();
                    pipe.feed(type, code, value);
                }
                pipe.tick();
            }
            pipe.cancelAll();
        } catch (Throwable t) {
            lastErr = String.valueOf(t);
        } finally {
            running = false;
            snap = new float[]{0, 0, 0};
            Native.nGrab(fd, 0);
            Native.nClose(fd);
        }
    }

    // 音量＋と音量−を同時に2秒押し続けたら強制停止（監視デバイスごとに1スレッド）
    private void keyLoop(String path) {
        int fd = Native.nOpen(path);
        if (fd < 0) return;
        byte[] buf = new byte[24 * 16];
        try {
            while (running) {
                int r = Native.nRead(fd, buf, 100);
                if (r < 0) break;
                long now = SystemClock.uptimeMillis();
                for (int off = 0; off + 24 <= r; off += 24) {
                    ByteBuffer bb = ByteBuffer.wrap(buf, off + 16, 8).order(ByteOrder.LITTLE_ENDIAN);
                    int type = bb.getShort() & 0xffff;
                    int code = bb.getShort() & 0xffff;
                    int value = bb.getInt();
                    if (type == 1 && value != 2 && (code == 114 || code == 115)) {
                        keyEvents++;
                        if (code == 114) volDown = value == 1 ? now : 0;
                        else volUp = value == 1 ? now : 0;
                    }
                }
                long d = volDown, u = volUp;
                if (d != 0 && u != 0 && now - Math.max(d, u) >= 2000) {
                    emergency = true;
                    running = false;
                    buzz();
                }
            }
        } finally {
            Native.nClose(fd);
        }
    }

    // ---------- 座標補正＋再注入 ----------

    private static int cell(float[] a, float v) {
        int i = 0;
        while (i < a.length - 2 && v >= a[i + 1]) i++;
        return i;
    }

    private static float extT(float t, int i, int last, float cellPx) {
        float e = 60f / Math.max(1f, cellPx);
        float lo = i == 0 ? -e : 0f;
        float hi = i == last ? 1f + e : 1f;
        return t < lo ? lo : (t > hi ? hi : t);
    }

    private static float clamp01(float v) {
        return v < 0 ? 0 : (v > 1 ? 1 : v);
    }

    private static float bil(float[] d, int k, int cols, float tx, float ty) {
        float a = d[k], b = d[k + 1], c = d[k + cols], e = d[k + cols + 1];
        return (a * (1 - tx) + b * tx) * (1 - ty) + (c * (1 - tx) + e * tx) * ty;
    }

    private final class Pipe {
        final int w, h;
        final float[] xs, ys, dx, dy;
        final boolean hasGrid;
        final float sx, sy;

        final boolean[] act = new boolean[16];
        final int[] px = new int[16];
        final int[] py = new int[16];
        int cur, pendDown, pendUp;
        boolean movedExisting;
        long downTime;
        int rot = 0;
        float mx, my;
        // フリック抑制：押した位置、しきい値を超えたか
        final boolean[] broken = new boolean[16];
        final float[] ox = new float[16];
        final float[] oy = new float[16];
        // タップ位置の平均：押してから確定するまで保留している指
        final boolean[] hold = new boolean[16];
        final long[] holdT0 = new long[16];
        final float[] hsx = new float[16];
        final float[] hsy = new float[16];
        final int[] hcnt = new int[16];
        final boolean[] forceAvg = new boolean[16];
        // 直前に送った位置（変化のない MOVE を送らないため）
        final float[] lx = new float[16];
        final float[] ly = new float[16];
        // 表示用：生の位置と補正後の位置
        final float[] rawX = new float[16];
        final float[] rawY = new float[16];
        final float[] outX = new float[16];
        final float[] outY = new float[16];

        Pipe(int w, int h, float[] xs, float[] ys, float[] dx, float[] dy) {
            this.w = w;
            this.h = h;
            this.xs = xs;
            this.ys = ys;
            this.dx = dx;
            this.dy = dy;
            this.hasGrid = xs.length >= 2 && ys.length >= 2
                    && dx.length == xs.length * ys.length && dy.length == dx.length;
            this.sx = (w - 1) / (float) Math.max(1, rawMaxX);
            this.sy = (h - 1) / (float) Math.max(1, rawMaxY);
        }

        void feed(int type, int code, int value) {
            if (type == 3) {
                if (code == 0x2f) {
                    cur = Math.max(0, Math.min(15, value));
                } else if (code == 0x39) {
                    if (value >= 0) {
                        if (!act[cur] && !hold[cur]) pendDown |= 1 << cur;
                    } else {
                        if (act[cur] || hold[cur] || ((pendDown >> cur) & 1) == 1) pendUp |= 1 << cur;
                    }
                } else if (code == 0x35) {
                    px[cur] = value;
                    if (act[cur]) movedExisting = true;
                } else if (code == 0x36) {
                    py[cur] = value;
                    if (act[cur]) movedExisting = true;
                }
            } else if (type == 0 && code == 0) {
                flush();
            }
        }

        void flush() {
            if (pendDown != 0) {
                boolean none = true;
                for (boolean b : act) if (b) none = false;
                if (none) rot = queryRotation();
            }
            long nowMs = SystemClock.uptimeMillis();
            for (int i = 0; i < 16; i++) {
                if (((pendDown >> i) & 1) == 1) {
                    if (avgMs > 0) {
                        // 押した直後の位置は不安定なので、少しの間ためて平均してから DOWN を送る
                        hold[i] = true;
                        holdT0[i] = nowMs;
                        hsx[i] = px[i] * sx;
                        hsy[i] = py[i] * sy;
                        hcnt[i] = 1;
                    } else {
                        act[i] = true;
                        ox[i] = px[i] * sx;
                        oy[i] = py[i] * sy;
                        broken[i] = false;
                        send(0, i);
                    }
                }
            }
            holdStep(nowMs, true, pendDown);
            if (movedExisting) send(2, -1);
            for (int i = 0; i < 16; i++) {
                if (((pendUp >> i) & 1) == 1 && act[i]) {
                    send(1, i);
                    act[i] = false;
                }
            }
            pendDown = 0;
            pendUp = 0;
            movedExisting = false;
            publish();
        }

        boolean holding() {
            for (boolean b : hold) if (b) return true;
            return false;
        }

        // 読み取りが空だった間も、保留時間が過ぎた指を確定させる
        void tick() {
            if (holding()) {
                holdStep(SystemClock.uptimeMillis(), false, 0);
                publish();
            }
        }

        // 保留中の指：時間が来た・指が離れた・大きく動いたら、平均した位置で DOWN を送る
        void holdStep(long now, boolean sample, int newMask) {
            int win = avgMs;
            for (int i = 0; i < 16; i++) {
                if (!hold[i]) continue;
                if (sample && ((newMask >> i) & 1) == 0) {
                    hsx[i] += px[i] * sx;
                    hsy[i] += py[i] * sy;
                    hcnt[i]++;
                }
                float ax = hsx[i] / hcnt[i], ay = hsy[i] / hcnt[i];
                float ddx = px[i] * sx - ax, ddy = py[i] * sy - ay;
                float bd = Math.max(16f, (float) slopPx);
                boolean up = ((pendUp >> i) & 1) == 1;
                if (up || win <= 0 || now - holdT0[i] >= win || ddx * ddx + ddy * ddy > bd * bd) {
                    hold[i] = false;
                    act[i] = true;
                    ox[i] = ax;
                    oy[i] = ay;
                    broken[i] = false;
                    forceAvg[i] = true;
                    send(0, i);
                    forceAvg[i] = false;
                    // 一瞬で離された場合も、DOWN と UP が同じ時刻にならないよう少しだけ間を空ける
                    if (up) SystemClock.sleep(8);
                }
            }
        }

        // 画面表示用のスナップショットを作る
        void publish() {
            int n = 0;
            for (boolean b : act) if (b) n++;
            float[] o = new float[3 + n * 5];
            o[2] = n;
            int k = 3;
            for (int i = 0; i < 16; i++) {
                if (act[i]) {
                    mapPoint(i);
                    o[k++] = i;
                    o[k++] = rawX[i];
                    o[k++] = rawY[i];
                    o[k++] = outX[i];
                    o[k++] = outY[i];
                }
            }
            snap = o;
        }

        void cancelAll() {
            boolean any = false;
            for (boolean b : act) any |= b;
            Arrays.fill(hold, false);
            if (any) {
                send(3, -1);
                Arrays.fill(act, false);
                publish();
            }
        }

        // パネル座標(x,y)を画面の向きに合わせた座標にする（結果は mx, my）
        void rotate(float x, float y) {
            switch (rot) {
                case 1:
                    mx = y;
                    my = (w - 1) - x;
                    break;
                case 2:
                    mx = (w - 1) - x;
                    my = (h - 1) - y;
                    break;
                case 3:
                    mx = (h - 1) - y;
                    my = x;
                    break;
                default:
                    mx = x;
                    my = y;
                    break;
            }
        }

        // 生座標 → フリック抑制 → 補正 → 画面の向きに合わせた座標（結果は mx, my）
        void mapPoint(int slot) {
            float x = px[slot] * sx;
            float y = py[slot] * sy;
            rotate(x, y);
            rawX[slot] = mx;
            rawY[slot] = my;
            int sp = Math.max(slopPx, avgMs > 0 ? 6 : 0);
            if (forceAvg[slot]) {
                x = ox[slot];
                y = oy[slot];
            } else if (sp > 0 && !broken[slot]) {
                float ddx = x - ox[slot], ddy = y - oy[slot];
                if (ddx * ddx + ddy * ddy < (float) sp * sp) {
                    x = ox[slot];
                    y = oy[slot];
                } else {
                    broken[slot] = true;
                }
            }
            if (rot == 0 && hasGrid) {
                int i = cell(xs, x), j = cell(ys, y);
                // 格子の外側（画面の端）は、一番外の区画の傾きをそのまま少しだけ延長する
                float tx = extT((x - xs[i]) / (xs[i + 1] - xs[i]), i, xs.length - 2, xs[i + 1] - xs[i]);
                float ty = extT((y - ys[j]) / (ys[j + 1] - ys[j]), j, ys.length - 2, ys[j + 1] - ys[j]);
                int cols = xs.length;
                x += bil(dx, j * cols + i, cols, tx, ty);
                y += bil(dy, j * cols + i, cols, tx, ty);
            }
            if (rot == 0) {
                // 全体オフセット（縦画面の補正と同じく、横画面では効かせない）
                x += offX;
                y += offY;
            }
            x = Math.max(0, Math.min(w - 1, x));
            y = Math.max(0, Math.min(h - 1, y));
            rotate(x, y);
            outX[slot] = mx;
            outY[slot] = my;
        }

        // kind: 0=down 1=up 2=move 3=cancel
        void send(int kind, int slot) {
            int n = 0, idx = 0;
            int[] ids = new int[16];
            for (int i = 0; i < 16; i++) {
                if (act[i]) {
                    if (i == slot) idx = n;
                    ids[n++] = i;
                }
            }
            if (n == 0) return;
            MotionEvent.PointerProperties[] pp = new MotionEvent.PointerProperties[n];
            MotionEvent.PointerCoords[] pc = new MotionEvent.PointerCoords[n];
            boolean changed = false;
            for (int k = 0; k < n; k++) {
                pp[k] = new MotionEvent.PointerProperties();
                pp[k].id = ids[k];
                pp[k].toolType = MotionEvent.TOOL_TYPE_FINGER;
                mapPoint(ids[k]);
                pc[k] = new MotionEvent.PointerCoords();
                pc[k].x = mx;
                pc[k].y = my;
                pc[k].pressure = 1f;
                pc[k].size = 1f;
                if (mx != lx[ids[k]] || my != ly[ids[k]]) changed = true;
                lx[ids[k]] = mx;
                ly[ids[k]] = my;
            }
            // フリック抑制で位置が変わらない MOVE は送らない
            if (kind == 2 && !changed) return;
            int action;
            switch (kind) {
                case 0:
                    action = n == 1 ? MotionEvent.ACTION_DOWN
                            : (MotionEvent.ACTION_POINTER_DOWN | (idx << MotionEvent.ACTION_POINTER_INDEX_SHIFT));
                    break;
                case 1:
                    action = n == 1 ? MotionEvent.ACTION_UP
                            : (MotionEvent.ACTION_POINTER_UP | (idx << MotionEvent.ACTION_POINTER_INDEX_SHIFT));
                    break;
                case 2:
                    action = MotionEvent.ACTION_MOVE;
                    break;
                default:
                    action = MotionEvent.ACTION_CANCEL;
                    break;
            }
            long now = SystemClock.uptimeMillis();
            if (kind == 0 && n == 1) downTime = now;
            MotionEvent ev = MotionEvent.obtain(downTime, now, action, n, pp, pc,
                    0, 0, 1f, 1f, touchDeviceId, 0, InputDevice.SOURCE_TOUCHSCREEN, 0);
            try {
                injM.invoke(imObj, ev, 0);
                injected++;
            } catch (Throwable t) {
                fails++;
                lastErr = String.valueOf(t);
            } finally {
                ev.recycle();
            }
        }
    }
}
