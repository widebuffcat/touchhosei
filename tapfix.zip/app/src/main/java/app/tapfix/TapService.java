package app.tapfix;

import android.os.SystemClock;
import android.view.InputDevice;
import android.view.InputEvent;
import android.view.MotionEvent;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Shizukuのユーザーサービス（shell権限・常駐）。
 * タッチデバイスを占有し、補正した座標で打ち直す。
 */
public class TapService extends ITapService.Stub {

    private boolean nativeLoaded = false;
    private String libDir = "";
    private boolean scanned = false;
    private String touchPath = null;
    private String keyPath = null;
    private int rawMaxX = 1080;
    private int rawMaxY = 2460;

    private Object imObj;
    private Method injM;
    private Object dmg;
    private Method getRealDisplay;
    private Method getRotationM;
    private boolean rotFail = false;

    private volatile boolean running = false;
    private volatile boolean emergency = false;
    private Thread worker;
    private Thread keyThread;
    private volatile int injected = 0;
    private volatile int fails = 0;
    private volatile int lastRot = 0;
    private volatile String lastErr = "";

    public TapService() {
    }

    @Override
    public void destroy() {
        running = false;
        System.exit(0);
    }

    // ---------- 準備 ----------

    @Override
    public String setLibDir(String dir) {
        libDir = dir == null ? "" : dir;
        return libDir;
    }

    private String ensureNative() {
        if (nativeLoaded) return null;
        if (libDir.isEmpty()) return "ライブラリの場所が未設定です";
        StringBuilder e = new StringBuilder();
        File src = new File(libDir, "libtapnative.so");
        try {
            System.load(src.getPath());
            nativeLoaded = true;
            return null;
        } catch (Throwable t) {
            e.append("直接load失敗: ").append(t).append("\n");
        }
        try {
            File dst = new File("/data/local/tmp/libtapnative.so");
            Files.copy(src.toPath(), dst.toPath(), StandardCopyOption.REPLACE_EXISTING);
            dst.setReadable(true, false);
            System.load(dst.getPath());
            nativeLoaded = true;
            return null;
        } catch (Throwable t) {
            e.append("tmp経由も失敗: ").append(t).append("\n");
        }
        return e.toString();
    }

    private static String geteventRaw(String path) {
        StringBuilder sb = new StringBuilder();
        try {
            java.lang.Process p = new ProcessBuilder("getevent", "-lp", path)
                    .redirectErrorStream(true).start();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line).append("\n");
            }
            p.destroy();
        } catch (Throwable t) {
            sb.append("getevent失敗: ").append(t).append("\n");
        }
        return sb.toString();
    }

    private static int parseMax(String raw, String label, int def) {
        for (String line : raw.split("\n")) {
            if (line.contains(label)) {
                Matcher m = Pattern.compile("max\\s+(\\d+)").matcher(line);
                if (m.find()) return Integer.parseInt(m.group(1));
            }
        }
        return def;
    }

    private void scan() {
        if (scanned) return;
        File[] fs = new File("/dev/input").listFiles();
        if (fs != null) {
            Arrays.sort(fs);
            for (File f : fs) {
                if (!f.getName().startsWith("event")) continue;
                String raw = geteventRaw(f.getPath());
                if (touchPath == null && raw.contains("ABS_MT_POSITION_X")) {
                    touchPath = f.getPath();
                    rawMaxX = parseMax(raw, "ABS_MT_POSITION_X", rawMaxX);
                    rawMaxY = parseMax(raw, "ABS_MT_POSITION_Y", rawMaxY);
                }
                if (keyPath == null && raw.contains("KEY_VOLUMEDOWN") && raw.contains("KEY_VOLUMEUP")) {
                    keyPath = f.getPath();
                }
            }
        }
        scanned = true;
    }

    private void initInject() throws Exception {
        if (imObj != null) return;
        Object im;
        try {
            Class<?> c = Class.forName("android.hardware.input.InputManagerGlobal");
            im = c.getMethod("getInstance").invoke(null);
        } catch (Throwable ignored) {
            Class<?> c = Class.forName("android.hardware.input.InputManager");
            im = c.getMethod("getInstance").invoke(null);
        }
        injM = im.getClass().getMethod("injectInputEvent", InputEvent.class, int.class);
        imObj = im;
    }

    private int queryRotation() {
        try {
            if (dmg == null) {
                Class<?> c = Class.forName("android.hardware.display.DisplayManagerGlobal");
                dmg = c.getMethod("getInstance").invoke(null);
                getRealDisplay = c.getMethod("getRealDisplay", int.class);
            }
            Object d = getRealDisplay.invoke(dmg, 0);
            if (getRotationM == null) getRotationM = d.getClass().getMethod("getRotation");
            lastRot = (Integer) getRotationM.invoke(d);
            return lastRot;
        } catch (Throwable t) {
            rotFail = true;
            return 0;
        }
    }

    // ---------- 開始・停止 ----------

    @Override
    public synchronized String start(int w, int h, float[] xs, float[] ys, float[] dx, float[] dy) {
        stopInternal();
        String err = ensureNative();
        if (err != null) return "ERR " + err;
        scan();
        if (touchPath == null) return "ERR タッチデバイスが見つかりません";
        try {
            initInject();
        } catch (Throwable t) {
            return "ERR 注入の準備に失敗: " + t;
        }
        int fd = Native.nOpen(touchPath);
        if (fd < 0) return "ERR open失敗 errno=" + (-fd);
        int g = Native.nGrab(fd, 1);
        if (g != 0) {
            Native.nClose(fd);
            return "ERR 占有失敗 errno=" + g;
        }
        final Pipe pipe = new Pipe(w, h, xs, ys, dx, dy);
        injected = 0;
        fails = 0;
        lastErr = "";
        emergency = false;
        running = true;
        final int ffd = fd;
        worker = new Thread(() -> runLoop(ffd, pipe), "tapfix-worker");
        worker.start();
        if (keyPath != null) {
            keyThread = new Thread(this::keyLoop, "tapfix-keys");
            keyThread.start();
        }
        return "OK";
    }

    @Override
    public synchronized String stop() {
        stopInternal();
        return "OK";
    }

    private void stopInternal() {
        running = false;
        try {
            if (worker != null) worker.join(1500);
            if (keyThread != null) keyThread.join(1500);
        } catch (InterruptedException ignored) {
        }
        worker = null;
        keyThread = null;
    }

    @Override
    public String status() {
        StringBuilder sb = new StringBuilder();
        sb.append(running ? "動作中" : "停止中");
        sb.append("\n注入 ").append(injected).append(" 回 / 失敗 ").append(fails).append(" 回");
        sb.append("\n画面の向き=").append(lastRot).append(rotFail ? "（取得失敗）" : "");
        if (emergency) sb.append("\n音量キーの同時長押しで停止しました");
        if (!lastErr.isEmpty()) sb.append("\n").append(lastErr);
        return sb.toString();
    }

    // ---------- 本体ループ ----------

    private void runLoop(int fd, Pipe pipe) {
        byte[] buf = new byte[24 * 64];
        try {
            while (running) {
                int r = Native.nRead(fd, buf, 100);
                if (r < 0) {
                    lastErr = "読取エラー errno=" + (-r);
                    break;
                }
                for (int off = 0; off + 24 <= r; off += 24) {
                    ByteBuffer bb = ByteBuffer.wrap(buf, off + 16, 8).order(ByteOrder.LITTLE_ENDIAN);
                    int type = bb.getShort() & 0xffff;
                    int code = bb.getShort() & 0xffff;
                    int value = bb.getInt();
                    pipe.feed(type, code, value);
                }
            }
            pipe.cancelAll();
        } catch (Throwable t) {
            lastErr = String.valueOf(t);
        } finally {
            running = false;
            Native.nGrab(fd, 0);
            Native.nClose(fd);
        }
    }

    // 音量＋と音量−を同時に2秒押し続けたら強制停止
    private void keyLoop() {
        int fd = Native.nOpen(keyPath);
        if (fd < 0) return;
        byte[] buf = new byte[24 * 16];
        long down = 0, up = 0;
        try {
            while (running) {
                int r = Native.nRead(fd, buf, 100);
                if (r < 0) break;
                long now = SystemClock.uptimeMillis();
                for (int off = 0; off + 24 <= r; off += 24) {
                    ByteBuffer bb = ByteBuffer.wrap(buf, off + 16, 8).order(ByteOrder.LITTLE_ENDIAN);
                    int type = bb.getShort() & 0xffff;
                    int code = bb.getShort() & 0xffff;
                    int value = bb.getInt();
                    if (type == 1 && value != 2) {
                        if (code == 114) down = value == 1 ? now : 0;
                        if (code == 115) up = value == 1 ? now : 0;
                    }
                }
                if (down != 0 && up != 0 && now - Math.max(down, up) >= 2000) {
                    emergency = true;
                    running = false;
                }
            }
        } finally {
            Native.nClose(fd);
        }
    }

    // ---------- 座標補正＋再注入 ----------

    private static int cell(float[] a, float v) {
        int i = 0;
        while (i < a.length - 2 && v >= a[i + 1]) i++;
        return i;
    }

    private static float clamp01(float v) {
        return v < 0 ? 0 : (v > 1 ? 1 : v);
    }

    private static float bil(float[] d, int k, int cols, float tx, float ty) {
        float a = d[k], b = d[k + 1], c = d[k + cols], e = d[k + cols + 1];
        return (a * (1 - tx) + b * tx) * (1 - ty) + (c * (1 - tx) + e * tx) * ty;
    }

    private final class Pipe {
        final int w, h;
        final float[] xs, ys, dx, dy;
        final boolean hasGrid;
        final float sx, sy;

        final boolean[] act = new boolean[16];
        final int[] px = new int[16];
        final int[] py = new int[16];
        int cur, pendDown, pendUp;
        boolean movedExisting;
        long downTime;
        int rot = 0;
        float mx, my;

        Pipe(int w, int h, float[] xs, float[] ys, float[] dx, float[] dy) {
            this.w = w;
            this.h = h;
            this.xs = xs;
            this.ys = ys;
            this.dx = dx;
            this.dy = dy;
            this.hasGrid = xs.length >= 2 && ys.length >= 2
                    && dx.length == xs.length * ys.length && dy.length == dx.length;
            this.sx = (w - 1) / (float) Math.max(1, rawMaxX);
            this.sy = (h - 1) / (float) Math.max(1, rawMaxY);
        }

        void feed(int type, int code, int value) {
            if (type == 3) {
                if (code == 0x2f) {
                    cur = Math.max(0, Math.min(15, value));
                } else if (code == 0x39) {
                    if (value >= 0) {
                        if (!act[cur]) pendDown |= 1 << cur;
                    } else {
                        if (act[cur] || ((pendDown >> cur) & 1) == 1) pendUp |= 1 << cur;
                    }
                } else if (code == 0x35) {
                    px[cur] = value;
                    if (act[cur]) movedExisting = true;
                } else if (code == 0x36) {
                    py[cur] = value;
                    if (act[cur]) movedExisting = true;
                }
            } else if (type == 0 && code == 0) {
                flush();
            }
        }

        void flush() {
            if (pendDown != 0) {
                boolean none = true;
                for (boolean b : act) if (b) none = false;
                if (none) rot = queryRotation();
            }
            for (int i = 0; i < 16; i++) {
                if (((pendDown >> i) & 1) == 1) {
                    act[i] = true;
                    send(0, i);
                }
            }
            if (movedExisting) send(2, -1);
            for (int i = 0; i < 16; i++) {
                if (((pendUp >> i) & 1) == 1 && act[i]) {
                    send(1, i);
                    act[i] = false;
                }
            }
            pendDown = 0;
            pendUp = 0;
            movedExisting = false;
        }

        void cancelAll() {
            boolean any = false;
            for (boolean b : act) any |= b;
            if (any) {
                send(3, -1);
                Arrays.fill(act, false);
            }
        }

        // 生座標 → 補正 → 画面の向きに合わせた座標（結果は mx, my）
        void mapPoint(int slot) {
            float x = px[slot] * sx;
            float y = py[slot] * sy;
            if (rot == 0 && hasGrid) {
                int i = cell(xs, x), j = cell(ys, y);
                float tx = clamp01((x - xs[i]) / (xs[i + 1] - xs[i]));
                float ty = clamp01((y - ys[j]) / (ys[j + 1] - ys[j]));
                int cols = xs.length;
                x += bil(dx, j * cols + i, cols, tx, ty);
                y += bil(dy, j * cols + i, cols, tx, ty);
            }
            x = Math.max(0, Math.min(w - 1, x));
            y = Math.max(0, Math.min(h - 1, y));
            switch (rot) {
                case 1:
                    mx = y;
                    my = (w - 1) - x;
                    break;
                case 2:
                    mx = (w - 1) - x;
                    my = (h - 1) - y;
                    break;
                case 3:
                    mx = (h - 1) - y;
                    my = x;
                    break;
                default:
                    mx = x;
                    my = y;
                    break;
            }
        }

        // kind: 0=down 1=up 2=move 3=cancel
        void send(int kind, int slot) {
            int n = 0, idx = 0;
            int[] ids = new int[16];
            for (int i = 0; i < 16; i++) {
                if (act[i]) {
                    if (i == slot) idx = n;
                    ids[n++] = i;
                }
            }
            if (n == 0) return;
            MotionEvent.PointerProperties[] pp = new MotionEvent.PointerProperties[n];
            MotionEvent.PointerCoords[] pc = new MotionEvent.PointerCoords[n];
            for (int k = 0; k < n; k++) {
                pp[k] = new MotionEvent.PointerProperties();
                pp[k].id = ids[k];
                pp[k].toolType = MotionEvent.TOOL_TYPE_FINGER;
                mapPoint(ids[k]);
                pc[k] = new MotionEvent.PointerCoords();
                pc[k].x = mx;
                pc[k].y = my;
                pc[k].pressure = 1f;
                pc[k].size = 1f;
            }
            int action;
            switch (kind) {
                case 0:
                    action = n == 1 ? MotionEvent.ACTION_DOWN
                            : (MotionEvent.ACTION_POINTER_DOWN | (idx << MotionEvent.ACTION_POINTER_INDEX_SHIFT));
                    break;
                case 1:
                    action = n == 1 ? MotionEvent.ACTION_UP
                            : (MotionEvent.ACTION_POINTER_UP | (idx << MotionEvent.ACTION_POINTER_INDEX_SHIFT));
                    break;
                case 2:
                    action = MotionEvent.ACTION_MOVE;
                    break;
                default:
                    action = MotionEvent.ACTION_CANCEL;
                    break;
            }
            long now = SystemClock.uptimeMillis();
            if (kind == 0 && n == 1) downTime = now;
            MotionEvent ev = MotionEvent.obtain(downTime, now, action, n, pp, pc,
                    0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0);
            try {
                injM.invoke(imObj, ev, 0);
                injected++;
            } catch (Throwable t) {
                fails++;
                lastErr = String.valueOf(t);
            } finally {
                ev.recycle();
            }
        }
    }
}
