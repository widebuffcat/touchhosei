package app.tapfix;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.HandlerThread;

/**
 * 端末の傾きを、重力の向きから求める。
 * roll  : 左右の傾き（度）。0 = 左右に傾いていない
 * pitch : 前後の傾き（度）。0 = 画面が垂直、90 = 画面が真上向きで水平
 */
final class TiltSensor implements SensorEventListener {

    interface Callback {
        void onTilt(float roll, float pitch);
    }

    volatile float roll = 0, pitch = 0;
    volatile boolean valid = false;

    private SensorManager sm;
    private HandlerThread thread;
    private Callback cb;
    private boolean usingGravity = false;
    private final float[] g = new float[3];
    private boolean haveG = false;

    boolean start(Context c, Callback cb) {
        this.cb = cb;
        sm = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
        if (sm == null) return false;
        Sensor s = sm.getDefaultSensor(Sensor.TYPE_GRAVITY);
        usingGravity = s != null;
        if (s == null) s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (s == null) return false;
        thread = new HandlerThread("tapfix-tilt");
        thread.start();
        return sm.registerListener(this, s, SensorManager.SENSOR_DELAY_UI, new Handler(thread.getLooper()));
    }

    void stop() {
        try {
            if (sm != null) sm.unregisterListener(this);
        } catch (Throwable ignored) {
        }
        if (thread != null) thread.quitSafely();
        thread = null;
        sm = null;
        valid = false;
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        float[] v = e.values;
        if (v == null || v.length < 3) return;
        if (usingGravity) {
            g[0] = v[0];
            g[1] = v[1];
            g[2] = v[2];
        } else if (!haveG) {
            // 加速度センサーのときは、ローパスで重力成分だけを取り出す
            System.arraycopy(v, 0, g, 0, 3);
            haveG = true;
        } else {
            for (int i = 0; i < 3; i++) g[i] = 0.85f * g[i] + 0.15f * v[i];
        }
        double gx = g[0], gy = g[1], gz = g[2];
        roll = (float) Math.toDegrees(Math.atan2(gx, Math.hypot(gy, gz)));
        pitch = (float) Math.toDegrees(Math.atan2(gz, gy));
        valid = true;
        Callback c = cb;
        if (c != null) c.onTilt(roll, pitch);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }
}
