package app.tapfix;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.SystemClock;

import rikka.shizuku.Shizuku;

/**
 * 補正中、端末の傾きを読み取って、補正の本体（Shizukuの常駐サービス）へ送り続ける。
 * センサーはアプリ側でしか読めないので、前面サービスにして止められにくくしている。
 */
public class TiltService extends Service {

    static volatile boolean running = false;

    private final TiltSensor sensor = new TiltSensor();
    private volatile ITapService svc;
    private boolean bound = false;
    private long lastSend = 0, lastBind = 0;
    private int idle = 0;

    // ジャイロ：直近1秒の回転の大きさ(rad/s, 二乗平均平方根)。机に置いているか手で持っているかの判定に使う
    private android.hardware.SensorManager gsm;
    private android.os.HandlerThread gthread;
    private final long[] gT = new long[256];
    private final float[] gV = new float[256];
    private int gHead = 0, gCount = 0;
    private volatile float gyroRms = -1f;
    private final android.hardware.SensorEventListener gyroListener = new android.hardware.SensorEventListener() {
        @Override
        public void onSensorChanged(android.hardware.SensorEvent e) {
            float[] v = e.values;
            if (v == null || v.length < 3) return;
            long now = SystemClock.uptimeMillis();
            synchronized (gT) {
                gT[gHead] = now;
                gV[gHead] = v[0] * v[0] + v[1] * v[1] + v[2] * v[2];
                gHead = (gHead + 1) % gT.length;
                if (gCount < gT.length) gCount++;
                double sum = 0;
                int n = 0;
                for (int i = 0; i < gCount; i++) {
                    int k = (gHead - 1 - i + gT.length) % gT.length;
                    if (now - gT[k] > 1000) break;
                    sum += gV[k];
                    n++;
                }
                gyroRms = n >= 5 ? (float) Math.sqrt(sum / n) : -1f;
            }
        }

        @Override
        public void onAccuracyChanged(android.hardware.Sensor sensor, int accuracy) {
        }
    };

    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            svc = ITapService.Stub.asInterface(binder);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            svc = null;
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    private Shizuku.UserServiceArgs args() {
        int vc = 1;
        try {
            vc = getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Throwable ignored) {
        }
        return new Shizuku.UserServiceArgs(new ComponentName(getPackageName(), TapService.class.getName()))
                .daemon(true)
                .processNameSuffix("tapfix")
                .version(vc);
    }

    private void startAsForeground() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(
                    "tilt", "傾きの監視", NotificationManager.IMPORTANCE_LOW));
            Notification n = new Notification.Builder(this, "tilt")
                    .setSmallIcon(android.R.drawable.ic_menu_compass)
                    .setContentTitle("傾きを監視中（補正と連携）")
                    .setOngoing(true)
                    .build();
            startForeground(2, n);
        } catch (Throwable ignored) {
        }
    }

    private void rebind() {
        try {
            Shizuku.unbindUserService(args(), conn, false);
        } catch (Throwable ignored) {
        }
        try {
            Shizuku.bindUserService(args(), conn);
            bound = true;
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        startAsForeground();
        lastBind = SystemClock.uptimeMillis();
        try {
            Shizuku.bindUserService(args(), conn);
            bound = true;
        } catch (Throwable ignored) {
        }
        try {
            gsm = (android.hardware.SensorManager) getSystemService(Context.SENSOR_SERVICE);
            android.hardware.Sensor gs = gsm == null ? null : gsm.getDefaultSensor(android.hardware.Sensor.TYPE_GYROSCOPE);
            if (gs != null) {
                gthread = new android.os.HandlerThread("tapfix-gyro");
                gthread.start();
                gsm.registerListener(gyroListener, gs, android.hardware.SensorManager.SENSOR_DELAY_GAME,
                        new android.os.Handler(gthread.getLooper()));
            }
        } catch (Throwable ignored) {
        }
        if (!sensor.start(this, this::onTilt)) {
            running = false;
            stopSelf();
        }
    }

    // センサーの更新ごとに呼ばれる（センサー用スレッド）
    private void onTilt(float roll, float pitch) {
        long now = SystemClock.uptimeMillis();
        if (now - lastSend < 30) return;
        lastSend = now;
        ITapService s = svc;
        if (s == null) {
            if (now - lastBind > 3000) {
                lastBind = now;
                rebind();
            }
            return;
        }
        try {
            boolean on = s.setTilt(roll, pitch);
            float gr = gyroRms;
            if (gr >= 0f) s.setMotion(gr);
            // 補正が止まったままなら、しばらくして自分も止まる
            if (on) idle = 0;
            else if (++idle > 300) stopSelf();
        } catch (Throwable t) {
            svc = null;
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        sensor.stop();
        try {
            if (gsm != null) gsm.unregisterListener(gyroListener);
            if (gthread != null) gthread.quitSafely();
        } catch (Throwable ignored) {
        }
        if (bound) {
            try {
                Shizuku.unbindUserService(args(), conn, false);
            } catch (Throwable ignored) {
            }
        }
        super.onDestroy();
    }
}
